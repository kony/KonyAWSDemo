function AS_Button_ceb57a4b07c24fe4b0037a35d68aa56d(eventobject) {
    popupStorageDownloadStar.destroy();
}