function AS_Button_17dfaa6658ef42c0b5243ea5cfa4efe2(eventobject) {
    var basicConf = {
        message: "Private user file storage is only available to users who are signed-in. Would you like to sign in?",
        alertType: constants.ALERT_TYPE_CONFIRMATION,
        alertTitle: "",
        yesLabel: "Sign In",
        noLabel: "Cancel",
        "alertIcon": "conf.png",
        alertHandler: handle2
    };
    //Defining pspConf parameter for alert
    var pspConf = {};
    //Alert definition
    kony.ui.Alert(basicConf, pspConf);
    //var infoAlert = kony.ui.Alert(basicConf,pspConf);
    function handle2(response) {
        //kony.print(JSON.stringify(response));
        var response = JSON.stringify(response);
        if (response === "true") {
            frmSignIn.show();
        }
    }
}