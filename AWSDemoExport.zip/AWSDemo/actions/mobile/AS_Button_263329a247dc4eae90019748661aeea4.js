function AS_Button_263329a247dc4eae90019748661aeea4(eventobject) {
    if (!frmAppContentDelivery.segAppContent.selectedItems[0].imgStar.visible && !frmAppContentDelivery.segAppContent.selectedItems[0].imgCheck.visible) {
        downloadAndPin();
    } else if (frmAppContentDelivery.segAppContent.selectedItems[0].imgCheck.visible && !frmAppContentDelivery.segAppContent.selectedItems[0].imgStar.visible) {
        pin();
    }
    popupDownload.destroy();
}