function AS_Button_56921ab9b45943719b6ddb0c18785526(eventobject) {
    return onLambdaInvoke.call(this);
}