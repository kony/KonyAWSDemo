function AS_Button_cf8da1eea83a4865ab1a77185dce5c89(eventobject) {
    //if(!frmAppContentDelivery.segAppContent.selectedItems[0].imgCheck.visible){
    //  download();
    //}
    popupStorageDownloadStar.destroy();
}