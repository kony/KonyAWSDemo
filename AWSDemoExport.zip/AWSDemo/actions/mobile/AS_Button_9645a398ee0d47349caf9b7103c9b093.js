function AS_Button_9645a398ee0d47349caf9b7103c9b093(eventobject) {
    cacheLimitValue = 20;
    popupStorageSetCacheSize.destroy();
    //upDateCacheSummary();
}