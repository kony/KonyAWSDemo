function AS_TitleBar_ef176c81a3fe4c81a4d05e0850f57eb9() {
    popupUploadStorage.show();
}