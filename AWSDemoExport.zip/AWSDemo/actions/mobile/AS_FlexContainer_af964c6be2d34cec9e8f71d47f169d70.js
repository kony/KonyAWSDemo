function AS_FlexContainer_af964c6be2d34cec9e8f71d47f169d70() {
    if (frmDetails.lblUserIdentity.text === "Demo Content Delivery") {
        frmAppContentDelivery.show();
    } else if (frmDetails.lblUserIdentity.text === "Demo Cloud Logic") {
        frmClogic.show();
    }
}