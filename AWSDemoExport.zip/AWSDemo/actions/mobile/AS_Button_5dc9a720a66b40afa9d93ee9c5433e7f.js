function AS_Button_5dc9a720a66b40afa9d93ee9c5433e7f(eventobject) {
    cacheLimitValue = 50;
    popupStorageSetCacheSize.destroy();
    //upDateCacheSummary();
}