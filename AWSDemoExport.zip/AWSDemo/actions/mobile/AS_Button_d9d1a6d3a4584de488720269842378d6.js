function AS_Button_d9d1a6d3a4584de488720269842378d6(eventobject) {
    cacheLimitValue = 100;
    popupStorageSetCacheSize.destroy();
    //upDateCacheSummary();
}