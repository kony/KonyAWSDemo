function AS_FlexContainer_13de395912c549cc9c981df17e0b2335() {
    if (frmDetails.lblUserIdentity.text === "Demo Content Delivery") {
        frmAppContentDelivery.show();
    } else if (frmDetails.lblUserIdentity.text === "Demo Cloud Logic") {
        frmClogic.show();
    }
}