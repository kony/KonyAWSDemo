function AS_FlexContainer_1072662e637542dcb57237a552abb018() {
    if (frmDetails.lblUserIdentity.text === "Demo Content Delivery") {
        frmAppContentDelivery.show();
    } else if (frmDetails.lblUserIdentity.text === "Demo Cloud Logic") {
        frmClogic.show();
    } else if (frmDetails.lblUserIdentity.text === "Demo User Identity") {
        frmUserIdentity.show();
    }
}