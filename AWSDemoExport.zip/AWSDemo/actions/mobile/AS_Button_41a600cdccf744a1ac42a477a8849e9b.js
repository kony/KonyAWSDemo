function AS_Button_41a600cdccf744a1ac42a477a8849e9b(eventobject) {
    cacheLimitValue = 50;
    popupSetCacheSize.destroy();
    upDateCacheSummary();
}