function AS_Button_c3d3450483a44ad8880abd805b20d83c(eventobject) {
    cacheLimitValue = 5;
    popupSetCacheSize.destroy();
    upDateCacheSummary();
}