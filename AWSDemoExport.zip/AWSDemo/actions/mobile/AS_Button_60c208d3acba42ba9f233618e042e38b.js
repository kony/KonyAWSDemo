function AS_Button_60c208d3acba42ba9f233618e042e38b(eventobject) {
    cacheLimitValue = 5;
    popupStorageSetCacheSize.destroy();
    //upDateCacheSummary();
}