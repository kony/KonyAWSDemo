function AS_Button_b0815d8ecbfa401aad048aa47e682894(eventobject) {
    clearCache();
    popupUpload.destroy();
}