function AS_Button_c0aabc880f244e89af515962d93f6ccb(eventobject) {
    cacheLimitValue = 1;
    popupStorageSetCacheSize.destroy();
    //upDateCacheSummary();
}