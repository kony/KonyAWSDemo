function AS_Segment_508a6e3a8e9042ffba08699a4059cfe9() {
    var segment = frmAppContentDelivery.segAppContent.selectedRowIndex[0];
    SelectedRow = frmAppContentDelivery.segAppContent.selectedRowIndex[1];
    imageSelectedName = frmAppContentDelivery.segAppContent.selectedItems[0].lblImageName;
    //alert("visibility is"+frmAppContentDelivery.segAppContent.selectedItems[0].imgCheck.visible);
    if (frmAppContentDelivery.segAppContent.selectedItems[0].imgCheck.visible) {
        if (frmAppContentDelivery.segAppContent.selectedItems[0].imgStar.visible) {
            popupDownloadStar.btnPinUnpin.text = "Unpin";
        } else {
            popupDownloadStar.btnPinUnpin.text = "Pin";
        }
        var context2 = {
            "widget": frmAppContentDelivery,
            "anchor": "bottom",
            "sizetoanchorwidth": false
        };
        popupDownloadStar.setContext(context2);
        popupDownloadStar.show();
    } else {
        var context1 = {
            "widget": frmAppContentDelivery,
            "anchor": "bottom",
            "sizetoanchorwidth": false
        };
        popupDownload.setContext(context1);
        popupDownload.show();
    }
}