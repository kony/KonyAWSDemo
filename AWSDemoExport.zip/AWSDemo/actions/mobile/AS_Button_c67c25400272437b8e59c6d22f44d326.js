function AS_Button_c67c25400272437b8e59c6d22f44d326(eventobject) {
    popupUploadStorage.destroy();
}