function AS_Button_d48a4fe1821f4154a28d2aaf0e4c1a5c(eventobject) {
    if (!frmAppContentDelivery.segAppContent.selectedItems[0].imgCheck.visible) {
        download();
    }
    popupDownload.destroy();
}