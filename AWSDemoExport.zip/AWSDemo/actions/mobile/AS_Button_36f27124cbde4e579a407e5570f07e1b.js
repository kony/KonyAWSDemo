function AS_Button_36f27124cbde4e579a407e5570f07e1b(eventobject) {
    popupStorageDownloadStar.destroy();
}