function AS_Segment_3e72b098bf6e43b494a9d9072ec2a060(eventobject, sectionNumber, rowNumber) {
    var segment = frmHome.segHome.selectedRowIndex[0];
    var row = frmHome.segHome.selectedRowIndex[1];
    //alert(frmHome.segHome.selectedItems[0].lblTitle);
    var title = frmHome.segHome.selectedItems[0].lblTitle.text;
    //var title = frmHome.segHome.selectedItems[0].lblTitle;
    HometoDetails(title);
}