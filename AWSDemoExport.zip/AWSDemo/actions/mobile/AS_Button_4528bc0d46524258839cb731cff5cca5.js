function AS_Button_4528bc0d46524258839cb731cff5cca5(eventobject) {
    popupUploadStorage.destroy();
}