function AS_Button_1b9d258fdd17412988cbafb6c68159bc(eventobject) {
    cacheLimitValue = 20;
    popupSetCacheSize.destroy();
    upDateCacheSummary();
}