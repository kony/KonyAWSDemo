function AS_Button_d4637b54d2e14e32aba86d1eab660e1a(eventobject) {
    clearCache();
    popupDownloadStar.destroy();
}