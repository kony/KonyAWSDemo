function AS__83a507c3ea844a72ba6f50263d603ef5() {
    var context1 = {
        "widget": frmAppContentDelivery,
        "anchor": "bottom",
        "sizetoanchorwidth": false
    };
    popupUpload.setContext(context1);
    popupUpload.show();
}