function AS_Button_bd937dac5b824fb5ab1514fae976bbeb(eventobject) {
    cacheLimitValue = 100;
    popupSetCacheSize.destroy();
    upDateCacheSummary();
}