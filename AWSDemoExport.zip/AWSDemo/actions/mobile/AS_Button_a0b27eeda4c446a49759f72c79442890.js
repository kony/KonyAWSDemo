function AS_Button_a0b27eeda4c446a49759f72c79442890(eventobject) {
    popupStorageSetCacheSize.destroy();
}