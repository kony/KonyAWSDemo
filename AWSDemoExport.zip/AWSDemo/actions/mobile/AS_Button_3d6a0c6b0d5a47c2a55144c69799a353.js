function AS_Button_3d6a0c6b0d5a47c2a55144c69799a353(eventobject) {
    //clearCache();
    popupStorageDownloadStar.destroy();
}