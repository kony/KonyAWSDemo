function AS_Button_69fe6627762f47728ccc768615c72f11(eventobject) {
    if (!frmAppContentDelivery.segAppContent.selectedItems[0].imgCheck.visible) {
        download();
    }
    popupDownloadStar.destroy();
}