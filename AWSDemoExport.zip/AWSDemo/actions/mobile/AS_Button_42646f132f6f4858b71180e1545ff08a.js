function AS_Button_42646f132f6f4858b71180e1545ff08a(eventobject) {
    if (popupDownloadStar.btnPinUnpin.text === "Unpin") {
        unpin();
    } else {
        pin();
    }
    popupDownloadStar.destroy();
}