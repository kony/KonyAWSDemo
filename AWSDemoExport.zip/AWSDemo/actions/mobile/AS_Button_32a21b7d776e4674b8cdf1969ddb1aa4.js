function AS_Button_32a21b7d776e4674b8cdf1969ddb1aa4(eventobject) {
    popupStorageDownloadStar.destroy();
    //frmImageOpen.show();
}