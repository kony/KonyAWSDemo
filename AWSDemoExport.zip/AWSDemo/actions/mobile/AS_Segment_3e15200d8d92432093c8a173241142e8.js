function AS_Segment_3e15200d8d92432093c8a173241142e8(eventobject, sectionNumber, rowNumber) {
    var segment = frmUserFileStorage.segAppContent.selectedRowIndex[0];
    SelectedRow = frmUserFileStorage.segAppContent.selectedRowIndex[1];
    imageSelectedName = frmUserFileStorage.segAppContent.selectedItems[0].lblImageName;
    //alert("visibility is"+frmAppContentDelivery.segAppContent.selectedItems[0].imgCheck.visible);
    if (frmUserFileStorage.segAppContent.selectedItems[0].imgCheck.visible) {
        if (frmUserFileStorage.segAppContent.selectedItems[0].imgStar.visible) {
            popupStorageDownloadStar.btnPinUnpin.text = "Unpin";
        } else {
            popupStorageDownloadStar.btnPinUnpin.text = "Pin";
        }
        var context2 = {
            "widget": frmUserFileStorage,
            "anchor": "bottom",
            "sizetoanchorwidth": false
        };
        popupStorageDownloadStar.setContext(context2);
        popupStorageDownloadStar.show();
    } else {
        var context1 = {
            "widget": frmUserFileStorage,
            "anchor": "bottom",
            "sizetoanchorwidth": false
        };
        popupStorageDownload.setContext(context1);
        popupStorageDownload.show();
    }
}