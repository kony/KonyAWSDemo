function AS_Form_727fec50d42d451990be1dac4582f10b() {
    return onShowImage.call(this);
}