function AS_Button_da0e2bb3f3d245ceb71a3e570ce2ce8e(eventobject) {
    popupStorageDownloadStar.destroy();
}