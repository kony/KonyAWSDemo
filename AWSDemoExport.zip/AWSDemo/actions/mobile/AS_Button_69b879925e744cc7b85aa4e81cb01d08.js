function AS_Button_69b879925e744cc7b85aa4e81cb01d08(eventobject) {
    popupUpload.destroy();
}