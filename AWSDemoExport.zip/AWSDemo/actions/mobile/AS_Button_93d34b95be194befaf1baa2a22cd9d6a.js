function AS_Button_93d34b95be194befaf1baa2a22cd9d6a(eventobject) {
    popupUpload.destroy();
}