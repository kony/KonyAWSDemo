function AS_Button_82360d0143f34080a5f9b598b1b77fc6(eventobject) {
    cacheLimitValue = 1;
    popupSetCacheSize.destroy();
    upDateCacheSummary();
}