function AS_Button_d379e5c34a7f42b79db2ceb910263a98(eventobject) {
    //clearCache();
    popupUploadStorage.destroy();
}