function AS_FlexContainer_321845f73d304195bfc3309f1641c039(eventobject, x, y) {
    if (frmDetails.lblUserIdentity.text === "Demo Content Delivery") {
        frmAppContentDelivery.show();
    } else if (frmDetails.lblUserIdentity.text === "Demo Cloud Logic") {
        frmClogic.show();
    } else if (frmDetails.lblUserIdentity.text === "Demo User Identity") {
        frmUserIdentity.show();
    } else if (frmDetails.lblUserIdentity.text === "Demo App Analytics") {
        frmMobileAnalytics.show();
    }
}