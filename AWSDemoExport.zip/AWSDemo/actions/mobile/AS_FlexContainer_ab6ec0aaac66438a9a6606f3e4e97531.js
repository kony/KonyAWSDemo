function AS_FlexContainer_ab6ec0aaac66438a9a6606f3e4e97531() {
    if (frmDetails.lblUserIdentity.text === "Demo Content Delivery") {
        frmAppContentDelivery.show();
    } else if (frmDetails.lblUserIdentity.text === "Demo Cloud Logic") {
        frmClogic.show();
    }
}