function AS_Button_d23c5c25a11c46c1b20fb69333e87512(eventobject) {
    popupUploadStorage.destroy();
}