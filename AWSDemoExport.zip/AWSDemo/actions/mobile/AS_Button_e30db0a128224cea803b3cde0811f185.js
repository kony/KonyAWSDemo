function AS_Button_e30db0a128224cea803b3cde0811f185(eventobject) {
    popupUploadStorage.destroy();
}