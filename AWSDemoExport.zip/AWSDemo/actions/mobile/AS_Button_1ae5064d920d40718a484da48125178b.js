function AS_Button_1ae5064d920d40718a484da48125178b(eventobject) {
    popupUploadStorage.destroy();
    var context3 = {
        "widget": frmUserFileStorage,
        "anchor": "bottom",
        "sizetoanchorwidth": false
    };
    popupUploadStorage.setContext(context3);
    popupStorageSetCacheSize.show();
}