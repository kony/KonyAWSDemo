function AS_Button_ebd296747c32496394482d52218b7e64(eventobject) {
    popupDownloadStar.destroy();
}