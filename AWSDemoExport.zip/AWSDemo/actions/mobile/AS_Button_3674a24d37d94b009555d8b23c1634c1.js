function AS_Button_3674a24d37d94b009555d8b23c1634c1(eventobject) {
    frmClogic.lblResult.text = "";
    frmClogic.txtArea.text = '{\n"key1":"value1",\n"key2":"value2",\n"key3":"value3"\n}';
}