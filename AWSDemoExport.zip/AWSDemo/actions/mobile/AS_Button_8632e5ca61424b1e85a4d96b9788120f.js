function AS_Button_8632e5ca61424b1e85a4d96b9788120f(eventobject) {
    popupUpload.destroy();
    var context3 = {
        "widget": frmAppContentDelivery,
        "anchor": "bottom",
        "sizetoanchorwidth": false
    };
    popupSetCacheSize.setContext(context3);
    popupSetCacheSize.show();
}