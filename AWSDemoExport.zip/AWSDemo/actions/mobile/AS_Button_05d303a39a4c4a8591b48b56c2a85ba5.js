function AS_Button_05d303a39a4c4a8591b48b56c2a85ba5(eventobject) {
    if (!frmAppContentDelivery.segAppContent.selectedItems[0].imgStar.visible && !frmAppContentDelivery.segAppContent.selectedItems[0].imgCheck.visible) {
        downloadAndPin();
    } else if (frmAppContentDelivery.segAppContent.selectedItems[0].imgCheck.visible && !frmAppContentDelivery.segAppContent.selectedItems[0].imgStar.visible) {
        pin();
    }
    popupDownloadStar.destroy();
}