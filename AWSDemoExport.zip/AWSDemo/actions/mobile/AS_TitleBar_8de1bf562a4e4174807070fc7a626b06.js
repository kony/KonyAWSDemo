function AS_TitleBar_8de1bf562a4e4174807070fc7a626b06() {
    var context1 = {
        "widget": frmAppContentDelivery,
        "anchor": "bottom",
        "sizetoanchorwidth": false
    };
    popupUpload.setContext(context1);
    popupUpload.show();
}