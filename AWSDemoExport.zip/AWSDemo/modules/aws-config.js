/**
Please refer the REPLACE ME.txt file for details on these keys
*/

//Lambda Functions create by Mobile Hub
var LambdaFunctiontoInvoke;
var validateUserFunction
var createUserFunction
var News

var config = {
    /**Please provide the access key id && secret access key for your user which are provided when you create a user in th IAM Note: 
    This details will be provided only once when you create a user in IAM*/
    accessKeyId:'',
    secretAccessKey:'',
    region:'',
    Bucket:'',
    IdentityPoolId:'',
    UserPoolId:'',
    ClientId:''
};