
var sampleRecords=[{
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-085248"
	},
	"category": {
		"S": "demo-category-2"
	},
	"creationDate": {
		"N": "1111652916"
	},
	"author": {
		"S": "demo-author-538741"
	},
	"content": {
		"S": "demo-content-448420"
	},
	"keywords": {
		"S": "{ \"papaya\", \"pineapple\" } "
	},
	"title": {
		"S": "demo-title-398301"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-142199"
	},
	"category": {
		"S": "demo-category-0"
	},
	"creationDate": {
		"N": "1111071820"
	},
	"author": {
		"S": "demo-author-300166"
	},
	"content": {
		"S": "demo-content-142179"
	},
	"keywords": {
		"S": "{ \"apple\", \"orange\", \"pineapple\" } "
	},
	"title": {
		"S": "demo-title-636822"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-159718"
	},
	"category": {
		"S": "demo-category-1"
	},
	"creationDate": {
		"N": "1111231134"
	},
	"author": {
		"S": "demo-author-688577"
	},
	"content": {
		"S": "demo-content-691913"
	},
	"keywords": {
		"S": "{ \"cherry\", \"orange\", \"pear\", \"raspberry\" } "
	},
	"title": {
		"S": "demo-title-981018"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-293373"
	},
	"category": {
		"S": "demo-category-2"
	},
	"creationDate": {
		"N": "1111250995"
	},
	"author": {
		"S": "demo-author-020946"
	},
	"content": {
		"S": "demo-content-173991"
	},
	"keywords": {
		"S": "{ \"cherry\", \"pineapple\" } "
	},
	"title": {
		"S": "demo-title-712923"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-304864"
	},
	"category": {
		"S": "demo-category-3"
	},
	"creationDate": {
		"N": "1111245240"
	},
	"author": {
		"S": "demo-author-531095"
	},
	"content": {
		"S": "demo-content-954734"
	},
	"keywords": {
		"S": "{ \"avocado\", \"blueberry\" } "
	},
	"title": {
		"S": "demo-title-112191"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-347072"
	},
	"category": {
		"S": "demo-category-1"
	},
	"creationDate": {
		"N": "1111199801"
	},
	"author": {
		"S": "demo-author-762262"
	},
	"content": {
		"S": "demo-content-205863"
	},
	"keywords": {
		"S": "{ \"grape\", \"papaya\" } "
	},
	"title": {
		"S": "demo-title-360379"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-352936"
	},
	"category": {
		"S": "demo-category-1"
	},
	"creationDate": {
		"N": "1111905516"
	},
	"author": {
		"S": "demo-author-147328"
	},
	"content": {
		"S": "demo-content-265094"
	},
	"keywords": {
		"S": "{ \"blueberry\", \"grape\" } "
	},
	"title": {
		"S": "demo-title-926044"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-417381"
	},
	"category": {
		"S": "demo-category-2"
	},
	"creationDate": {
		"N": "1111659012"
	},
	"author": {
		"S": "demo-author-891171"
	},
	"content": {
		"S": "demo-content-473416"
	},
	"keywords": {
		"S": "{ \"avocado\", \"blueberry\", \"cherry\", \"pear\", \"pineapple\", \"raspberry\" } "
	},
	"title": {
		"S": "demo-title-172759"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-460429"
	},
	"category": {
		"S": "demo-category-3"
	},
	"creationDate": {
		"N": "1111860913"
	},
	"author": {
		"S": "demo-author-569462"
	},
	"content": {
		"S": "demo-content-633958"
	},
	"keywords": {
		"S": "{ \"banana\", \"grape\", \"pear\", \"watermelon\" } "
	},
	"title": {
		"S": "demo-title-466666"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-466277"
	},
	"category": {
		"S": "demo-category-3"
	},
	"creationDate": {
		"N": "1111105949"
	},
	"author": {
		"S": "demo-author-791536"
	},
	"content": {
		"S": "demo-content-559967"
	},
	"keywords": {
		"S": "{ \"banana\", \"blueberry\", \"papaya\", \"raspberry\", \"watermelon\" } "
	},
	"title": {
		"S": "demo-title-442732"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-485542"
	},
	"category": {
		"S": "demo-category-3"
	},
	"creationDate": {
		"N": "1111611907"
	},
	"author": {
		"S": "demo-author-278687"
	},
	"content": {
		"S": "demo-content-699695"
	},
	"keywords": {
		"S": "{ \"pear\" } "
	},
	"title": {
		"S": "demo-title-947653"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-500000"
	},
	"category": {
		"S": "demo-category-2"
	},
	"creationDate": {
		"N": "1111815116"
	},
	"author": {
		"S": "demo-author-820348"
	},
	"content": {
		"S": "demo-content-982484"
	},
	"keywords": {
		"S": "{ \"blueberry\", \"grape\", \"papaya\", \"pineapple\", \"watermelon\" } "
	},
	"title": {
		"S": "demo-title-328001"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-547532"
	},
	"category": {
		"S": "demo-category-0"
	},
	"creationDate": {
		"N": "1111251632"
	},
	"author": {
		"S": "demo-author-193539"
	},
	"content": {
		"S": "demo-content-923274"
	},
	"keywords": {
		"S": "{ \"banana\", \"lemon\", \"pineapple\" } "
	},
	"title": {
		"S": "demo-title-223739"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-558020"
	},
	"category": {
		"S": "demo-category-2"
	},
	"creationDate": {
		"N": "1111814819"
	},
	"author": {
		"S": "demo-author-074234"
	},
	"content": {
		"S": "demo-content-093620"
	},
	"keywords": {
		"S": "{ \"blueberry\", \"grape\", \"lemon\", \"pineapple\", \"raspberry\" } "
	},
	"title": {
		"S": "demo-title-085824"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-766906"
	},
	"category": {
		"S": "demo-category-1"
	},
	"creationDate": {
		"N": "1111310171"
	},
	"author": {
		"S": "demo-author-766031"
	},
	"content": {
		"S": "demo-content-645070"
	},
	"keywords": {
		"S": "{ \"orange\", \"raspberry\" } "
	},
	"title": {
		"S": "demo-title-783236"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-798916"
	},
	"category": {
		"S": "demo-category-0"
	},
	"creationDate": {
		"N": "1111312689"
	},
	"author": {
		"S": "demo-author-719457"
	},
	"content": {
		"S": "demo-content-708525"
	},
	"keywords": {
		"S": "{ \"avocado\", \"banana\", \"grape\", \"lemon\", \"pear\" } "
	},
	"title": {
		"S": "demo-title-882308"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-841275"
	},
	"category": {
		"S": "demo-category-3"
	},
	"creationDate": {
		"N": "1111234024"
	},
	"author": {
		"S": "demo-author-346965"
	},
	"content": {
		"S": "demo-content-901504"
	},
	"keywords": {
		"S": "{ \"apple\", \"orange\", \"papaya\", \"pear\" } "
	},
	"title": {
		"S": "demo-title-733839"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-874946"
	},
	"category": {
		"S": "demo-category-1"
	},
	"creationDate": {
		"N": "1111879904"
	},
	"author": {
		"S": "demo-author-182715"
	},
	"content": {
		"S": "demo-content-370822"
	},
	"keywords": {
		"S": "{ \"banana\", \"blueberry\", \"lemon\", \"papaya\", \"pear\" } "
	},
	"title": {
		"S": "demo-title-263268"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-875885"
	},
	"category": {
		"S": "demo-category-2"
	},
	"creationDate": {
		"N": "1111561810"
	},
	"author": {
		"S": "demo-author-984097"
	},
	"content": {
		"S": "demo-content-959819"
	},
	"keywords": {
		"S": "{ \"apple\", \"blueberry\", \"pear\", \"raspberry\", \"watermelon\" } "
	},
	"title": {
		"S": "demo-title-739678"
	}
}, {
	"userId": {
		"S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
	},
	"articleId": {
		"S": "demo-articleId-976841"
	},
	"category": {
		"S": "demo-category-0"
	},
	"creationDate": {
		"N": "1111098846"
	},
	"author": {
		"S": "demo-author-234181"
	},
	"content": {
		"S": "demo-content-357816"
	},
	"keywords": {
		"S": "{ \"blueberry\", \"grape\" } "
	},
	"title": {
		"S": "demo-title-330691"
	}
}];


