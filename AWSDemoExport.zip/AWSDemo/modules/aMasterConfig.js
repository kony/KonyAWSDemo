navcfg = {"Identity":{form:"frmUserIdentity"}
};

function targetFormFromFunction(fname){
  eval(fname).show();
}
