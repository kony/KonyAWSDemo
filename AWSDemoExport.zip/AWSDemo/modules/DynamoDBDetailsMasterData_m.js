/**
 * @module DynamoDBMasterData_m
 *
 *   
 */
var dynamoDBdata = [
	["Get", [{
		"lblHeading": "Get Item",
		"lblDescription": "Find Item with userId=\'us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704\' and articleId=\'demo-userId-500000\'"
	}]],
  	[
      "Primary Index Queries", [
        {
          "lblHeading" : "Query by Partition Key",
          "lblDescription": "Find all items with userId=\'us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704\'"
        },{
          "lblHeading" : "Query by Partition Key and Filter",
          "lblDescription": "Find all items with userId=\'us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704\' and author >\'demo-author-500000\'"
        },{
          "lblHeading" : "Query by Partition Key and Sort Condition",
          "lblDescription": "Find all items with userId=\'us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704\' and articleId <\'demo-userId-500000\'"
        },{
          "lblHeading" : "Query by Partition Key, Sort Condition and Filter",
          "lblDescription": "Find all items with userId=\'us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704\' , articleId <\'demo-userId-500000\' and author >\'demo-author-500000\'"
        }]],
      [
        "Secondary Index Queries (Categories)", [
          {
            "lblHeading": "Query by Partition Key",
            "lblDescription": "Find all items with category =\'demo-catefory-3\'."
          },
          {
            "lblHeading": "Query by Partition Key and Filter",
            "lblDescription": "Find all items with category =\'demo-catefory-3\' and articleId > \'demo-articleId-500000\'."
          },
          {
            "lblHeading": "Query by Partition Key and Sort Condition",
           "lblDescription": "Find all items with category =\'demo-catefory-3\' and creationDate > \'1111500000\'."
          },
          {
            "lblHeading": "Query by Partition Key, Sort Condition and Filter",
            "lblDescription": "Find all items with category =\'demo-catefory-3\', creationDate < \'1111500000\' and ariticleId > \'demo-articleId-500000\'."
          }]],
  		[
          "Scan", [
            {
              "lblHeading": "Scan",
              "lblDescription": "Show all items in the table."
            },
            {
              "lblHeading": "Scan with Filter",
              "lblDescription": "Find all items with \'author\' > \'demo-author-500000\'."
            }
          ]
        ]
];
