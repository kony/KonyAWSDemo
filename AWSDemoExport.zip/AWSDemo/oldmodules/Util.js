
var  AMAZON_COGNITO_IDENTITY_POOL_ID = "us-east-1:73ced3de-314c-4a8b-95f3-d10daafe57e6";
var AMAZON_CONTENT_DELIVERY_S3_BUCKET = "s3samplesesham";
var AWS_MOBILEHUB_USER_AGENT = "";
/*
var AmazonS3Client = java.import("com.amazonaws.services.s3.AmazonS3Client");
var CognitoCachingCredentialsProvider= java.import("com.amazonaws.auth.CognitoCachingCredentialsProvider");
var CognitoCredentialsProvider = java.import("com.amazonaws.auth.CognitoCredentialsProvider");
var Region = java.import("com.amazonaws.regions.Region");
var Regions = java.import("com.amazonaws.regions.Regions");
var LambdaInvokerFactory = java.import("com.amazonaws.mobileconnectors.lambdainvoker.LambdaInvokerFactory");  
var ClientConfiguration = java.import("com.amazonaws.ClientConfiguration");
var AWSLambdaClient = java.import("com.amazonaws.services.lambda.AWSLambdaClient");
  */
function Util(){
}
Util.sS3Client = null;
Util.sCredProvider = null;
Util.sTransferUtility = null;
Util.region = Regions.US_EAST_1;
Util.scloudFunctionUtility = null;
Util.clientConfiguration = null;
Util.getCredProvider = function(context){
	if(Util.sCredProvider == null){
	 	Util.clientConfiguration = new ClientConfiguration();
        Util.clientConfiguration.setUserAgent(ClientConfiguration.DEFAULT_USER_AGENT);
		Util.sCredProvider = new CognitoCredentialsProvider(AMAZON_COGNITO_IDENTITY_POOL_ID,Regions.US_EAST_1,Util.clientConfiguration);
	}
	return Util.sCredProvider;
}
Util.getS3Client = function (context) {
        if (Util.sS3Client == null) {
            Util.sS3Client = new AmazonS3Client(Util.getCredProvider(context));
        }
        return Util.sS3Client;
}
Util.getTransferUtility = function(context) {
        if (Util.sTransferUtility == null) {
            Util.sTransferUtility = new TransferUtility(Util.getS3Client(context),
                    context);
        }

        return Util.sTransferUtility;
}
Util.getCloudFunctionFactory = function(context){
        if(Util.scloudFunctionUtility === null){
       		kony.print("get cloud function client");
        	Util.scloudFunctionUtility = new LambdaInvokerFactory(context,
                                     Util.region,
                                     Util.getCredProvider(context),
                                     Util.clientConfiguration);
            kony.print("Lambda Invoker Factory created");
        }
        return Util.scloudFunctionUtility;    
}
Util.getCloudFunctionClient = function (context) {
        return new AWSLambdaClient(Util.getCredProvider(context),  Util.clientConfiguration);
    }

