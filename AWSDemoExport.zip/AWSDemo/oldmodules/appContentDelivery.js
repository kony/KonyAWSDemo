var SelectedRow=null;
var imageSelectedName="";


var cacheLimitValue=20;
var cacheUsedValue=0;
var cacheAvailableValue=20;
var cachePinnedValue=0;
var cacheLimit=cacheLimitValue+" MB";
var cacheUsed=cacheUsedValue+" B";
var cacheAvailable=cacheAvailableValue+" MB";
var cachePinned=cachePinnedValue+" B";

function appContentPreshow(){
  frmAppContentDelivery.lblLimit.text=cacheLimit;
  frmAppContentDelivery.lblUsed.text=cacheUsed;
  frmAppContentDelivery.lblAvailable.text=cacheAvailable;
  frmAppContentDelivery.lblPinned.text=cachePinned;  
  var SegaData;
  SegData = listDirectory();

 //SegData = tmpSegData;
  //alert (SegData);
  
  frmAppContentDelivery.segAppContent.setData(SegData);
 
}

function downloadAndPin(){
  cacheAvailableValue=19;
  switch(imageSelectedName.text) {
    case "example-image-1.png":
      cachePinnedValue=cachePinnedValue + 208;
      var data={lblImageName:"example-image-1.png",
              lblImageSize:"208 KB",
              imgStar:{"visible":true},
              imgCheck:{"visible":true}             
              };
      frmAppContentDelivery.segAppContent.setDataAt(data,SelectedRow);
     	
    break;
    case "example-image-2.png":
      cachePinnedValue=cachePinnedValue + 210;
          data={lblImageName:"example-image-2.png",
              lblImageSize:"210 KB",
              imgStar:{"visible":true},
              imgCheck:{"visible":true}             
              };
      frmAppContentDelivery.segAppContent.setDataAt(data,SelectedRow);
    break;
    case "example-image-3.png":
      cachePinnedValue=cachePinnedValue + 216;
      data={lblImageName:"example-image-3.png",
              lblImageSize:"216 KB",
              imgStar:{"visible":true},
              imgCheck:{"visible":true}             
              };
      frmAppContentDelivery.segAppContent.setDataAt(data,SelectedRow);
    break;
    case "example-image-4.png":
      cachePinnedValue=cachePinnedValue + 194;
      data={lblImageName:"example-image-4.png",
              lblImageSize:"194 KB",
              imgStar:{"visible":true},
              imgCheck:{"visible":true}             
              };
      frmAppContentDelivery.segAppContent.setDataAt(data,SelectedRow);
    break;
    case "example-image-5.png":
      cachePinnedValue=cachePinnedValue + 200;
      data={lblImageName:"example-image-5.png",
              lblImageSize:"200 KB",
              imgStar:{"visible":true},
              imgCheck:{"visible":true}             
              };
      frmAppContentDelivery.segAppContent.setDataAt(data,SelectedRow);
    break;
  }
  upDateCacheSummary();
}

function download(){ 
  cacheAvailableValue=19;
  
  tmpchanged=imageSelectedName.text;
  //tmpsize="208";
 
  onDownload(imageSelectedName);
  
  upDateCacheSummary();
}

function unpin(){ 
  popupDownload.destroy();
  switch(imageSelectedName.text) {
    case "example-image-1.png":
      cachePinnedValue=cachePinnedValue - 208;
      cacheUsedValue=cacheUsedValue+208;
      
      
      var data={lblImageName:"example-image-1.png",
              lblImageSize:"208 KB",
              imgStar:{"visible":false},
              imgCheck:{"visible":true}             
              };
      frmAppContentDelivery.segAppContent.setDataAt(data,SelectedRow);
      
     	
    break;
    case "example-image-2.png":
      cachePinnedValue=cachePinnedValue - 210;
      cacheUsedValue=cacheUsedValue+210;
          data={lblImageName:"example-image-2.png",
              lblImageSize:"210 KB",
              imgStar:{"visible":false},
              imgCheck:{"visible":true}             
              };
      frmAppContentDelivery.segAppContent.setDataAt(data,SelectedRow);
    break;
    case "example-image-3.png":
      cachePinnedValue=cachePinnedValue - 216;
      cacheUsedValue=cacheUsedValue+216;
      data={lblImageName:"example-image-3.png",
              lblImageSize:"216 KB",
              imgStar:{"visible":false},
              imgCheck:{"visible":true}             
              };
      frmAppContentDelivery.segAppContent.setDataAt(data,SelectedRow);
    break;
    case "example-image-4.png":
      cachePinnedValue=cachePinnedValue - 194;
      cacheUsedValue=cacheUsedValue+194;
      data={lblImageName:"example-image-4.png",
              lblImageSize:"194 KB",
              imgStar:{"visible":false},
              imgCheck:{"visible":true}             
              };
      frmAppContentDelivery.segAppContent.setDataAt(data,SelectedRow);
    break;
    case "example-image-5.png":
      cachePinnedValue=cachePinnedValue - 200;
      cacheUsedValue=cacheUsedValue+200;
      data={lblImageName:"example-image-5.png",
              lblImageSize:"200 KB",
              imgStar:{"visible":false},
              imgCheck:{"visible":true}             
              };
      frmAppContentDelivery.segAppContent.setDataAt(data,SelectedRow);
    break;
  }
  upDateCacheSummary();
}

function pin(){
  //popupDownload.destroy();
  switch(imageSelectedName.text) {
    case "example-image-1.png":
      cachePinnedValue=cachePinnedValue + 208;
      cacheUsedValue=cacheUsedValue - 208;
      
      var data={lblImageName:"example-image-1.png",
              lblImageSize:"208 KB",
              imgStar:{"visible":true},
              imgCheck:{"visible":true}             
              };
      frmAppContentDelivery.segAppContent.setDataAt(data,SelectedRow);
     	
    break;
    case "example-image-2.png":
      cachePinnedValue=cachePinnedValue + 210;
      cacheUsedValue=cacheUsedValue - 210;
          data={lblImageName:"example-image-2.png",
              lblImageSize:"210 KB",
              imgStar:{"visible":true},
              imgCheck:{"visible":true}             
              };
      frmAppContentDelivery.segAppContent.setDataAt(data,SelectedRow);
    break;
    case "example-image-3.png":
      cachePinnedValue=cachePinnedValue + 216;
      cacheUsedValue=cacheUsedValue - 216;
      data={lblImageName:"example-image-3.png",
              lblImageSize:"216 KB",
              imgStar:{"visible":true},
              imgCheck:{"visible":true}             
              };
      frmAppContentDelivery.segAppContent.setDataAt(data,SelectedRow);
    break;
    case "example-image-4.png":
      cachePinnedValue=cachePinnedValue + 194;
      cacheUsedValue=cacheUsedValue - 194;
      data={lblImageName:"example-image-4.png",
              lblImageSize:"194 KB",
              imgStar:{"visible":true},
              imgCheck:{"visible":true}             
              };
      frmAppContentDelivery.segAppContent.setDataAt(data,SelectedRow);
    break;
    case "example-image-5.png":
      cachePinnedValue=cachePinnedValue + 200;
      cacheUsedValue=cacheUsedValue - 200;
      data={lblImageName:"example-image-5.png",
              lblImageSize:"200 KB",
              imgStar:{"visible":true},
              imgCheck:{"visible":true}             
              };
      frmAppContentDelivery.segAppContent.setDataAt(data,SelectedRow);
    break;
  }
  upDateCacheSummary();
}

function upDateCacheSummary(){
  // alert(cacheUsedValue);
  //  alert(cachePinnedValue);
  
  if(cacheUsedValue >= 999 ){
    frmAppContentDelivery.lblLimit.text=cacheLimitValue+" MB";
  frmAppContentDelivery.lblUsed.text="1 MB";
  frmAppContentDelivery.lblAvailable.text=cacheLimitValue-1+" MB";
  frmAppContentDelivery.lblPinned.text=cachePinnedValue+" KB";   
  } else if(cachePinnedValue >= 999){
    frmAppContentDelivery.lblLimit.text=cacheLimitValue+" MB";
  frmAppContentDelivery.lblUsed.text=cacheUsedValue+" KB";
  frmAppContentDelivery.lblAvailable.text=cacheLimitValue-1+" MB";
  frmAppContentDelivery.lblPinned.text="1 MB";  
    
  }else if(cacheUsedValue === 0){
  frmAppContentDelivery.lblLimit.text=cacheLimitValue+" MB";
  frmAppContentDelivery.lblUsed.text=cacheUsedValue+" KB";
  frmAppContentDelivery.lblAvailable.text=cacheLimitValue+" MB";
  frmAppContentDelivery.lblPinned.text=cachePinnedValue+" KB";  
  }else{
    frmAppContentDelivery.lblLimit.text=cacheLimitValue+" MB";
  frmAppContentDelivery.lblUsed.text=cacheUsedValue+" KB";
  frmAppContentDelivery.lblAvailable.text=cacheLimitValue-1+" MB";
  frmAppContentDelivery.lblPinned.text=cachePinnedValue+" KB";  
    
  }
}

function clearCache(){
  frmAppContentDelivery.lblLimit.text=cacheLimitValue+" MB";
  frmAppContentDelivery.lblUsed.text="0 B";
  frmAppContentDelivery.lblAvailable.text=cacheLimitValue+" MB";
  frmAppContentDelivery.lblPinned.text="0 B"; 
 
  cacheUsedValue=0;
  cachePinnedValue=0;
  
  var SegData = [{lblImageName:"example-image-1.png",
              lblImageSize:"208 KB",
              imgStar:{"visible":false},
              imgCheck:{"visible":false}             
              },
              {lblImageName:"example-image-2.png",
              lblImageSize:"210 KB",
              imgStar:{"visible":false},
              imgCheck:{"visible":false}             
              },
              {lblImageName:"example-image-3.png",
              lblImageSize:"216 KB",
              imgStar:{"visible":false},
              imgCheck:{"visible":false}             
              },
              {lblImageName:"example-image-4.png",
              lblImageSize:"194 KB",
              imgStar:{"visible":false},
              imgCheck:{"visible":false}             
              },
              {lblImageName:"example-image-5.png",
              lblImageSize:"200 KB",
              imgStar:{"visible":false},
              imgCheck:{"visible":false}             
              }
              ];
  frmAppContentDelivery.segAppContent.setData(SegData);
 
}
function downloadrecent(){
  frmAppContentDelivery.lblLimit.text=cacheLimitValue+" MB";
  frmAppContentDelivery.lblUsed.text="1 MB";
  frmAppContentDelivery.lblAvailable.text=cacheLimitValue-1+" MB"; 
  
  var SegData = [{lblImageName:"example-image-1.png",
              lblImageSize:"208 KB",
              imgStar:{"visible":false},
              imgCheck:{"visible":true}             
              },
              {lblImageName:"example-image-2.png",
              lblImageSize:"210 KB",
              imgStar:{"visible":false},
              imgCheck:{"visible":true}             
              },
              {lblImageName:"example-image-3.png",
              lblImageSize:"216 KB",
              imgStar:{"visible":false},
              imgCheck:{"visible":true}             
              },
              {lblImageName:"example-image-4.png",
              lblImageSize:"194 KB",
              imgStar:{"visible":false},
              imgCheck:{"visible":true}             
              },
              {lblImageName:"example-image-5.png",
              lblImageSize:"200 KB",
              imgStar:{"visible":false},
              imgCheck:{"visible":true}             
              }
              ];
  frmAppContentDelivery.segAppContent.setData(SegData);
  
}
