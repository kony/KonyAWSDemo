/*
var KonyMain = java.import("com.konylabs.android.KonyMain");
var context = 	KonyMain.getAppContext();

var TransferListener = java.import("com.amazonaws.mobileconnectors.s3.transferutility.TransferListener");
var TransferObserver =  java.import("com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver");
var TransferState =  java.import("com.amazonaws.mobileconnectors.s3.transferutility.TransferState");
var TransferType =  java.import("com.amazonaws.mobileconnectors.s3.transferutility.TransferType");
var ObjectList = java.import("com.amazonaws.services.s3.model.ObjectListing");
var ListRequest = java.import("com.amazonaws.services.s3.model.ListObjectsRequest");
var S3ObjSummary = java.import("com.amazonaws.services.s3.model.S3ObjectSummary");
var TransferUtility =  java.import("com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility");
var InvokeRequest = java.import("com.amazonaws.services.lambda.model.InvokeRequest");
var InvocationType = java.import("com.amazonaws.services.lambda.model.InvocationType");
//var IdentityManager = java.import("com.amazonaws.mobile.user.IdentityManager");
var Charset =	java.import("java.nio.charset.Charset");
var CHARSET_UTF8 = Charset.forName("UTF-8");
var ENCODER = CHARSET_UTF8.newEncoder();
var DECODER = CHARSET_UTF8.newDecoder();

var CharBuffer = java.import("java.nio.CharBuffer");

var Environment = java.import("android.os.Environment");
var File = java.import("java.io.File");
var tmpchanged;
var tmpsize;
*/
	
function onUpload(){
	kony.print("on upload function");	 
	var s3Client = Util.getS3Client(context);
	//var bucket = s3Client.createBucket("seshamkonybucket");
	var path =  Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
	kony.print("download path acquired");	
	kony.print(path.getPath());
	
	var file = new File(path,"/cat1.png");
		kony.print("file created ");	
		kony.print(file.length());
	var transferUtility = Util.getTransferUtility(context);
		kony.print("transferUtility created ");	
    var observer = transferUtility.upload("seshamkonybucket", file.getName(),file);
        kony.print("upload done");	

}

function getIdentity(){

}

function listDirectory(){
	kony.print("on listing Bucket");
	var objectArray = [];

	var path =  Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
    var S3 = Util.getS3Client();
    var myListObjectRequest = new ListRequest();
    myListObjectRequest.withBucketName("seshamkonybucket");
   
	objectlist =S3.listObjects(myListObjectRequest);

    var objs = objectlist.getObjectSummaries();
    for (x=0; x<objs.size();x++){
  
		S3ObjSummary = objs.get(x);

		var obj = new Object();
	    obj.lblImageName = S3ObjSummary.getKey();
	    obj.lblImageSize = S3ObjSummary.getSize();
	    obj.imgStar = new Object();
	    obj.imgStar.visible=false;
	    obj.imgCheck = new Object();
	    obj.imgCheck.visible=false;
	    objectArray.push(obj);
    }
    
    return objectArray;
    
}
    
function onDownload(imgtodownload){
  
	//kony.print("on download function");
	var transferManager = Util.getTransferUtility(context);
	var path =  Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
	var file = new File(path,imgtodownload);
	file.delete();
	file = new File(path,imgtodownload);
	if(file.createNewFile ()){
		// Starts a download
    
		 var observer = transferManager.download("seshamkonybucket",imgtodownload, file);
			 var TransferListenerInterfaceImplementation = java.newClass('TransferListenerInterfaceImplementation',
			 	'java.lang.Object',['com.amazonaws.mobileconnectors.s3.transferutility.TransferListener'],{
			  'onStateChanged' : function (id,  newState) {
			  			kony.print("bingu " +newState.equals(TransferState.COMPLETED));
			      
					if (newState.equals(TransferState.COMPLETED)) {
             
						kony.print("TransferState completed");
				
	cacheUsedValue=cacheUsedValue + 208;
      var data={lblImageName:"example-image-1.png",
              lblImageSize:"208 KB",
              imgStar:{"visible":false},
              imgCheck:{"visible":true}             
              };

      var obj = new Object();
	    obj.lblImageName = imgtodownload;
	    obj.lblImageSize = tmpsize;
	    obj.imgStar = new Object();
	    obj.imgStar.visible=true;
	    obj.imgCheck = new Object();
	    obj.imgCheck.visible=true;      
       
        frmAppContentDelivery.segAppContent.setDataAt(obj,SelectedRow);


 					}
			     },
			 
			   'onProgressChanged' : function ( id,  bytesCurrent,  bytesTotal) {
			   	kony.print("onProgressChanged called");
			         // Do something in the callback.
					//frmAppContentDelivery.lblBytesRead.text = "bytesCurrent : " + bytesCurrent + " bytesTotal : " + bytesTotal;
			     },
			 
			     'onError' : function ( id,  e) {
			     	kony.print("onError called");
			         Home.lblStateChanged.text = "Error : ";
               
			     }
			 	});
			 observer.setTransferListener(new TransferListenerInterfaceImplementation());
		 
		 
	}else{
      
		kony.print("unable to create  local file ");
	}
 
}
function onShowImage(){
	var path =  Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
	kony.print("************************************************************************************************************************************************************************************************************************************************************************************ " + path + "/cat2.png");
	//imageSelectedName = frmAppContentDelivery.segAppContent.selectedItems[0].lblImageName.text;
  
    tmpimg = "/" + imageSelectedName;
   // alert(tmpimg);
    frmImageOpen.title=imageSelectedName;
    
	var myfile = kony.io.FileSystem.getFile(path+tmpimg);
    frmImageOpen.imgLocal.rawBytes = myfile.read();
	

}
function onLambdaInvoke(){

var payload = ENCODER.encode(CharBuffer.wrap(frmClogic.txtArea.text));
//var payload = ENCODER.encode(CharBuffer.wrap('{"key1":"Kony Lambda Test1","key2":"Kony Lambda Test1","key3":"Kony Lambda Test1"}'));
var functionName = "hello-world";
var  invokeRequest = new InvokeRequest();
      invokeRequest.withFunctionName(functionName)
                   .withInvocationType(InvocationType.RequestResponse)
                   .withPayload(payload);
                   kony.print("before invoking function ************* ************* ************* ************* ************* ************* ************* ************* ************* ************* ************* ************* ************* ************* ************* *************");
      var invokeResult = Util.getCloudFunctionClient(context).invoke(invokeRequest);
                    kony.print("after invoking function ************* ************* ************* ************* ************* ************* ************* ************* ************* ************* ************* ************* ************* ************* ************* *************");
    
      var statusCode = invokeResult.getStatusCode();
      var functionError = invokeResult.getFunctionError();
      var logResult = invokeResult.getLogResult();

        if (statusCode != 200) {
            kony.print(invokeResult.getFunctionError());
        } else {
            var resultPayloadBuffer = invokeResult.getPayload();
            var resultPayload = DECODER.decode(resultPayloadBuffer).toString();
           //Home.lblLambdaResult.text = resultPayload;
           frmClogic.lblResult.text=resultPayload;
           //frmClogic.lbl
        }

        if (functionError != null) {
             kony.print("AWS Lambda Function Error: " + functionError);
        }

        if (logResult != null) {
             kony.print("AWS Lambda Log Result: " + logResult);
        }
  
}
