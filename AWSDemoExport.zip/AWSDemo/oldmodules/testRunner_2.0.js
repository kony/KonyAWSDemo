kony.uirtTest = {};
kony.uirtTest.v2 = {};

kony.uirtTest.v2.constants = {};
kony.uirtTest.v2.TestObj = {};

kony.uirtTest.v2.constants["POSTRESULT_URL"] = "/AppTest/result"; 
kony.uirtTest.v2.constants["GETSCRIPT_URL"] = "/AppTest/info/ScriptName";

/**
 * This class is used for creating a listner in the App for testing purpose 
 * by pinging the test Server
 */
kony.uirtTest.v2.UIRTTestRunner = Class({
	/**
	 * Contructor that initiates the test listner by onbtaining the Ip
	 */
	constructor: function(testUrl) {
        this.testServerUrl = testUrl;
        this.UIRTApi = new kony.automationLib.v2.UIRTAutomationLib(this.testServerUrl,this);
        this.testCommandListener();
    },
    /**
     * This function is the listner by pinging the test Server
     */
    testCommandListener: function(){
    	var scopeObj = this; 
    	scopeObj.getTestScriptName(success,error);
    	function success(){
    		scopeObj.getTestScriptName(success,error);
    	}
    	function error(){
    		scopeObj.getTestScriptName(success,error);
    	}
    },
    /**
     * This function parses the result of pinging to get the Sript Name
     *  
     */
    getTestScriptName: function(success,error){
    	try{
    		var scopeObj = this;
    		// Post call for pinging the Test Server
	     	kony.uirtTest.GET(this.testServerUrl + kony.uirtTest.v2.constants.GETSCRIPT_URL,successCB,errorCB);
	     	function successCB(res){
	     		 var scriptName = res.scriptName;
			     if(scriptName != null && scriptName != undefined && scriptName != "NotAvailable") {
			     // Parsing the response and calling the corresponding UIRT Api
		            var script = scriptName.name;
		            eval("scopeObj.UIRTApi."+script+"(scriptName.inputs,successCallBack,errorCallBack);");
		            function successCallBack(result){
		            	var response = {"status" : 200 , "info" : {"result": result}};
	    				kony.uirtTest.POST(scopeObj.testServerUrl + kony.uirtTest.v2.constants.POSTRESULT_URL,response,successCBack,errorCBack);
	    				function successCBack(){
							success();
	    				}
	    				function errorCBack(err){
	    					alert("Posting Result Failed :"+err.message);
	    				}
		            }
		            function errorCallBack(err){
		            	var response = {"status" : 500 , "info" : {"result":{"msg":err.message},"errMessage":err.message}};
						kony.uirtTest.POST(scopeObj.testServerUrl + kony.uirtTest.v2.constants.POSTRESULT_URL,response,successCBack,errorCBack);
						function successCBack(){
							success();
	    				}
	    				function errorCBack(err){
	    					alert("Posting Result Failed :"+JSON.stringify(err));
	    				}
		            }
		            
		        } else {
		          success();
		        }
	     	}
	     	function errorCB(e){
	     		kony.appfoundation.log.info("Get Call Failed to get Test Script Name Due to "+JSON.stringify(e));
	     		error();
	     	}
       	}catch(err){
       		kony.uirtTest.POST(this.testServerUrl + kony.uirtTest.v2.constants.POSTRESULT_URL,JSON.stringify(err));
       	}	
    }
});
kony.uirtTest.thisControllerToINSTANCE = function(code,currentFormId){
	var CodeToBeAdded = "this.controller = kony.appfoundation.v2.SaaSApplication.INSTANCE.getFormController(\""+currentFormId+"\");";
	return CodeToBeAdded+code;
}
 
    
kony.uirtTest.segmentCodeFormatter = function(code,data){
 	var splitted = code.split("selectedItems");
 	if(splitted.length > 1){
	 	if(splitted[1].indexOf("[") > -1 && splitted[1].indexOf("[") < 4){
	 		splitted[1]  = splitted[1].substring(splitted[1].indexOf("["), splitted[1].length);
	 	}else{
	 		if(splitted[1].indexOf(")") > -1 && splitted[1].indexOf(")") < 4){
	 			splitted[1]  = splitted[1].substring(splitted[1].indexOf("(")+1, splitted[1].length);
	 		}
	 	}
	    var p = splitted[0].split("=");
	    var k = "";
	    for (var i = 0; i < ((p.length) - 1); i++) {
	        k = k + p[i] + "=";
	    }
	    var f = "";
	    for (var j = 1; j < splitted.length; j++) {
	        f = f + splitted[j];
	    }
	    var appended = k+"["+JSON.stringify(data)+"]"+ f;    
	    return appended;
	}else{
		return code;
	}  
 };
/**
 * This function is used for pinging the test Server and getting the test case name
 * 
 */
kony.uirtTest.GET = function(url,success,error){
    var getHeader = {
	    				"Content-Type": "application/json",
	    				"Accept": "application/json"
					};
	kony.appfoundation.theAjaxProvider.get(url,kony.appfoundation.constants.HTTP_METHOD_GET,getHeader,
	success, error, null);
}
/**
 * This function is used for posting the result back after executing thr UIRT api.
 * 
 */
kony.uirtTest.POST = function(url,result,success,error) {
    var postHeader = {
        "Content-Type": "application/x-www-form-urlencoded"
    };
    kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants.HTTP_METHOD_POST,postHeader,
     success, error, result);
}