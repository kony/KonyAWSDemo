kony = kony || {};
kony.appfoundation = kony.appfoundation || {};
kony.appfoundation.log = kony.appfoundation.log || {};
kony.appfoundation.constants = kony.appfoundation.constants || {};

kony.sync = kony.sync || {};

//For Other library logs
kony.afn = kony.afn || {};

kony.appfoundation.success_code = false; //This is used as parameter for sending response code
kony.appfoundation.error_code = false;
kony.appfoundation.isForTesting = undefined;

kony.appfoundation.Platforms = {
	"IPHONE" : "iphone",
	"IPAD" : "ipad",
	"TABRCANDROID" : "tabrcandroid",
	"ANDROID" : "android"
};

kony.appfoundation.Channels = {
	"MOBILE" : "mobile",
	"TABLET" : "tablet"
};

kony.appfoundation.TestConstants = {};

kony.appfoundation.initializeHostSettings = function(hostID){
	kony.appfoundation.constants["HOST_URL"]= (hostID !== undefined && hostID !== null 
								&& hostID !=="" && typeof hostID === "string") ? hostID : "http://10.0.2.2:9080";
	
	kony.appfoundation.constants["CUSTOMSERVICE_ENDPOINT"]=kony.appfoundation.constants["HOST_URL"]+"/SaaSFoundationWS/customservice/v1/";
	kony.appfoundation.constants["DATA_ENDPOINT"]=kony.appfoundation.constants["HOST_URL"]+"/SaaSFoundationWS/data/v1/";
	kony.appfoundation.constants["SYNC_ENDPOINT"]=kony.appfoundation.constants["HOST_URL"]+"/SaaSFoundationWS/sync/v1";
	
	kony.appfoundation.constants["AUTH_ENDPOINT"]=kony.appfoundation.constants["HOST_URL"]+"/SaaSFoundationWS/authenticate";
	kony.appfoundation.constants["AUTH_USER_PROFILE_ENDPOINT"]=kony.appfoundation.constants["HOST_URL"]+"/SaaSFoundationWS/authenticate/userProfile";
	kony.appfoundation.constants["AUTH_USER_AUTH_PROFIlE_ENDPOINT"] = kony.appfoundation.constants["HOST_URL"]+"/SaaSFoundationWS/authenticate/userAuthProfile";
	kony.appfoundation.constants["METADATA_ENDPOINT"]=kony.appfoundation.constants["HOST_URL"]+"/SaaSFoundationWS/metadata/v1";
	kony.appfoundation.constants["RELATED_ENTITY_ENDPOINT"]=kony.appfoundation.constants["HOST_URL"]+"/SaaSFoundationWS/data/v1/relatedentities";
	kony.appfoundation.constants["CUSTOMIZABLE_METADATA_ENDPOINT"]=kony.appfoundation.constants["HOST_URL"]+"/SaaSFoundationWS/metadata/v1/customizableMetadata";
	kony.appfoundation.constants["HTTP_METHOD_GET"]="GET";
	kony.appfoundation.constants["HTTP_METHOD_POST"]="POST";
	kony.appfoundation.constants["UICONFIG_ENDPOINT"]=kony.appfoundation.constants["HOST_URL"]+"/SaaSFoundationWS/uiconfig/v1/formdata";
	kony.appfoundation.constants["TEMPLATES_ENDPOINT"]=kony.appfoundation.constants["HOST_URL"]+"/SaaSFoundationWS/uiconfig/v1/application/templates";
	kony.appfoundation.constants["THEME_ENDPOINT"]=kony.appfoundation.constants["HOST_URL"]+"/SaaSFoundationWS/uiconfig/v1/application/themedata";

	kony.appfoundation.constants["APPPROPS_ENDPOINT"] = kony.appfoundation.constants["HOST_URL"]+"/SaaSFoundationWS/uiconfig/v1/application/applicationproperties";
	kony.appfoundation.constants["DEVICE_ID"] = "";
	kony.appfoundation.constants["ENABLE_COMPLETE_LOGS"] = "false";
	kony.appfoundation.constants["APP_MENU_KEY"] = "APP_MENU";
	kony.appfoundation.constants["CURRENT_APP_THEME"] = null;
	kony.appfoundation.constants["KONY_DEFAULT_THEME"] = "default";
	kony.appfoundation.constants["VIZ_DEFAULT_THEME"] = "defaultTheme";
	kony.appfoundation.constants["MODELER_STORED_THEMES_LIST"] = "generatedThemes";
	kony.appfoundation.metricsPayload=null;
	kony.appfoundation.constants["AFNLocalDBName"] ="AFNLocalDB";
	
} 

//load the setting when app loads
//reload when host id is set
kony.appfoundation.initializeHostSettings();
/*
kony.appfoundation.constants["GET_METADATA"] =
       "SELECT ent.id AS entityId, ent.name AS entityName, ent.sourceentityname AS "
          + "entSrcName,ent.iscustom AS entIsCustom, ent.iscustomizable AS entIsCustomizable, fm.name AS fieldName, fm.sourcefieldname AS fmSrcName, fm.datatype AS fmDataType, fm.hasindex AS "
          + "fmHasIndx, fm.isunique fmIsUnique, fm.isprimarykey AS fmIsPrimaryKey, fm.isnamefield AS fmIsNameField, fm.id AS fieldMappingId, "
          + "fm.isnullable AS fmIsNullable, fm.iscustom AS fmIsCustom, fm.iscreateable AS fmIsCreateable, fm.isupdateable AS fmIsUpdateable, fm.isaudit AS fmIsAudit,"
          + " fm.iscustomizable AS fmIsCustomizable, (select name from entitytype where id = fm.parent_entitytype_id and softdeleteflag = 'false') fmParentEntity, "
          + "(select name from fieldmapping where id = fm.parent_fieldmapping_id and softdeleteflag = 'false') fmParentField, "
          + "(select name from fieldmapping where id = fm.parent_namefield_id and softdeleteflag = 'false') fmParentPrimaryName, "
          + " (SELECT relationship_name FROM entityrelationship WHERE id = fm.relationship_id AND softdeleteflag = 'false') AS relationshipName, "
          + "fm.fieldlength AS fieldlength, pv.value AS pickvalue, pv.label AS picklabel, pv.id AS pickid, pv.fieldmapping_id AS pickfieldmappingid, "
          + "pv.active AS pickactive, pv.defaultvalue AS pickdefaultvalue, pv.validfor AS pickvalidfor "
          + "FROM entitytype ent LEFT OUTER JOIN fieldmapping fm ON ent.id = fm.entitytype_id AND fm.softdeleteflag = 'false' "
          + "LEFT OUTER JOIN picklistvalues pv ON fm.id = pv.fieldmapping_id AND pv.softdeleteflag = 'false' "
          + "WHERE ent.softdeleteflag = 'false' order by entityId";
*/
kony.appfoundation.constants["GET_METADATA_OBJECT_FIELDS"] = "SELECT ent.id AS entityId, ent.name AS entityName, ent.displayname As entDisplayName, ent.isjunction as entJunction, ent.sourceentityname AS  entSrcName, "
    + " fm.name AS fieldName, fm.displayname AS fmDisplayName, fm.sourcefieldname AS fmSrcName, fm.datatype AS fmDataType, fm.hasindex AS "
    + "fmHasIndx, fm.isunique fmIsUnique, fm.id AS fieldMappingId, fm.isprimarykey AS fmIsPrimaryKey, fm.isnamefield AS fmIsNameField, "
    + " fm.isnullable AS fmIsNullable, fm.iscustom AS fmIsCustom,fm.iscustomizable AS fmIsCustomizable, fm.iscreateable AS fmIsCreateable, fm.isupdateable AS fmIsUpdateable, fm.isaudit AS fmIsAudit, "
    + " fm.relationship_id AS fmRelationshipId, (SELECT name FROM fieldmapping WHERE id = fm.parent_fieldmapping_id AND softdeleteflag = 'false') AS referencingField, "
    + " (SELECT name FROM entitytype WHERE id = fm.parent_entitytype_id AND softdeleteflag = 'false') AS referenceTo, "
    + " (SELECT relationship_name FROM entityrelationship WHERE id = fm.relationship_id AND softdeleteflag = 'false') AS relationshipName, "
    + " (SELECT f.name FROM fieldmapping f where  id=(Select referenced_field_id from entityrelationship er where fm.relationship_id = er.id and softdeleteflag='false' ) and softdeleteflag='false') AS referencedField, "
    + " (select sourcefieldname from fieldmapping where id = fm.parent_fieldmapping_id AND softdeleteflag = 'false') AS parent_fieldname, "
    + " (select sourcefieldname from fieldmapping ifm inner join entityrelationship ier "
    + " ON ifm.id = ier.referencing_field_id AND ier.id = fm.relationship_id WHERE ifm.softdeleteflag = 'false' AND ier.softdeleteflag = 'false') as foreign_key, "
    + " (SELECT name FROM fieldmapping WHERE id = fm.parent_namefield_id AND softdeleteflag = 'false') AS parentNameField, "
    + "fm.fieldlength AS fieldlength, pv.value AS pickvalue, pv.label AS picklabel, pv.id AS pickid, pv.fieldmapping_id AS pickfieldmappingid, "
    + "pv.active AS pickactive, pv.defaultvalue AS pickdefaultvalue, pv.validfor AS pickvalidfor "
    + "FROM entitytype ent LEFT OUTER JOIN fieldmapping fm ON ent.id = fm.entitytype_id  AND fm.softdeleteflag = 'false' "
    + "LEFT OUTER JOIN picklistvalues pv ON fm.id = pv.fieldmapping_id AND pv.softdeleteflag = 'false' "
    + "WHERE ent.softdeleteflag = 'false' AND lower(ent.name) = lower(?) AND fm.sourcefieldname is not null AND trim(fm.sourcefieldname) <> '' order by entityId";

kony.appfoundation.constants["FETCH_ENTITY_RELATIONS_BY_ENTITYID"] =
      "SELECT er.id as id, (SELECT ent.name FROM entitytype ent WHERE ent.id = er.referenced_entity_id "
          + "AND ent.softdeleteflag = 'false') AS parentEntityName, (SELECT ent.name FROM entitytype ent WHERE ent.id = er.referencing_entity_id "
          + "AND ent.softdeleteflag = 'false') AS childEntityName, er.relationship_name AS relationshipName, "
          + "(SELECT fm.name FROM fieldmapping fm where fm.id = er.referencing_field_id AND fm.softdeleteflag = 'false') AS referencing_field_name, "
          + "er.relationship_type AS relationshipType, "
          + "(SELECT name FROM entitytype ent WHERE ent.id = er.junction_table_id AND ent.softdeleteflag = 'false') AS junction_table ,"
          + "er.iscustom as isCustom "
          + "FROM entityrelationship er INNER JOIN entitytype ent ON er.referencing_entity_id = ent.id AND ent.isjunction = 'false' "
          + "WHERE er.referenced_entity_id = ? AND er.softdeleteflag = 'false' AND ent.softdeleteflag = 'false' "
          + "UNION "
          + "SELECT er.id as id, (SELECT ent.name FROM entitytype ent WHERE ent.id = er.referencing_entity_id "
          + "AND ent.softdeleteflag = 'false') AS parentEntityName, (SELECT ent.name FROM entitytype ent WHERE ent.id = er.referenced_entity_id "
          + "AND ent.softdeleteflag = 'false') AS childEntityName, er.relationship_name AS relationshipName, "
          + "(SELECT fm.name FROM fieldmapping fm where fm.id = er.referencing_field_id AND fm.softdeleteflag = 'false') AS referencing_field_name, "
          + "er.relationship_type AS relationshipType, "
          + "(SELECT name FROM entitytype ent WHERE ent.id = er.junction_table_id AND ent.softdeleteflag = 'false') AS junction_table ,"
          + "er.iscustom as isCustom "
          + "FROM entityrelationship er INNER JOIN entitytype ent ON er.referencing_entity_id = ent.id AND ent.isjunction = 'false' "
          + "WHERE er.referencing_entity_id = ? AND er.relationship_type = 'ManyToMany' AND er.softdeleteflag = 'false' AND ent.softdeleteflag = 'false'";

kony.appfoundation.constants["picklist"] = "picklist";
kony.appfoundation.constants["reference"] = "reference";
kony.appfoundation.constants["picklistmultiselect"] = "picklistmultiselect";
kony.appfoundation.constants["extendedfield"] = "extendedfield";
kony.appfoundation.constants["entityMetadataMap"] = {};//Does not contain childRelationshipList of the entity, childRelationshipList of an entity will be added when getEntity for that entity is called.
kony.appfoundation.constants["INTEGER_MIN_VALUE"] = -2147483648;
kony.appfoundation.constants["INTEGER_MAX_VALUE"] = 2147483647;


if (typeof(kony.appfoundation.log) === "undefined") {
	kony.appfoundation.log = {};
}

//TRACE(6) > DEBUG(5) > INFO(4) > WARN(3) > ERROR(2) > FATAL(1) > NONE(0)
kony.appfoundation.log.NONE = {
	value : 0,
	name : "none",
	code : "NONE"
};
kony.appfoundation.log.FATAL = {
	value : 1,
	name : "fatal",
	code : "FATAL"
};
kony.appfoundation.log.ERROR = {
	value : 2,
	name : "error",
	code : "ERROR"
};
kony.appfoundation.log.WARN = {
	value : 3,
	name : "warn",
	code : "WARN"
};
kony.appfoundation.log.INFO = {
	value : 4,
	name : "info",
	code : "INFO"
};
kony.appfoundation.log.DEBUG = {
	value : 5,
	name : "debug",
	code : "DEBUG"
};	
kony.appfoundation.log.TRACE = {
	value : 6,
	name : "trace",
	code : "TRACE"
}; 

//Global to maintain current loglevel
kony.appfoundation.currentLogLevel = kony.appfoundation.log.INFO;

kony.appfoundation.log.trace = function (msg, params) {
	kony.appfoundation.logger(kony.appfoundation.log.TRACE, "AFN", msg, params);
};

kony.appfoundation.log.debug = function (msg, params) {
	kony.appfoundation.logger(kony.appfoundation.log.DEBUG, "AFN", msg, params);
};

kony.appfoundation.log.info = function (msg, params) {
	kony.appfoundation.logger(kony.appfoundation.log.INFO, "AFN", msg, params);
};

kony.appfoundation.log.warn = function (msg, params) {
	kony.appfoundation.logger(kony.appfoundation.log.WARN, "AFN", msg, params);
};

kony.appfoundation.log.error = function (msg, params) {
	kony.appfoundation.logger(kony.appfoundation.log.ERROR, "AFN", msg, params);
};

kony.appfoundation.log.fatal = function (msg, params) {
	kony.appfoundation.logger(kony.appfoundation.log.FATAL, "AFN", msg, params);
};


kony.afn.trace = function (tag, msg, params) {
	kony.appfoundation.logger(kony.appfoundation.log.TRACE, tag, msg, params);
};

kony.afn.debug = function (tag, msg, params) {
	kony.appfoundation.logger(kony.appfoundation.log.DEBUG, tag, msg, params);
};

kony.afn.info = function (tag, msg, params) {
	kony.appfoundation.logger(kony.appfoundation.log.INFO, tag, msg, params);
};

kony.afn.warn = function (tag, msg, params) {
	kony.appfoundation.logger(kony.appfoundation.log.WARN, tag, msg, params);
};

kony.afn.error = function (tag, msg, params) {
	kony.appfoundation.logger(kony.appfoundation.log.ERROR, tag, msg, params);
};

kony.afn.fatal = function (tag, msg, params) {
	kony.appfoundation.logger(kony.appfoundation.log.FATAL, tag, msg, params);
};


kony.appfoundation.log.setLogLevel = function (level, logSuccessCallback, logFailureCallback) {
	switch (level) {
	case kony.appfoundation.log.NONE:
		kony.appfoundation.currentLogLevel = kony.appfoundation.log.NONE;
		break;
	case kony.appfoundation.log.TRACE:
		kony.appfoundation.currentLogLevel = kony.appfoundation.log.TRACE;
		break;
	case kony.appfoundation.log.INFO:
		kony.appfoundation.currentLogLevel = kony.appfoundation.log.INFO;
		break;
	case kony.appfoundation.log.WARN:
		kony.appfoundation.currentLogLevel = kony.appfoundation.log.WARN;
		break;
	case kony.appfoundation.log.ERROR:
		kony.appfoundation.currentLogLevel = kony.appfoundation.log.ERROR;
		break;
	case kony.appfoundation.log.FATAL:
		kony.appfoundation.currentLogLevel = kony.appfoundation.log.FATAL;
		break;
	case kony.appfoundation.log.DEBUG:
		kony.appfoundation.currentLogLevel = kony.appfoundation.log.DEBUG;
		break;
	default :
		kony.appfoundation.log.error("Failed in setting log level "+ level);
		kony.appfoundation.verifyAndCallClosure(logFailureCallback, "Failed in setting log level " + level);
		return;
	}
	kony.appfoundation.log.info("Log Level successfully set to " + kony.appfoundation.currentLogLevel.name);
	kony.appfoundation.verifyAndCallClosure(logSuccessCallback, "Log Level successfully set to " + kony.appfoundation.currentLogLevel.name);
};


kony.appfoundation.log.isDebugEnabled = function () {
	return kony.appfoundation.currentLogLevel.value >= kony.appfoundation.log.DEBUG.value;
};

kony.appfoundation.log.isTraceEnabled = function () {
	return kony.appfoundation.currentLogLevel.value >= kony.appfoundation.log.TRACE.value;
};

kony.appfoundation.log.isInfoEnabled = function () {
	return kony.appfoundation.currentLogLevel.value >= kony.appfoundation.log.INFO.value;
};

kony.appfoundation.log.isWarnEnabled = function () {
	return kony.appfoundation.currentLogLevel.value >= kony.appfoundation.log.WARN.value;
};

kony.appfoundation.log.isFatalEnabled = function () {
	return kony.appfoundation.currentLogLevel.value >= kony.appfoundation.log.FATAL.value;
};

kony.appfoundation.log.isErrorEnabled = function () {
	return kony.appfoundation.currentLogLevel.value >= kony.appfoundation.log.ERROR.value;
};

kony.appfoundation.log.isNoneEnabled = function () {
	return kony.appfoundation.currentLogLevel.value === kony.appfoundation.log.NONE.value;
};

kony.appfoundation.log.getCurrentLogLevel = function () {
	return kony.appfoundation.currentLogLevel;
};

kony.appfoundation.isNullOrUndefined = function(val){
	if(val === null || val === undefined){
		return true;
	}else{
		return false;
	}
};

kony.appfoundation.isValidJs = function(inputTable) {
	if (kony.appfoundation.isNullOrUndefined(inputTable)) {
		return false;
	}
	return kony.type(inputTable) === "object" || kony.type(inputTable) === "Object" || kony.type(inputTable) === "Array";
};

kony.appfoundation.logger = function (logLevel, tag, msg, params) {
	if (logLevel.value <= kony.appfoundation.currentLogLevel.value) {
		params = (typeof(params) === "undefined") ? "" : params;

		//Tag undefined
		if(tag === undefined || tag === null) {	
			tag = "AFN";
		}
		
		//Stringify object
		if (kony.appfoundation.isValidJs(params)) {
			params = "";
		}

		var date = new Date().toLocaleDateString();
		var time = new Date().toLocaleTimeString();
		var level = logLevel.code;

		var formattedMessage = "[" + date + "][" + time + "]["+tag+"][" + level + "] : " + msg + " " + params;
		if(kony.appfoundation.error_alert && logLevel.value==kony.appfoundation.log.ERROR.value)
            alert(formattedMessage);
		kony.print(formattedMessage);
	}
};

//Keeping this for jasmine test cases
kony.appfoundation.print = function(statement) {
	if (typeof kony !== 'undefined' && typeof kony.print === 'function') {
		kony.print(statement);
	} else if (typeof console !== 'undefined'
			&& typeof console.log === 'function') {
		console.log(statement);
	}
};

kony.appfoundation.cacheMetadata = function(entities){
	kony.appfoundation.constants.entityMetadataMap = {};
	kony.appfoundation.log.info("GP## ");
	if(entities !== undefined && entities !== null){
		for (var i = 0; i < entities.length; i++) {
			var entity = entities[i];
			kony.appfoundation.constants.entityMetadataMap[entity.name] = entity;
			kony.appfoundation.log.info("GP%% Cached Entity : "+entity.name);
		}
	}
}
kony.appfoundation.cacheEntityMetadata = function(entity){
	if(entity !== undefined && entity !== null){
		kony.appfoundation.constants.entityMetadataMap[entity.name] = entity;
		kony.appfoundation.log.info("GP%% Cached Entity : "+entity.name);
	}
}
kony.appfoundation.getCachedEntityMetadata = function(entityName){
	var entityMetadata;
	if(entityName !== undefined && entityName !==null){
		entityMetadata =  kony.appfoundation.constants.entityMetadataMap[entityName];
	}
	return entityMetadata;
}
kony.appfoundation.AjaxService = Class(function() {
	var ajaxProvider = Class({
		constructor : function() {
			throw "This is an abstract class";
		},
		get : function(url, httpMethod, headers, successCallback,
				errorCallback, formData) {
			throw "Cannot call this function";
		}
	});
	var konyAjaxProvider = Class(ajaxProvider, {
		constructor : function() {
		},
		get : function(url, httpMethod, headers, successCallback,
				errorCallback, formData, dumpLog) {
			try {
				if(!true){
					errorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_NETWORK_UNAVAILABLE, kony.appfoundation.AppFoundationExceptionCode.MSG_NETWORK_UNAVAILABLE));
					return;
				}

				var request = new kony.net.HttpRequest();
				request.onReadyStateChange = callbackHandler;
				url = encodeURI(url);
				request.open(httpMethod, url);
				
				if(!headers.hasOwnProperty("Accept"))
					headers["Accept"] = "application/json";
					
				if(!headers.hasOwnProperty("Content-Type"))
					headers["Content-Type"] = "application/json";
				
				if(!headers.hasOwnProperty("X-Kony-RequestId"))
					headers["X-Kony-RequestId"] = "myRequest";
					
				if(!headers.hasOwnProperty("request-source"))
					headers["request-source"] = "jssdk";
				
				for ( var headerName in headers) {
					request.setRequestHeader(headerName, headers[headerName]);
				}
				
				if(dumpLog)
					kony.appfoundation.log.debug(httpMethod+" request for:"+url+" Headers :",headers);
				else
					kony.appfoundation.log.info(httpMethod+" request for:"+url+" Headers :",headers);	

				if (typeof formData !== 'undefined' && formData !== null) {
					var frmData = new kony.net.FormData();
					kony.appfoundation.log.info("Payload :",formData);
					frmData.append("jsondata", JSON.stringify(formData));
					request.send(frmData);
				} else
					request.send();
			} catch (e) {
				throw "Exception: " + e.message;
			}

			function callbackHandler() {
				kony.appfoundation.log.info("HttpRequest readystate -->"+this.readyState);
				if (this.readyState == 4) {
					var result;
					kony.appfoundation.log.info("Response code -->"+this.status);
					
					// Mainly used for automatic test cases
					if(kony.appfoundation.constants["ENABLE_COMPLETE_LOGS"] !== undefined &&
							kony.appfoundation.constants["ENABLE_COMPLETE_LOGS"] === true)
						kony.appfoundation.log.info("Http Response :",this);
					
					if (this.status == 200 && this.response !== null && this.response !== undefined) {
						if (typeof this.response === 'string' || this.response instanceof String) {
							result = JSON.parse(this.response);
						} else {
							result = this.response;
						}
						if (typeof successCallback === 'function')
							successCallback(result);
						else
							throw "callbackhandler invalid";
					} else if (this.response !== null && this.response !== undefined) {		//error scenario, statusCode other than 200
						if (typeof this.response === 'string' || this.response instanceof String) {
							try{
								result = JSON.parse(this.response);
							} catch(e){
								result = this.response;
							}
						} else {
							result = this.response;
						}
						if (result.hasOwnProperty("DataAccessException")) {
							result = new kony.appfoundation.AppFoundationException(result.DataAccessException.ErrorCode,
										result.DataAccessException.ErrorMessage);
						} else if (result.hasOwnProperty("dataAccessExceptionJson")) {
							result = new kony.appfoundation.AppFoundationException(result.dataAccessExceptionJson.errorCode,
										result.dataAccessExceptionJson.errorMsg);
						} else {
							result = result;
						}
						if (typeof errorCallback === 'function')
							errorCallback(result);
						else
							throw "callbackhandler invalid";
					} else {	//no response from service
						result = new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_NO_RESPONSE_RECEIVED,
										kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_NO_RESPONSE_RECEIVED);
						if (typeof errorCallback === 'function')
							errorCallback(result);
						else
							throw "callbackhandler invalid";
					}
				}
			}
		}
	});
	var jQueryAjaxProvider = Class(
			ajaxProvider,
			{
				constructor : function() {
				},
				get : function(url, httpMethod, headers, successCallback,
						errorCallback, formData, dumpLog) {
					// alert("in jqueryajaxprovider");
					
					if(!true){
						errorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_NETWORK_UNAVAILABLE, kony.appfoundation.AppFoundationExceptionCode.MSG_NETWORK_UNAVAILABLE));
						return;
					}

					headers.Accept = "application/json";
					if(!headers.hasOwnProperty("Accept"))
						headers["Accept"] = "application/json";
					
					if(!headers.hasOwnProperty("Content-Type"))
						headers["Content-Type"] = "application/json";
						
					if(!headers.hasOwnProperty("X-Kony-RequestId"))
						headers["X-Kony-RequestId"] = "myRequest";

				    if(dumpLog)
						kony.appfoundation.log.debug(httpMethod+" request for:"+url+" Headers :",headers);
					else
						kony.appfoundation.log.info(httpMethod+" request for:"+url+" Headers :",headers);						

					var ajaxSettings = {};
					if (typeof formData !== 'undefined' && formData !== null) {
						kony.appfoundation.log.info("Payload :",formData);	
						var frmData;
						if (typeof formData === 'string'
								|| formData instanceof String) {
							frmData = JSON.parse(formData);
						} else {
							frmData = formData;
						}
						ajaxSettings = {
							'type' : httpMethod,
							'headers' : headers,
							'data' : JSON.stringify(frmData),
							'crossDomain' : true,
							'success' : function(data, statusText,xhr) {
								kony.appfoundation.log.
									debug("in jqueryAjaxProvider.get success callback "+data);
								callbackHandler(data, statusText,xhr);
							},
							'error' : function(jqXHR, textStatus, errorThrown) {
								kony.appfoundation.log.
									debug("in jqueryAjaxProvider.get error callback "+
										textStatus+errorThrown);
								errorHandler(jqXHR, textStatus, errorThrown);
							}
						};
					} else {
						ajaxSettings = {
							'type' : httpMethod,
							'headers' : headers,
							'crossDomain' : true,
							'success' : function(data, statusText,xhr) {
								kony.appfoundation.log.
									debug("in jqueryAjaxProvider.get success callback ",
										data);
								callbackHandler(data, statusText,xhr);
							},
							'error' : function(jqXHR, textStatus, errorThrown) {
								errorHandler(jqXHR, textStatus, errorThrown);
							}
						};
					}
					$.ajax(url, ajaxSettings);
					function callbackHandler(response, statusText,xhr) {
						kony.appfoundation.log.info("HttpRequest status -->"+statusText);
						kony.appfoundation.log.info("HttpRequest Code -->"+xhr.status);
						var result;
						if (response !== null && response !== undefined) {
							if ((typeof response === 'string' || response instanceof String)
									&& response.toString().substring(0, 1) === "{") {
								result = JSON.parse(response);
								} else {
								result = response;
							}
							//This change is made to send the response code 
							if(kony.appfoundation.success_code === false)
							{
							kony.appfoundation.log.debug("Inside false kony.appfoundation.success_code");
							if (typeof successCallback === 'function')
								successCallback(result);
							else
								throw "callbackhandler invalid";
							}
							else if(kony.appfoundation.success_code === true)
							{
							kony.appfoundation.log.debug("Inside true success code");
							if (typeof successCallback === 'function')
								successCallback(result,xhr);
							else
								throw "callbackhandler invalid";
							}
						}
					}
					function errorHandler(jqXHR, statusText, errorThrown) {
						kony.appfoundation.log.info("HttpRequest status -->"+statusText);
						kony.appfoundation.log.info("response code:"+jqXHR.status);
						var errorObj;
						if(kony.appfoundation.error_code == true)
						var errorObjCode ={"responseCode":jqXHR.status};
						try {
							if (typeof jqXHR.responseText === 'string'
									|| jqXHR.responseText instanceof String) {
								if (jqXHR.responseText.toString().substring(0,
										1) === "{") {
									errorObj = JSON.parse(jqXHR.responseText);
								} else {
									errorObj = {
										errorCode : "",
										errorMsg : jqXHR.responseText
									};
								}
							} else {
								errorObj = jqXHR.responseText;
							}
						} catch (e) {
							kony.appfoundation.log.error("Exception occured in parsing response."
									+e.message);
							errorObj = {
								errorCode : "",
								errorMsg : jqXHR.responseText
							};
						}
						if (errorObj.hasOwnProperty("DataAccessException")) {
							errorObj = new kony.appfoundation.AppFoundationException(errorObj.DataAccessException.ErrorCode,
											errorObj.DataAccessException.ErrorMessage);
						} else if (errorObj.hasOwnProperty("dataAccessExceptionJson")) {
							errorObj = new kony.appfoundation.AppFoundationException(errorObj.dataAccessExceptionJson.errorCode,
											errorObj.dataAccessExceptionJson.errorMsg);
						} else {
							errorObj = errorObj;
						}
						if (kony.appfoundation.error_code == true) {
							kony.appfoundation.error_code = false;
							if (typeof errorCallback === 'function')
								errorCallback(errorObjCode);
							else
								throw "callbackhandler invalid";
						} else {
							if (typeof errorCallback === 'function')
								errorCallback(errorObj);
							else
								throw "callbackhandler invalid";
						}
					}
				}
			});
	return {
		constructor : function(forTesting) {
			if(forTesting) {
				this.provider = new jQueryAjaxProvider();
			} else if (typeof kony !== 'undefined' && typeof kony.net !== 'undefined') {
				this.provider = new konyAjaxProvider();
			} else if (typeof $ !== 'undefined') {
				this.provider = new jQueryAjaxProvider();
			} else {
				throw "Cannot load provider";
			}
		},
		getAjaxProvider : function() {
			return this.provider;
		}
	};
});
kony.appfoundation.theAjaxProvider = new kony.appfoundation.AjaxService().getAjaxProvider();

kony.appfoundation.Model = Class({
	constructor : function(entityName) {
		this.entityName = entityName;
		this.fields = {};
		this.field_new ={};
		this.fieldarray=[]; 
		this.callback = null;
		this.args = [];
		this.registerCallback = false;
		this.entityDetails = null;
	},
	get : function(fieldName) {
		return this.fields[fieldName];
	},
	
	get_from_fieldarray :function(fieldName,index)
	{
	return this.fieldarray[index][fieldName];
	},
	set : function(fieldName, value) {
		if((fieldName !== "updateable")&&(fieldName !=="datatype"))
		this.fields[fieldName]=value;
		this.field_new[fieldName] = value;
		if (this.registerCallback === true) {
			this.callback.apply(this, this.args);
		}
	},
	
	add : function()
	{
	this.fieldarray.push(this.field_new);
	this.field_new={}
	},
	register : function(callbackFunction, args) {
		this.callback = callbackFunction;
		this.args = args;
		this.registerCallback = true;
	},
	deRegister : function() {
		this.registerCallback = false;
	}
});
kony.appfoundation.DataProvider = Class({
	constructor : function(sessionToken) {
		this.sessionToken = sessionToken;
		//throw "Cannot instantiate object of this class!!";
	},
	update : function(model, syncUpdateSuccess, syncUpdateError) {
		throw "This method is not implemented."
	},
	fetch : function(query, syncFetchSuccess, syncFetchError,odataqueryStr) {
		throw "This method is not implemented."
	},
	read : function(entityName, id) {
		throw "This method is not implemented."
	},
	deleteRecord : function(model, id, syncDeleteSuccess,
			syncDeleteError) {
		throw "This method is not implemented."
	},
	downloadClientArtifact : function() {
		throw "This method is not implemented";
	},
	executeSelectQuery: function(query,successHandler,errorHandler){
		throw "This method is not implemented."
	},
	getRelationData : function(entityName, entityKeyName, entityKeyValue,relation, uiFields, successcallback, errorcallback,criteriaObj) {
		throw "This method is not implemented."
	},
	associate : function(pkName, parent,parentId,child,payload,relation, relationshipname,successcallback,errorcallback){
		throw "This method is not implemented."
	},
	associateexistingrecord : function(pkName, parent,parentId,child,childId,relation, relationshipname,successcallback,errorcallback){
		throw "This method is not implemented."
	},
	dissociate : function(pkName, parent,parentId,child,childId,relation, relationshipname, successcallback, errorcallback){
		throw "This method is not implemented."
	},
	executeGeneratedSQLQuery: function(selectQuery, generatedsqlquery, sucCallBack, errCallBack){
		throw "This method is not implemented."
	}
});


kony.appfoundation.konySyncProvider = Class(
		kony.appfoundation.DataProvider,
		{
			constructor : function(sessionToken) {
				this.$class.$super.call(this, sessionToken);


	},
	fetch : function(selectQuery, successCallback, errorCallback) {
						// Passing additional parameter to toString function to specify the caller of the function
		var query = null;
		for(var i=0; i<selectQuery.tables.length;i++){
			var tName = selectQuery.tables[i].getName();
			if(!selectQuery.tables[i].isJunction() && kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(tName,"","retrieve")){
				//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_READ_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_READ_PERMISSION.replace("{}",tName)).alert(true);
				errorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_READ_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_READ_PERMISSION.replace("{}",tName)));
				return;
			}
		}
		selectQuery.toString(toStringSuccessCallback, toStringErrorCallback, kony.appfoundation.Providers.SYNC);
		function toStringSuccessCallback(response){
			query = response;
		var dbName = kony.appfoundation.getDbName();
		var FetchSelectExecuteTS = new Date();
		kony.sync.single_select_execute(dbName, query, null,
				selectSuccessCallback, selectErrorCallback);
		function selectSuccessCallback(response) {
			var responseJSONArray = [];
			if (response !== null) {
				for ( var i in response) {
					var responseObject = response[i];
					var responseJSONObject = {};
					if (selectQuery.getColumns().length !== 0) {
						for ( var j = 0; j < selectQuery.getColumns().length; j++) {
							var eachColumn = selectQuery.getColumns()[j];
							var columnName = eachColumn.getName();
							var columnType = eachColumn.dataType;
							var columnParentFieldName = eachColumn.parentFieldName ;
							if (columnType !== null && columnType !== undefined && columnType === kony.appfoundation.constants["extendedfield"] && columnParentFieldName !== null && columnParentFieldName !== undefined) {
								responseJSONObject[columnName] = responseObject[columnParentFieldName];
							} else {
								responseJSONObject[columnName] = responseObject[columnName];
							}
						}
					}
					responseJSONArray.push(responseJSONObject);
				}
			}
			var FetchSelectExecuteEndTS = new Date();
            kony.appfoundation.Utils.perftimecal("Fetch records "+ query +" >>","Fetch records end >>",FetchSelectExecuteTS,FetchSelectExecuteEndTS);
			if (typeof (successCallback) == 'function') {
				successCallback(responseJSONArray);
			}
		}

		function selectErrorCallback(error) {
			var eMsg = kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_FAILED_TO_QUERY_DATA;
			if (typeof (errorCallback) == 'function'){
				if(error.errorMessage){
					eMsg = eMsg + " : "+error.errorMessage;		
				}		
				errorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_FAILED_TO_QUERY_DATA,eMsg));
			}
		}
	}
	function toStringErrorCallback(error){
		if (typeof (errorCallback) == 'function')
			errorCallback("Error occurred while constructing the select query with error message '"+error.message+"'");
		}
	},
	customservice : function(httpcustomrequest,customservicename, customserviceCallback,
					customserviceErrorCallback) {
				if(httpcustomrequest !== null
				&& httpcustomrequest !== undefined && httpcustomrequest instanceof kony.appfoundation.HttpCustomRequest)
					{
				httpcustomrequest.headers.session_token = this.sessionToken.token;
			httpcustomrequest.headers["Content-Type"] = "application/json";
				if(!kony.appfoundation.constants["ISCLOUD"]){
					httpcustomrequest.headers["tenant"] = this.sessionToken.tenant;
				}
				var url=kony.appfoundation.constants.CUSTOMSERVICE_ENDPOINT+ customservicename;
				var flag=true;
				for (var key in httpcustomrequest.urlparams) {
					  if (httpcustomrequest.urlparams.hasOwnProperty(key)) {
						  if(flag){
							  url=url+"?"+key+"="+httpcustomrequest.urlparams[key];
							  flag=false;
						  }
						  else{
							  url=url+"&"+key+"="+httpcustomrequest.urlparams[key];
						  }
					  }
					}
				function sucesscallback(response){
					if("customresponse" in response){
					   customserviceCallback(response["customresponse"]);
					}else{
						customserviceErrorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_UNEXPECTED_CUSTOMRESPONSE,kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_UNEXPECTED_CUSTOMRESPONSE));
					}
				}
				function errorcallback(response){
					if("customresponse" in response){
					   customserviceErrorCallback(response["customresponse"]);
					}else{
						customserviceErrorCallback(response);
					}
				}
				
					if(httpcustomrequest.headers["X-HTTP-Method-Override"]==="GET"){
				kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants.HTTP_METHOD_GET,
						httpcustomrequest.headers, sucesscallback, errorcallback,
						httpcustomrequest.payload);
						}
						else{
						kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants.HTTP_METHOD_POST,
						httpcustomrequest.headers, sucesscallback, errorcallback,
						httpcustomrequest.payload);
						}
					}else{
						customserviceErrorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_INVALID_CUSTOMSERVICE_INPUT_PARAM,kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_INVALID_CUSTOMSERVICE_INPUT_PARAM));
					}
			},
	create : function(model, successCallback, errorCallback) {
		var isJunction = (model.entityDetails) ? ((model.entityDetails["isjunction"]) ?  model.entityDetails["isjunction"] : false ): false;
		if(!isJunction && kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(model.entityName,"","create")){
			//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_CREATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_CREATE_PERMISSION.replace("{}",model.entityName)).alert(true);
			errorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_CREATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_CREATE_PERMISSION.replace("{}",model.entityName)));
			return;
		}
		var result = kony.appfoundation.validateFormDataModel(model, true); 
		if(!result.isValid){
			errorCallback(result);
			return;
		}
		
		
		var baseTable = new kony.appfoundation.Table(model.entityName);
	    var insertQuery = new kony.appfoundation.InsertQuery(baseTable);
	    
		for (var columnName in model.fields) {
			if (model.fields.hasOwnProperty(columnName)) {
				var primaryKeyName = ""+model.entityDetails.primaryKeyName;
				if (columnName.toUpperCase() !== primaryKeyName.toUpperCase()) {
					var col = new kony.appfoundation.Column(baseTable,columnName); 
					insertQuery.addColumn(col,model.fields[columnName])
				}
			}
		}
		
		var valid = kony.appfoundation.Utils.validateInput(insertQuery.listColumns(),
				insertQuery.listValues());
		if (valid) {
			doInsert(insertQuery, insertSuccessCallback,
					insertErrorCallback);
			function insertSuccessCallback(response) {
				if (typeof (successCallback) == 'function') {
					successCallback(response);
				}
			}
			function insertErrorCallback(errMessage) {
				if (typeof (errorCallback) == 'function') {
					errorCallback(errMessage);
				}
			}
			
		} else {
			return errorCallback(kony.appfoundation.DataAccessAppsExceptionCode.CD_ERROR_INSERT
					+ " : "
					+ kony.appfoundation.DataAccessAppsExceptionCode.MSG_ERROR_INSERT);
		}

		function doInsert(insertQueryObj, insertSuccCallback,
				insertErrCallback) {
			var columns = insertQueryObj.listColumns();
			var values = insertQueryObj.listValues();
			var table = insertQueryObj.getBaseTable();
			var tableName = table.getName();
			var columnValuePair = convertColumnValuePair(insertQueryObj
					.listColumns(), insertQueryObj.listValues());
			function convertColumnValuePair(columns, values) {
				var json = {};

				for ( var index = 0; index < columns.length; index++) {
					var col = columns[index];
					if (col instanceof kony.appfoundation.Column) {
						//json[col.toStringByMode(3)] = values[index];
						if (kony.sync.isValidNumberType(values[index] && values[index] >= 0) === true) {
							json[col.toStringByMode(3)] = ""
									+ values[index];
						} else {
							json[col.toStringByMode(3)] = values[index];
						}
					} else {
						throw new kony.appfoundation.DataAccessAppsException(
								kony.appfoundation.DataAccessAppsExceptionCode.CD_ERROR_INVALID_TABLE,
								kony.appfoundation.DataAccessAppsExceptionCode.MSG_ERROR_INVALID_TABLE);
					}
				}
				//var str = JSON.stringify(json);
				//return str;
				return json; 
			}
			var valuesTable = columnValuePair;
			var dsname = kony.appfoundation.getDbName();
			var InsertRecordTS = new Date();
			kony.sync.single_insert_execute(dsname, tableName,
					valuesTable, insertsuccess, inserterror, true);
			function insertsuccess(response) {
				// insertQueryObj.setRetVal(response["id"]);
				//var responseJson = {};
				//responseJson.recordId = response.id;
				var InsertRecordEndTS = new Date();
                        kony.appfoundation.Utils.perftimecal("Insert record >>","Insert record end >>",InsertRecordTS,InsertRecordEndTS);
				if(response&&response["id"]&&response["id"].toString().indexOf(".0")===-1){
					response["id"]+=".0";
				}else if(response&&response["Id"]&&response["Id"].toString().indexOf(".0")===-1){
					response["Id"]+=".0";
				}else if(response&&response["GUID"]&&response["GUID"].toString().indexOf(".0")===-1){
					response["GUID"]+=".0";
				}
				insertSuccCallback(response);
			}
			function inserterror(errMessage) {
				insertErrCallback(kony.appfoundation.DataAccessAppsExceptionCode.CD_ERROR_UNKNOWN_DB_ERROR
						+ ":"
						+ kony.appfoundation.DataAccessAppsExceptionCode.MSG_ERROR_UNKNOWN_DB_ERROR);
			}
		}
	},
	update : function(model, successCallback, errorCallback) {
		if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(model.entityName,"","update")){
			//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_UPDATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_UPDATE_PERMISSION.replace("{}",model.entityName)).alert(true);
			errorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_UPDATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_UPDATE_PERMISSION.replace("{}",model.entityName)));
			return;
		}
		
		var result = kony.appfoundation.validateFormDataModel(model, false);
		if(!result.isValid){
			errorCallback(result);
			return;
		}
		var tableName = model.entityName;
	    var dbName = kony.appfoundation.getDbName();
	    var valuesTable = {};
	    var pKey = "";
	    var pKeyValue = "";
	    var whereClause = [];
	    var primaryKeyName = model.entityDetails.primaryKeyName;
	    if (model.fields[primaryKeyName] !== null && model.fields[primaryKeyName] !== undefined) {
	        pKeyValue = model.fields[primaryKeyName];
	        pKey = primaryKeyName;
	    }
	    var pkTable = {};
	    pkTable.Id = {
	        "key": pKey,
	        "value": pKeyValue
	    };
	    var condition = {};
	    condition.key = pKey;
	    condition.value = pKeyValue;
	    whereClause.push(condition);
	    for (var columnName in model.fields) {
	        if (model.fields.hasOwnProperty(columnName)) {
	            if (columnName.toUpperCase() !== model.entityDetails.primaryKeyName) {
	                if (kony.sync.isValidNumberType(model.fields[columnName]) === true && model.fields[columnName] >= 0) {
						valuesTable[columnName] = ""
								+ model.fields[columnName];
					} else {
						valuesTable[columnName] = model.fields[columnName];
					}
	            }
	        }
	    }
		var updateRecordTS = new Date();
	    kony.sync.updateByPK(tableName, dbName, null, pkTable, valuesTable, syncUpdateEntitySuccess, syncUpdateEntityError, true, whereClause);
	
	    function syncUpdateEntitySuccess(response) {
	        var modifiedResponse = {};
	        modifiedResponse["updatedRecords"] = 1;
			var updateRecordEndTS = new Date();
                        kony.appfoundation.Utils.perftimecal("updateRecord >>","updateRecord end >>",updateRecordTS,updateRecordEndTS);
	        if (typeof(successCallback) == "function") {
	            successCallback(modifiedResponse);
	        }
	    }
	
	    function syncUpdateEntityError(error) {
	    	if(typeof(errorCallback) == "function"){
	        	errorCallback(error);
	        }
	    }
	},
	read : function(entityName, id) {
		throw "This method is not implemented."
	},
	deleteRecord : function(model, id, successCallback,
			errorCallback) {
		if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(model.entityName,"","delete")){
			//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_DELETE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_DELETE_PERMISSION.replace("{}",model.entityName)).alert(true);
			errorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_DELETE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_DELETE_PERMISSION.replace("{}",model.entityName)));
			return;
		}
		var deleteRecordTS = new Date();
		kony.appfoundation.deleteRecordCascade(model, id, delSuccCallback, delErrCallback);
		/*var baseTable = new kony.appfoundation.Table(model.entityName);
		var deleteQuery = new kony.appfoundation.DeleteQuery(baseTable);
		var criteria = new kony.appfoundation.Match(baseTable,model.entityDetails.primaryKeyName, kony.appfoundation.MatchType.EQUALS,id);
		
		deleteQuery.addCriteria(criteria);
		
		var whereClause = constructWhereClause();
		function constructWhereClause() {
			var whereClause = "";
			if (deleteQuery.getCriterias() !== null
					&& deleteQuery.getCriterias() !== undefined
					&& deleteQuery.getCriterias().length > 0) {
				whereClause = whereClause + "WHERE ";
				try {
					whereClause = whereClause
							+ kony.appfoundation.Utils.appendListToQuery(deleteQuery
									.getCriterias(), " AND ", 0);
				} catch (e) {
					throw e;
				}
			}
			return whereClause;
		}
		// The where clause by default prefixes columns with table or
		// alias
		// name.
		// We should remove that prefix before passing the where clause
		// to
		// .remove method.
				/*if (whereClause !== null && whereClause !== undefined
				&& whereClause !== "") {
			var prefixString = (deleteQuery.getBaseTable().getAlias() !== null && deleteQuery
					.getBaseTable().getAlias() !== undefined) ? deleteQuery
					.getBaseTable().getAlias()
					: deleteQuery.getBaseTable().getName();
			whereClause = kony.appfoundation.Utils.replaceAllRegEx(prefixString + ".", "",
					whereClause);
				}*/
		/*var dbName = kony.appfoundation.getDbName();
		kony.sync.single_delete_execute(dbName, deleteQuery
				.getBaseTable().getName(), whereClause,
				delSuccCallback, delErrCallback, true, false, true);
		*/
		function delSuccCallback(result) {
			var response = {};
			if (result !== null && result !== undefined
					&& result.hasOwnProperty("deletedRecords")) {
				response.deletedRecords = result.deletedRecords;
			}
			var deleteRecordEndTS = new Date();
                        kony.appfoundation.Utils.perftimecal("deleteRecord >>","deleteRecord end >>",deleteRecordTS,deleteRecordEndTS);
			if (typeof (successCallback) == 'function') {
				successCallback(response);
			}
		}
		function delErrCallback(errorMsg) {
			var errorStr = kony.appfoundation.DataAccessAppsExceptionCode.CD_ERROR_UNKNOWN_DB_ERROR
					+ ":"
					+ kony.appfoundation.DataAccessAppsExceptionCode.MSG_ERROR_UNKNOWN_DB_ERROR;
			kony.appfoundation.log.debug("inside error callback", errorStr)
			if (typeof (errorCallback) == 'function') {
				errorCallback(errorStr);
			}
		}
	},
	downloadClientArtifact : function() {
		throw "This method is not implemented";
	},
	executeSelectQuery : function(queryStr, succCallback, errCallback) {
	var executeSelectQueryTS = new Date(); 
		kony.sync.single_select_execute(kony.appfoundation.getDbName(),queryStr,null,successCallback, errorCallback);
		
		function successCallback(response){
		var executeSelectQueryEndTS = new Date();
                    kony.appfoundation.Utils.perftimecal("executeSelectQuery "+queryStr+" >>","executeSelectQuery end >>",executeSelectQueryTS,executeSelectQueryEndTS);
			if (typeof (succCallback) == 'function') {
					succCallback(response);
			}
		}
		
		function errorCallback(error){
			var eMsg = kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_FAILED_TO_QUERY_DATA;
			if (typeof (errCallback) == 'function') {
				if(error.errorMessage){
					eMsg = eMsg + " : "+error.errorMessage;		
				}
				errCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_FAILED_TO_QUERY_DATA,eMsg));
			}
		}
	},
	getRelationData : function(entityName, entityKeyName, entityKeyValue,
			relation, uiFields, syncRelatedDataSuccess, syncRelatedDataError,queryObj) {
		if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(entityName,"","retrieve")){
			//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_READ_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_READ_PERMISSION.replace("{}",entityName)).alert(true);
			syncRelatedDataError(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_READ_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_READ_PERMISSION.replace("{}",entityName)));
			return;
		}
		if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(relation["entityName"],"","retrieve")){
			//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_READ_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_READ_PERMISSION.replace("{}",relation["entityName"])).alert(true);
			syncRelatedDataError(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_READ_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_READ_PERMISSION.replace("{}",relation["entityName"])));
			return;
		}
		fetchEntityRelatedData(entityName, entityKeyName, entityKeyValue,
				relation, uiFields, syncRelatedDataSuccess,
				syncRelatedDataError,queryObj);
		function fetchEntityRelatedData(entityName, entityKeyName, entityKeyValue, relation, uiFields, success, error,queryObj){
			var childTableName = relation["entityName"];
			var childReferencingField = relation["referencingField"];
			var relationShipType = relation["relationshipType"];
			
			var dbName = kony.appfoundation.getDbName();
			var syncSelectQuery = "";
			var selectQuery = null;

			if(relationShipType == "ManyToMany"){
				/*
				 * Sample Query For Many to many relationship:
				 * Assuming parent entity as Account & child entity as Address
				 * 
				 * SELECT address.id FROM address INNER JOIN account_address ON address.id = account_address.address_id
				 * INNER JOIN account ON account_address.account_id = account.id WHERE account.id = "<some_account_id>"; 
				 * 
				 */
				var junctionTableName = relation["junctionTableName"];
				var relationShipName =  relation["relationshipName"];
				
				// any name ending with __k
				var endsWith = "__k";
				var customRegex = new RegExp("[.]*[" + endsWith + "]$");
				var isCustomRelation = relationShipName.search(customRegex) == -1 ? false : true;
				var isCustomEntityTable = entityName.search(customRegex) == -1 ? false : true;
				var isCustomChildTable = childTableName.search(customRegex) == -1 ? false : true;
				var junctionTableChildRefName = "";
				var junctionTableParentRefName = "";
				
				// Column name should not contain "__" (double under score)
				if(!isCustomRelation){
					junctionTableChildRefName = childTableName + "_" + entityKeyName;
					junctionTableParentRefName = entityName + "_" + entityKeyName;
					junctionTableParentRefName = kony.appfoundation.Utils.replaceAll(junctionTableParentRefName,"__","_");
					junctionTableChildRefName = kony.appfoundation.Utils.replaceAll(junctionTableChildRefName,"__","_");
				}else{
					var junctionTableChildRefName = "";
					var junctionTableParentRefName = "";
					
					if(isCustomChildTable){
						var index = childTableName.lastIndexOf(endsWith);
						junctionTableChildRefName = childTableName.substr(0, index);
						junctionTableChildRefName = junctionTableChildRefName + "_k" + "_" + entityKeyName;
					}else{
						junctionTableChildRefName = childTableName + "_" + entityKeyName;
					}
						
					if(isCustomEntityTable){
						var index = entityName.lastIndexOf(endsWith);
						junctionTableParentRefName = entityName.substr(0, index);
						junctionTableParentRefName = junctionTableParentRefName + "_k" + "_" + entityKeyName;
					}else{
						junctionTableParentRefName = entityName + "_" + entityKeyName;
					}
					junctionTableParentRefName = kony.appfoundation.Utils.replaceAll(junctionTableParentRefName,"__","_");
					junctionTableParentRefName += endsWith;
					junctionTableChildRefName = kony.appfoundation.Utils.replaceAll(junctionTableChildRefName,"__","_");
					junctionTableChildRefName += endsWith;
				}
				// construct the selectQuery builder to generate the select query SQL
				var childTable = new kony.appfoundation.Table(childTableName);
				selectQuery = new kony.appfoundation.SelectQuery(childTable);
				// var column = new kony.appfoundation.Column(table, "Id");
				var junctionTable = new kony.appfoundation.Table(junctionTableName,null,true);
				var childTableKey = new kony.appfoundation.Column(childTable, entityKeyName);
				var junctionTableChildRef = new kony.appfoundation.Column(junctionTable, junctionTableChildRefName);
				var childJunctionJoin = new kony.appfoundation.Join(junctionTable, childTableKey, junctionTableChildRef, "INNER");
				var parentTable = new kony.appfoundation.Table(entityName);
				var junctionTableParentRef = new kony.appfoundation.Column(junctionTable, junctionTableParentRefName);
				var parentTableKey = new kony.appfoundation.Column(parentTable, entityKeyName);
				var junctionParentJoin = new kony.appfoundation.Join(parentTable, junctionTableParentRef, parentTableKey, "INNER");
				
				selectQuery.addJoin(childJunctionJoin);
				selectQuery.addJoin(junctionParentJoin);
				
				var childTableIdColumn = new kony.appfoundation.Column(childTable, entityKeyName);
				childTableIdColumn.setAlias("result_value");
				selectQuery.addColumn(childTableIdColumn);
				var parentTableIdColumn = new kony.appfoundation.Column(parentTable, entityKeyName);
				var whereCondition = new kony.appfoundation.Match(parentTableIdColumn, kony.appfoundation.MatchType.EQUALS, entityKeyValue);
				selectQuery.addCriteria(whereCondition);
				if(queryObj){
					var criterias = queryObj.getCriterias();
					
					for(i=0 ; i<criterias.length ; i += 1){
						selectQuery.addCriteria(criterias[i]);
					}
					
					if(queryObj.getLimit() !== undefined && queryObj.getLimit() !== null)
						selectQuery.setLimit(queryObj.getLimit());
						
					if(queryObj.getSkip() !== undefined && queryObj.getSkip() !== null)
						selectQuery.setSkip(queryObj.getSkip());
				}
					
				if(uiFields !== undefined && uiFields !== null)
				{
					var column;
					for(var i=0; i < uiFields.length ; i++){
						column = new kony.appfoundation.Column(childTable, uiFields[i]);
						selectQuery.addColumn(column);
					}
				}
				
			}else{
				/*
				 * Sample Query For One to many relationship:
				 * Assuming parent entity as Account & child entity as Address
				 * 
				 * SELECT address.id, address.accountId FROM address INNER JOIN account ON address.accountId = account.id
				 * WHERE account.id = <some_account_id>
				 */
				
				// Construct the selectQuery builder to generate the select query SQL
				var childTable = new kony.appfoundation.Table(childTableName);
				var childTableIdColumn = new kony.appfoundation.Column(childTable, entityKeyName);
				var childTableRefField = new kony.appfoundation.Column(childTable, childReferencingField);
				
				var parentTable = new kony.appfoundation.Table(entityName);
				var parentTableIdColumn = new kony.appfoundation.Column(parentTable, entityKeyName);
				selectQuery = new kony.appfoundation.SelectQuery(childTable);
				selectQuery.addColumn(childTableIdColumn);
				selectQuery.addColumn(childTableRefField);
				var childParentJoin = new kony.appfoundation.Join(parentTable, childTableRefField, parentTableIdColumn, "INNER");
				selectQuery.addJoin(childParentJoin);
				var criteria = new kony.appfoundation.Match(parentTableIdColumn, kony.appfoundation.MatchType.EQUALS, entityKeyValue);
				selectQuery.addCriteria(criteria);
				if(queryObj){
					var criterias = queryObj.getCriterias();
					
					for(i=0 ; i<criterias.length ; i += 1){
						selectQuery.addCriteria(criterias[i]);
					}
					
					if(queryObj.getLimit() !== undefined && queryObj.getLimit() !== null)
						selectQuery.setLimit(queryObj.getLimit());
						
					if(queryObj.getSkip() !== undefined && queryObj.getSkip() !== null)
						selectQuery.setSkip(queryObj.getSkip());
				}
					
				if(uiFields !== undefined && uiFields !== null)
				{
					var column;
					for(var i=0; i < uiFields.length ; i++){
						column = new kony.appfoundation.Column(childTable, uiFields[i]);
						selectQuery.addColumn(column);
					}
				}				
			}
			
			if(selectQuery === null || selectQuery === undefined){
				var response = [];
				return response;
			}
			selectQuery.toString(toStringSuccessCallback, toStringErrorCallback, kony.appfoundation.Providers.SYNC);
			function toStringSuccessCallback(response){
				syncSelectQuery = response;
				var getRelationDataTS = new Date();
				kony.appfoundation.log.info("related entities query syncSelectQuery .... "+syncSelectQuery)
				kony.sync.single_select_execute(dbName, syncSelectQuery, null, syncFetchRelationSuccess, syncFetchRelationError);
				
				function syncFetchRelationSuccess(response){
					/*var responseJSONArray = [];
					if(response!=null){
						for(var i in response){
							var responseObject = response[i];
							var responseJSONObject = {};
							// include all the child fields.
							responseJSONObject[entityKeyName] = responseObject["result_value"];
							responseJSONArray.push(responseJSONObject);
						}
					}*/
					var getRelationDataEndTS = new Date();
                        kony.appfoundation.Utils.perftimecal("Get Relation data "+ syncSelectQuery +" >>","Get Relation data end >>",getRelationDataTS,getRelationDataEndTS);
					if(typeof(success) == 'function')
						success(response);
				}
				
				function syncFetchRelationError(error){
					kony.appfoundation.genericSyncError(error, kony.appfoundation.syncFetchRelatedEntitiesErrorCode, 
											kony.appfoundation.syncFetchRelatedEntitiesErrorMessage, error);
				}
			}
			
			function toStringErrorCallback(error){
				kony.appfoundation.genericSyncError(error, kony.appfoundation.syncFetchRelatedEntitiesErrorCode, 
											kony.appfoundation.syncFetchRelatedEntitiesErrorMessage, error);
			}
		}
	},
	associate : function(pkName, parent,parentId,child,payload,relation, relationshipname,successcallback,errorcallback){
		//associate is modifying the parent in a way by adding a child to its children.
		if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(parent,"","create")){
			errorcallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_CREATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_CREATE_PERMISSION.replace("{}",parent)));
			return;
		}
		
		if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(child,"","create")){
			errorcallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_CREATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_CREATE_PERMISSION.replace("{}",child)));
			return;
		}
		var result = kony.appfoundation.validateFormDataModel(payload, true, child); 
		if(!result.isValid){
			errorcallback(result);
			return;
		}
		var syncProvider = this;
		associateRecords(pkName, parent,parentId,child,payload,relation, relationshipname,successcallback,errorcallback);
		function associateRecords(pkName, parent,parentId,child,payload,relation, relationshipName,successcallback,errorcallback){
			// 1) prepare model object to be passed to the create entity method.
			var childModel = new kony.appfoundation.Model(child);
			
			childModel.entityDetails = new kony.appfoundation.EntityDetails(child, null, null, pkName, null, null, null);
			
			var fields = {};
			var columns = payload["columnValueDto"];
			for(var i in columns){
				var column = columns[i];
				var columnName = column["columnName"];
				var value = column["val"];
				
				fields[columnName] = value;
			}
			
			childModel["fields"] = fields;
			
			var createdChildRecordId = "";

			// (2) Make call to sync create entity to first create the child record
			// on success, read the created child record id in a variable.
			syncProvider.create(childModel, syncCreateChildRecordSuccess, syncCreateChildRecordError);
			
			function syncCreateChildRecordSuccess(response){
				createdChildRecordId = response[pkName];		
				// (3) Now we need to add a record in the junction table.
				// For that first fetch the column names in junction table corresponding to parent and child table.
				var endsWith = "__k";
				var customRegex = new RegExp("[.]*[" + endsWith + "]$");
				var isCustomRelation = relationshipName.search(customRegex) == -1 ? false : true;
				var isCustomEntityTable = parent.search(customRegex) == -1 ? false : true;
				var isCustomChildTable = child.search(customRegex) == -1 ? false : true;
				
				var junctionTableName = relation["junctionTableName"];
				var junctionTableChildRefName = "";
				var junctionTableParentRefName = "";
				
				// Column name should not contain "__" (double under score)
				if(!isCustomRelation){
					junctionTableChildRefName = child + "_" + pkName;
					junctionTableParentRefName = parent + "_" + pkName;
					junctionTableParentRefName = kony.appfoundation.Utils.replaceAll(junctionTableParentRefName,"__","_");
					junctionTableChildRefName = kony.appfoundation.Utils.replaceAll(junctionTableChildRefName,"__","_");
				}else{
					if(isCustomChildTable){
						var index = child.lastIndexOf(endsWith);
						junctionTableChildRefName = child.substr(0, index);
						junctionTableChildRefName = junctionTableChildRefName + "_k" + "_" + pkName;
					}else{
						junctionTableChildRefName = child + "_" + pkName;
					}
						
					if(isCustomEntityTable){
						var index = parent.lastIndexOf(endsWith);
						junctionTableParentRefName = parent.substr(0, index);
						junctionTableParentRefName = junctionTableParentRefName + "_k" + "_" + pkName;
					}else{
						junctionTableParentRefName = parent + "_" + pkName;
					}
					junctionTableParentRefName = kony.appfoundation.Utils.replaceAll(junctionTableParentRefName,"__","_");
					junctionTableParentRefName += endsWith;
					junctionTableChildRefName = kony.appfoundation.Utils.replaceAll(junctionTableChildRefName,"__","_");
					junctionTableChildRefName += endsWith;
				}
				
				
				// (4) Next prepare a model object for junction table to be passed to sync create entity.
				var junctionTableModel = new kony.appfoundation.Model(junctionTableName);
				
				junctionTableModel.entityDetails = new kony.appfoundation.EntityDetails(junctionTableName, null, null, pkName, null, null, null);
				var junctionTableFields = {};
				junctionTableFields[junctionTableChildRefName] = createdChildRecordId;
				junctionTableFields[junctionTableParentRefName] = parentId;
				
				junctionTableModel["fields"] = junctionTableFields;
				
				junctionTableModel.entityDetails["isjunction"] = true;
				// (5) Call sync create entity for the junction table.
				syncProvider.create(junctionTableModel, syncCreateJunctionRecordSuccess, syncCreateJunctionRecordError);
				
				function syncCreateJunctionRecordSuccess(response){
					if(typeof(successcallback) == 'function'){
						successcallback(response);
					}		
				}
			
				function syncCreateJunctionRecordError(errorParams){
					if(typeof(errorcallback) == 'function'){
						errorcallback(errorParams);
					}
				}
			}
			
			function syncCreateChildRecordError(errorParams){
				if(typeof(errorcallback) == 'function'){
					errorcallback(errorParams);
				}
			}
		}

	},
	associateexistingrecord : function(pkName, parent,parentId,child,childId,relation,relationshipname,successcallback,errorcallback){
		//Keeping in sync with server code.
		if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(parent,"","create")){
			errorcallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_CREATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_CREATE_PERMISSION.replace("{}",parent)));
			return;
		}
		
		if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(child,"","create")){
			errorcallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_CREATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_CREATE_PERMISSION.replace("{}",child)));
			return;
		}
		var syncProvider = this;
		associateexistingRecords(pkName, parent,parentId,child,childId,relation,relationshipname,successcallback,errorcallback);
		function associateexistingRecords(pkName, parent,parentId,child,childId,relation,relationshipName,successcallback,errorcallback){
			// 1) prepare model object to be passed to the create entity method.
			
			var entityDetails = {};
			entityDetails.primaryKeyName = pkName;
			
			
			var createdChildRecordId = childId;	
				
				// (3) Now we need to add a record in the junction table.
				// For that first fetch the column names in junction table corresponding to parent and child table.
				var endsWith = "__k";
				var customRegex = new RegExp("[.]*[" + endsWith + "]$");
				var isCustomRelation = relationshipName.search(customRegex) == -1 ? false : true;
				var isCustomEntityTable = parent.search(customRegex) == -1 ? false : true;
				var isCustomChildTable = child.search(customRegex) == -1 ? false : true;
				
				var junctionTableName = relation["junctionTableName"];
				var junctionTableChildRefName = "";
				var junctionTableParentRefName = "";
				
				// Column name should not contain "__" (double under score)
				if(!isCustomRelation){
					junctionTableChildRefName = child + "_" + pkName;
					junctionTableParentRefName = parent + "_" + pkName;
					junctionTableParentRefName = kony.appfoundation.Utils.replaceAll(junctionTableParentRefName,"__","_");
					junctionTableChildRefName = kony.appfoundation.Utils.replaceAll(junctionTableChildRefName,"__","_");
				}else{
					if(isCustomChildTable){
						var index = child.lastIndexOf(endsWith);
						junctionTableChildRefName = child.substr(0, index);
						junctionTableChildRefName = junctionTableChildRefName + "_k" + "_" + pkName;
					}else{
						junctionTableChildRefName = child + "_" + pkName;
					}
						
					if(isCustomEntityTable){
						var index = parent.lastIndexOf(endsWith);
						junctionTableParentRefName = parent.substr(0, index);
						junctionTableParentRefName = junctionTableParentRefName + "_k" + "_" + pkName;
					}else{
						junctionTableParentRefName = parent + "_" + pkName;
					}
					junctionTableParentRefName = kony.appfoundation.Utils.replaceAll(junctionTableParentRefName,"__","_");
					junctionTableParentRefName += endsWith;
					junctionTableChildRefName = kony.appfoundation.Utils.replaceAll(junctionTableChildRefName,"__","_");
					junctionTableChildRefName += endsWith;
				}
				
				// (4) Next prepare a model object for junction table to be passed to sync create entity.
				var junctionTableModel = new kony.appfoundation.Model(junctionTableName);
				
				junctionTableModel.entityDetails = new kony.appfoundation.EntityDetails(junctionTableName, null, null, pkName, null, null, null);
				var junctionTableFields = {};
				junctionTableFields[junctionTableChildRefName] = createdChildRecordId;
				junctionTableFields[junctionTableParentRefName] = parentId;
				junctionTableModel.entityDetails["isjunction"] = true;
				junctionTableModel["fields"] = junctionTableFields;
				
			
				// (5) Call sync create entity for the junction table.
				syncProvider.create(junctionTableModel, syncCreateJunctionRecordSuccess, syncCreateJunctionRecordError);
				
				function syncCreateJunctionRecordSuccess(response){
					if(typeof(successcallback) == 'function'){
						successcallback(response);
					}		
				}
			
				function syncCreateJunctionRecordError(errorParams){
					if(typeof(errorcallback) == 'function'){
						errorcallback(errorParams);
					}
				}
			
			
		}

	},
	dissociate : function(pkName, parent,parentId,child,childId,relation, relationshipname, successcallback, errorcallback){
		//Keeping in sync with server code.
		if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(parent,"","delete")){
			//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_UPDATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_UPDATE_PERMISSION.replace("{}",parent)).alert(true);
			errorcallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_DELETE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_DELETE_PERMISSION.replace("{}",parent)));
			return;
		}
		if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(child,"","delete")){
			//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_UPDATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_UPDATE_PERMISSION.replace("{}",parent)).alert(true);
			errorcallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_DELETE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_DELETE_PERMISSION.replace("{}",child)));
			return;
		}
		dissociateRecords(pkName, parent,parentId,child,childId,relation, relationshipname, successcallback, errorcallback);
		function dissociateRecords(pkName, parent, parentId, child, childId, relation, relationshipName, successcallback, errorcallback){
			// simply delete the record from the junction table.
			var dbName = kony.appfoundation.getDbName();
			var endsWith = "__k";
			var customRegex = new RegExp("[.]*[" + endsWith + "]$");
			var isCustomRelation = relationshipName.search(customRegex) == -1 ? false : true;
			var isCustomEntityTable = parent.search(customRegex) == -1 ? false : true;
			var isCustomChildTable = child.search(customRegex) == -1 ? false : true;
			
			var junctionTableName = relation["junctionTableName"];
			var junctionTableChildRefName = "";
			var junctionTableParentRefName = "";
			
			// Column name should not contain "__" (double under score)
			if(!isCustomRelation){
				junctionTableChildRefName = child + "_" + pkName;
				junctionTableParentRefName = parent + "_" + pkName;
				junctionTableParentRefName = kony.appfoundation.Utils.replaceAll(junctionTableParentRefName,"__","_");
				junctionTableChildRefName = kony.appfoundation.Utils.replaceAll(junctionTableChildRefName,"__","_");
			}else{
				if(isCustomChildTable){
					var index = child.lastIndexOf(endsWith);
					junctionTableChildRefName = child.substr(0, index);
					junctionTableChildRefName = junctionTableChildRefName + "_k" + "_" + pkName;
				}else{
					junctionTableChildRefName = child + "_" + pkName;
				}
					
				if(isCustomEntityTable){
					var index = parent.lastIndexOf(endsWith);
					junctionTableParentRefName = parent.substr(0, index);
					junctionTableParentRefName = junctionTableParentRefName + "_k" + "_" + pkName;
				}else{
					junctionTableParentRefName = parent + "_" + pkName;
				}
				junctionTableParentRefName = kony.appfoundation.Utils.replaceAll(junctionTableParentRefName,"__","_");
				junctionTableParentRefName += endsWith;
				junctionTableChildRefName = kony.appfoundation.Utils.replaceAll(junctionTableChildRefName,"__","_");
				junctionTableChildRefName += endsWith;				
			}
			// Construct the deleteQuery builder to generate the delete query
			var junctionTable = new kony.appfoundation.Table(junctionTableName);
			var deleteQuery = new kony.appfoundation.DeleteQuery(junctionTable);
			var parentRefCol = new kony.appfoundation.Column(junctionTable, junctionTableParentRefName);
			var childRefCol = new kony.appfoundation.Column(junctionTable, junctionTableChildRefName);
			
			var parentCondition = new kony.appfoundation.Match(parentRefCol, kony.appfoundation.MatchType.EQUALS, parentId);
			var childCondition = new kony.appfoundation.Match(childRefCol, kony.appfoundation.MatchType.EQUALS, childId);
			
			deleteQuery.addCriteria(parentCondition);
			deleteQuery.addCriteria(childCondition);
			
			var whereClause = buildWhereClause();
			function buildWhereClause() {
				var whereClause = "";
				if (deleteQuery.getCriterias() !== null
						&& deleteQuery.getCriterias() !== undefined
						&& deleteQuery.getCriterias().length > 0) {
					whereClause = whereClause + "WHERE ";
					try {
						whereClause = whereClause
								+ kony.appfoundation.Utils.appendListToQuery(deleteQuery
										.getCriterias(), " AND ", 0);
					} catch (e) {
						throw e;
					}
				}
				return whereClause;
			}
			var dissociateRecordTS = new Date();
			kony.sync.single_delete_execute(dbName, deleteQuery.getBaseTable().getName(), whereClause,
				syncDissociateSuccess, syncDissociateError, true, false, true);
			
			function syncDissociateSuccess(response){
			var dissociateRecordEndTS = new Date();
              kony.appfoundation.Utils.perftimecal("Disassociate records >>","Disassociate records end >>",dissociateRecordTS,dissociateRecordEndTS);
				if(typeof(successcallback) == 'function'){
					successcallback(response);
				}
			}
			
			function syncDissociateError(error){
				if(typeof(errorcallback) == 'function'){
					errorcallback(error);
				}
			}
		}

	},
	executeGeneratedSQLQuery: function(selectQueryObj, generatedsqlquery, sucCallBack, errCallBack){
		
		if(selectQueryObj){
			selectQueryObj.toString(sscallback,errcallback);
			function sscallback(queryStr){
				kony.print("query framed by uiruntime is "+ queryStr);
				var selectQueryString = queryStr;
				var selectClause = "";
				var whereClause = "";
				var endClause = "";
				var whrindex = selectQueryString.indexOf("WHERE");
				var whrEndIndex = -1; 
				if(whrindex != -1){
					selectClause = selectQueryString.substring(0, whrindex);	
				}
				
				
				// generatedsqlquery can not have any columns specified as the api supports queries starting with $filters only.
				//we only are considering the select and filters specified by the users in their widget queries.  
				//find the end index of where clause to append the criterias mentioned in the user defined query(generatedsqlquery).
				var groupbyIndex = selectQueryString.indexOf("GROUP BY");
				var orderIndex = selectQueryString.indexOf("ORDER BY");
				var limitIndex = selectQueryString.indexOf("LIMIT");
				var offsetIndex = selectQueryString.indexOf("OFFSET");
				if(groupbyIndex != -1){
					whrEndIndex = groupbyIndex;	
				} else if(orderIndex != -1){
					whrEndIndex = orderIndex;
				} else if(limitIndex != -1){
					whrEndIndex = limitIndex;
				} else if(offsetIndex != -1){
					whrEndIndex = offsetIndex;
				}
				
				//to retain the groupby,offset or other parameters.
				if(whrindex == -1 && whrEndIndex != -1){
					selectClause = selectQueryString.substring(0,whrEndIndex);
					endClause = selectQueryString.substring(whrEndIndex);
				}else if(whrindex == -1 && whrEndIndex == -1){ 
					//selectClause is the complete part of query.
					selectClause = selectQueryString;
				}else if(whrindex != -1 && whrEndIndex == -1){
					//the parameters like group,order, etc.. are not present.
					whereClause = selectQueryString.substring(whrindex);
				}else if(whrindex != -1 && whrEndIndex != -1){
					whereClause = selectQueryString.substring(whrindex,whrEndIndex);
					endClause = selectQueryString.substring(whrEndIndex);
				}
				
				var genWhrIndex = generatedsqlquery.indexOf("WHERE ");
				var genWhrClause = "";
				var criteriaIndex = -1;
				if(genWhrIndex != -1){
					criteriaIndex = genWhrIndex + 6;
					var genWhrEndIndex = -1;
					
					var groupbyIndex = generatedsqlquery.indexOf("GROUP BY");
					var orderIndex = generatedsqlquery.indexOf("ORDER BY");
					var limitIndex = generatedsqlquery.indexOf("LIMIT");
					var offsetIndex = generatedsqlquery.indexOf("OFFSET");
					if(groupbyIndex != -1){
						genWhrEndIndex = groupbyIndex;	
					} else if(orderIndex != -1){
						genWhrEndIndex = orderIndex;
					} else if(limitIndex != -1){
						genWhrEndIndex = limitIndex;
					} else if(offsetIndex != -1){
						genWhrEndIndex = offsetIndex;
					}
				}
				
				if(genWhrIndex != -1 && genWhrEndIndex == -1){
					//the parameters like group,order, etc.. are not present.
					genWhrClause = generatedsqlquery.substring(criteriaIndex);
				}else if(genWhrIndex != -1 && genWhrEndIndex != -1){
					genWhrClause = generatedsqlquery.substring(criteriaIndex,genWhrEndIndex);
				}
					
				if(genWhrClause != "" && whereClause != "")
					whereClause = whereClause + " AND " + genWhrClause;
				else if(whereClause == "" && genWhrClause != "")
					whereClause = " WHERE " + genWhrClause;
				else if(whereClause == "" && genWhrClause == "")
					whereClause= "";
				
				
				var finalSqlQuery = selectClause + " " + whereClause + " " + endClause;
				
				kony.appfoundation.log.info("final query combined is "+ finalSqlQuery);
				return syncProvider.executeSelectQuery(finalSqlQuery, sucCallBack, errCallBack);
			}
			
			function errcallback(error){
				kony.appfoundation.log.error("error in the tostring call for generated query ---- ");
				errCallBack(error);
			}
		}
		else{
			return syncProvider.executeSelectQuery(generatedsqlquery, sucCallBack, errCallBack);	
		}	
	}
});

kony.appfoundation.mockSyncProvider = Class(
		kony.appfoundation.DataProvider,
		{
			constructor : function(sessiontoken) {
				this.$class.$super.call(this, sessionToken);

			},
			fetch : function(selectQuery, successCallback,
					errorCallback) {
				// Passing an argument to selectQuery's toString function to know if the call is coming from 'mockSyncProvider'
				// or 'konySyncProvider'
				var query = null;
				selectQuery.toString(toStringSuccessCallback, toStringErrorCallback, kony.appfoundation.Providers.MOCK);
				function toStringSuccessCallback(responseQuery){
					query = responseQuery;
					syncMock.selectRecords(query, succCallback,
						errCallback);
				function succCallback(response) {
					if (typeof (successCallback) == 'function')
						successCallback(response);
				}
				function errCallback() {
					if (typeof (errorCallback) == 'function')
						errorCallback("Error occurred while fetching the records !!!");
				}
			}
				function toStringErrorCallback(error){
					if (typeof (errorCallback) == 'function')
						errorCallback("Error occurred while constructing the select query with error message '"+error.message+"'");
				}
			},
			create : function(model, successCallback, errorCallback) {
				var result = kony.appfoundation.validateFormDataModel(model, true); 
				if(!result.isValid){
					errorCallback(result);
					return;
				}
				var baseTable = new kony.appfoundation.Table(model.entityName);
			    var insertQuery = new kony.appfoundation.InsertQuery(baseTable);
				for (var columnName in model.fields) {
					if (model.fields.hasOwnProperty(columnName)) {
						
						if (columnName.toUpperCase() !== model.entityDetails.primaryKeyName.toUpperCase()) {
							var col = new kony.appfoundation.Column(baseTable,columnName); 
							insertQuery.addColumn(col,model.get(columnName));
						}
					}
				}
				
				var valid = kony.appfoundation.Utils.validateInput(insertQuery.listColumns(),
						insertQuery.listValues());
				if (valid) {
					syncMock.createRecord(insertQuery.toString(), insertQuery
							.listValues(), createSuccCallback,
							createErrCallback);
					function createSuccCallback(response) {
						if (typeof (successCallback) == 'function') {
							successCallback(response);
						}
					}
					function createErrCallback(errMessage) {
						if (typeof (errorCallback) == 'function') {
							errorCallback(errMessage);
						}
					}
				} else {
					errorCallback(kony.appfoundation.DataAccessAppsExceptionCode.CD_ERROR_INSERT
							+ ":"
							+ kony.appfoundation.DataAccessAppsExceptionCode.MSG_ERROR_INSERT);
				}

			},
			update : function(model,  successCallback, errorCallback) {
				var result = kony.appfoundation.validateFormDataModel(model, false); 
				if(!result.isValid){
					errorCallback(result);
					return;
				}
				var baseTable = new kony.appfoundation.Table(model.entityName);
				var updateQuery = new kony.appfoundation.UpdateQuery(baseTable);
				var valuesTable = {};
				for (var columnName in model.fields) {
					if (model.fields.hasOwnProperty(columnName)) {
						if (columnName.toUpperCase() !== model.entityDetails.primaryKeyName.toUpperCase()) {
							var col = new kony.appfoundation.Column(baseTable,columnName);
							updateQuery.addColumn(col,model.fields[columnName]);
						}
					}
				}
				
				var values = [];
				for ( var prop in updateQuery.getColumnValueMap()) {
					if (updateQuery.getColumnValueMap().hasOwnProperty(prop)) {
						values.push(updateQuery.getColumnValueMap()[prop]);
					}
				}
				
				var id = "";
				if (model.fields[model.entityDetails.primaryKeyName] !== null
						&& model.fields[model.entityDetails.primaryKeyName] !== undefined) {
					id = model.fields[model.entityDetails.primaryKeyName];
				}
				var criteria = new kony.appfoundation.Match(baseTable,model.entityDetails.primaryKeyName, kony.appfoundation.MatchType.EQUALS,id);
				updateQuery.addCriteria(criteria);
				
				syncMock.updateRecord(updateQuery, values, updateSuccCallback,
						updateErrCallback);
				function updateSuccCallback(response) {
					if (typeof (successCallback) == 'function') {
						successCallback(response);
					}
				}
				function updateErrCallback(error) {
					if (typeof (errorCallback) == 'function') {
						errorCallback(error);
					}
				}
			},
			read : function(entityName, id) {
				throw "This method is not implemented."
			},
			deleteRecord : function(model, id, syncDeleteSuccess,
					syncDeleteError) {
				var baseTable = new kony.appfoundation.Table(model.entityName);
				var deleteQueryObj = new kony.appfoundation.DeleteQuery(baseTable);
				kony.appfoundation.log.info("value of id is "+id)
				if(id != undefined && id != null && id !=""){
					var criteria = new kony.appfoundation.Match(baseTable,model.entityDetails.primaryKeyName, kony.appfoundation.MatchType.EQUALS,id);
					deleteQueryObj.addCriteria(criteria);	
				}
				
						
				var deleteQuery = deleteQueryObj.toString();
				kony.appfoundation.log.info("deleteQuery string is "+deleteQuery)
				kony.appfoundation.log.info("type of syncmock deleteRecord fn. in saasfnmodel --- "+ 
							typeof syncMock.deleteRecord)
				syncMock.deleteRecord(deleteQuery, [], delSuccCallback,	delErrCallback);
				function delSuccCallback(response) {
					if (typeof (syncDeleteSuccess) == 'function') {
						syncDeleteSuccess(response);
					}
				}
				function delErrCallback(error) {
					if (typeof (syncDeleteError) == 'function') {
						syncDeleteError(error);
					}
				}
			},
			executeSelectQuery: function(query,successHandler,errorHandler){
				syncMock.selectRecords(query, succCallback,errCallback);
				function succCallback(response) {
					if (typeof (successHandler) == 'function') {
						successHandler(response);
					}
				}
				function errCallback(error) {
					if (typeof (errorHandler) == 'function') {
						errorHandler(errorCallback);
					}
				}
			},
			getRelationData : function(entityName, entityKeyName, entityKeyValue,relation, uiFields, successcallback, errorcallback,criteriaObj) {
				throw "This method is not implemented."
			},
			associate : function(pkName, parent,parentId,child,payload,relation, relationshipname,successcallback,errorcallback){
				//This method is not implemented
				throw "This method is not implemented."
			},
			associateexistingrecord : function(pkName, parent,parentId,child,childId,relation, relationshipname,successcallback,errorcallback){
				//This method is not implemented
				throw "This method is not implemented."
			},
			dissociate : function(pkName, parent,parentId,child,childId,relation, relationshipname, successcallback, errorcallback){
				//This method is not implemented
				throw "This method is not implemented."
			},
			executeGeneratedSQLQuery: function(selectQueryObj, generatedsqlquery, sucCallBack, errCallBack){
				throw "This method is not implemented."
			}
		});


kony.appfoundation.dataRestProvider = Class(
		kony.appfoundation.DataProvider,
		{
			constructor : function(sessionToken) {
				this.$class.$super.call(this, sessionToken);

			},
			create : function(model, createServiceCallback,
					serviceErrorCallback) {
				if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(model.entityName,"","create")){
					//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_CREATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_CREATE_PERMISSION.replace("{}",model.entityName)).alert(true);
					serviceErrorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_CREATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_CREATE_PERMISSION.replace("{}",model.entityName)));
					return;
				}
				var result = kony.appfoundation.validateFormDataModel(model, true); 
				if(!result.isValid){
					serviceErrorCallback(result);
					return;
				}
				model = result.finalmodel;	
				var colValDto;
				var colValueList = [];
				for ( var key in model.fields) {
					if (model.fields.hasOwnProperty(key)) {
						if (key.toUpperCase() !== model.entityDetails.primaryKeyName) {
							colValDto = new kony.appfoundation.columnValueDto(key,
									model.fields[key]);
							colValueList.push(colValDto);
						}
					}
				}
				var inputData = new kony.appfoundation.insertInput(colValueList);
				var headers = {
					Accept : "application/json",
					session_token : this.sessionToken.token,
					"Content-Type" : "application/json"
				};
				if(!kony.appfoundation.constants["ISCLOUD"]){
					headers["tenant"] = this.sessionToken.tenant;
				}
				kony.appfoundation.theAjaxProvider.get(kony.appfoundation.constants.DATA_ENDPOINT
						+ model.entityName, kony.appfoundation.constants.HTTP_METHOD_POST,
						headers, createServiceCallback, serviceErrorCallback,
						inputData);
			},

			update : function(model, updateServiceCallback,
					serviceErrorCallback) {
				if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(model.entityName,"","update")){
					//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_UPDATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_UPDATE_PERMISSION.replace("{}",model.entityName)).alert(true);
					serviceErrorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_UPDATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_UPDATE_PERMISSION.replace("{}",model.entityName)));
					return;
				}
				var result = kony.appfoundation.validateFormDataModel(model, false); 
				if(!result.isValid){
					serviceErrorCallback(result);
					return;
				}
				var id = "";
				if (model.fields[model.entityDetails.primaryKeyName] !== null
						&& model.fields[model.entityDetails.primaryKeyName] !== undefined) {
					id = model.fields[model.entityDetails.primaryKeyName];
				}
				var colValDto;
				var colValueList = [];
				for ( var key in model.fields) {
					if (model.fields.hasOwnProperty(key)) {
						if (key.toUpperCase() !== model.entityDetails.primaryKeyName.toUpperCase()) {
							colValDto = new kony.appfoundation.columnValueDto(key,
									model.fields[key]);
							colValueList.push(colValDto);
						}
					}
				}
				var updateData = new kony.appfoundation.updateDto(colValueList,
						model.entityDetails.primaryKeyName + "[eq]" + id);
				var input = new kony.appfoundation.updateInput(updateData);
				kony.appfoundation.log.info("update input data-- ", input)
				var headers = {
					session_token : this.sessionToken.token,
					"Content-Type" : "application/json",
					"X-HTTP-Method-Override" : "PUT"
				};
				if(!kony.appfoundation.constants["ISCLOUD"]){
					headers["tenant"] = this.sessionToken.tenant;
				}
				kony.appfoundation.theAjaxProvider.get(kony.appfoundation.constants.DATA_ENDPOINT
						+ model.entityName, kony.appfoundation.constants.HTTP_METHOD_POST,
						headers, updateServiceCallback, serviceErrorCallback,
						input);
			},
			customservice : function(httpcustomrequest,customservicename, customserviceCallback,
					customserviceErrorCallback) {
				if(httpcustomrequest !== null
				&& httpcustomrequest !== undefined && httpcustomrequest instanceof kony.appfoundation.HttpCustomRequest)
					{
				httpcustomrequest.headers.session_token = this.sessionToken.token;
			httpcustomrequest.headers["Content-Type"] = "application/json";
				if(!kony.appfoundation.constants["ISCLOUD"]){
					httpcustomrequest.headers["tenant"] = this.sessionToken.tenant;
				}
				var url=kony.appfoundation.constants.CUSTOMSERVICE_ENDPOINT+ customservicename;
				var flag=true;
				for (var key in httpcustomrequest.urlparams) {
					  if (httpcustomrequest.urlparams.hasOwnProperty(key)) {
						  if(flag){
							  url=url+"?"+key+"="+httpcustomrequest.urlparams[key];
							  flag=false;
						  }
						  else{
							  url=url+"&"+key+"="+httpcustomrequest.urlparams[key];
						  }
					  }
					}
				function sucesscallback(response){
					if("customresponse" in response){
					   customserviceCallback(response["customresponse"]);
					}else{
						customserviceErrorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_UNEXPECTED_CUSTOMRESPONSE,kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_UNEXPECTED_CUSTOMRESPONSE));
					}
				}
				function errorcallback(response){
					if("customresponse" in response){
					   customserviceErrorCallback(response["customresponse"]);
					}else{
						customserviceErrorCallback(response);
					}
				}
				
					if(httpcustomrequest.headers["X-HTTP-Method-Override"]==="GET"){
				kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants.HTTP_METHOD_GET,
						httpcustomrequest.headers, sucesscallback, errorcallback,
						httpcustomrequest.payload);
						}
						else{
						kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants.HTTP_METHOD_POST,
						httpcustomrequest.headers, sucesscallback, errorcallback,
						httpcustomrequest.payload);
						}
					}else{
						customserviceErrorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_INVALID_CUSTOMSERVICE_INPUT_PARAM,kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_INVALID_CUSTOMSERVICE_INPUT_PARAM));
					}
			},

			fetch : function(query, successCallback,
					serviceErrorCallback,odataqueryStr) {
				kony.appfoundation.log.info("odataqueryStr passed to fetch is ",odataqueryStr);
				var url = kony.appfoundation.constants.DATA_ENDPOINT;
				if((!query || query.tables.length == 0) && odataqueryStr){					
					url = url + odataqueryStr;
					var headers = {
						Accept : "application/json",
						session_token : this.sessionToken.token
					};
					if(!kony.appfoundation.constants["ISCLOUD"]){
						headers["tenant"] = this.sessionToken.tenant;
					}
					kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants.HTTP_METHOD_GET,
							headers, successCallback, serviceErrorCallback, null);
				}
				else{
					// we need to apply the odataquery set by user on top of the query generated by ui runtime.
					//we are considering only the select and filters queryparam from the odataquery provided by user. 
					for(var i=0; i < query.tables.length;i++){
						var tName = query.tables[i].getName();
						if(!query.tables[i].isJunction() && kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(tName,"","retrieve")){
							//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_READ_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_READ_PERMISSION.replace("{}",tName)).alert(true);
							serviceErrorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_READ_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_READ_PERMISSION.replace("{}",tName)));
							return;
						}
					}
					var tableName = query.getTables()[0].getName();
					
					if (tableName !== null && tableName !== undefined) {
						url = url + tableName;
					}
					if (query && query.getJoins().length !== 0) {
						url = url + "/" + query.getJoins()[0].getTable().getName();
					}
					if (query &&( query.getColumns().length !== 0
							|| query.getCriterias().length !== 0
							|| query.getLimit() !== null
							|| query.getSkip() !== null)) {
						url = url + "?";
						if (query.getColumns() && query.getColumns().length !== 0) {
							url = url + "$select=";
							for ( var i = 0; i < query.getColumns().length; i++) {
								url = url + query.getColumns()[i].getName();
								if (i + 1 < query.getColumns().length) {
									url = url + ",";
								}
							}
						}
						
						if(odataqueryStr && odataqueryStr.indexOf("$select=") != -1){
							var indx = odataqueryStr.indexOf("$select=");
							var endIndx =  odataqueryStr.indexOf(indx+8,"&");
							var colStr = "";
							if(endIndx != -1)
								colStr = odataqueryStr.substring(indx,endIndx);
							else
								colStr = odataqueryStr.substring(indx);
							if (query.getColumns() && query.getColumns().length !== 0) 
								url = url + ","+ colStr;
							else
								url = url + "$select="+ colStr;
						}
						
						kony.appfoundation.log.info("url after adding columns is "+url);
						
						if (query.getCriterias() && query.getCriterias().length != 0) {
							if (query.getColumns().length !== 0) {
								url = url + "&";
							}
							url = url + "$filters=";
							for ( var i = 0; i < query.getCriterias().length; i++) {
								url = url+ query.getCriterias()[i].getColumn()
												.getName();
								var criteriaObj = query.getCriterias()[i];
								if(criteriaObj instanceof kony.appfoundation.Match){
									switch(criteriaObj.getMatchType().name.toUpperCase()){
										case "EQUALS":
											url = url + "[eq]";
											break;
										case "GREATER":
											url = url + "[gt]";
											break;
										case  "GREATEREQUAL":
											url = url + "[ge]";
											break;
										case "LESS":
											url = url + "[lt]";
											break;
										case  "LESSEQUAL":
											url = url + "[le]";
											break;
										case  "STARTSWITH":
											url = url + "[sw]";
											break;
										case "CONTAINS":
											url = url + "[cn]";
											break;
										case "ENDSWITH":
											url = url + "[ew]";
											break;
										case "NOTEQUAL":
											url = url + "[ne]";
											break;
										case "ISNULL":
											url = url + "[null]";
											break;
										case "ISNOTNULL":
											url = url + "[nn]";
											break;	
										case "LIKE":
											url = url + "[lk]";
											break;
										default :
											kony.appfoundation.log.error("match type doesnt match any operator");
									}
									url = url + criteriaObj.getValue();
								}
								else if(criteriaObj instanceof kony.appfoundation.InCriteria){
									url = url + "[in]" ;
									var values = criteriaObj.getValues();
									for(var j=0;j< values.length;j+=1){
										url  = url + values[j];
										if(j < values.length - 1)
										   url += ",";
									}
								}
								else if(criteriaObj instanceof kony.appfoundation.Between){
									url = url + "[btn]" ;
									var values = criteriaObj.getValues();
									for(var j=0;j< values.length;j+=1){
										url  = url + values[j];
										if(j < values.length - 1)
										   url += ",";
									}
								}
								
								if (i + 1 < query.getCriterias().length) {
									url = url + " and ";
								}
							}
						}
						kony.appfoundation.log.info("url is "+url);
						kony.appfoundation.log.info("query is ",query);
						
						if(odataqueryStr && odataqueryStr.indexOf("$filters=") != -1){
							var indx = odataqueryStr.indexOf("$filters=")+9;
							var endIndx =  odataqueryStr.indexOf('&');
							var fltrStr = "";
							kony.appfoundation.log.info("endIndx is "+endIndx);
							if(endIndx != -1)
								fltrStr = odataqueryStr.substring(indx,endIndx);
							else{
								kony.appfoundation.log.info("odataqueryStr is "+odataqueryStr);
								fltrStr = odataqueryStr.substring(indx,odataqueryStr.length);
								kony.appfoundation.log.info("fltrStr is "+fltrStr);
							}
								
							
							
							
							if(query.getCriterias() && query.getCriterias().length !== 0)
								url = url + " and " + fltrStr;
							else
								url = url + "&$filters="+ fltrStr;
						}
						kony.appfoundation.log.info("url after adding filters is "+url);
						
						if (query.getLimit() !== null) {
							if (query.getColumns().length !== 0
									|| query.getCriterias().length !== 0) {
								url = url + "&";
							}
							url = url + "$limit=" + query.getLimit();
						}
						if (query.getSkip() !== null) {
							if (query.getColumns().length !== 0
									|| query.getCriterias().length !== 0
									|| query.getLimit() !== null) {
								url = url + "&";
							}
							url = url + "$skip=" + query.getSkip();
						}
						if (query.getOrders() !== null && query.getOrders().length > 0) {
							if (query.getColumns().length !== 0
									|| query.getCriterias().length !== 0
									|| query.getLimit() !== null
									|| query.getSkip() !== null) {
								url = url + "&";
							}
							url = url + "$order=";
							for (var i = 0; i < query.getOrders().length; i++) {
								url = url + query.getOrders()[i].getColumn().getName();
								if (i + 1 < query.getOrders().length) {
									url = url + ",";
								}
							}
							if (query.getOrders()[0]) {
								url = url + ":" + query.getOrders()[0].getType();
							}
						}
					}
					kony.appfoundation.log.info("final url prepared by RestDataProvider : ",url);
					var headers = {
						Accept : "application/json",
						session_token : this.sessionToken.token
					};
					if(!kony.appfoundation.constants["ISCLOUD"]){
						headers["tenant"] = this.sessionToken.tenant;
					}
					kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants.HTTP_METHOD_GET,
							headers, successCallback, serviceErrorCallback, null);
				
				}
			},
			read : function(model, id, readSuccessCallback,
					serviceErrorCallback) {
				if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(model.entityName,"","retrieve")){
					//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_READ_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_READ_PERMISSION.replace("{}",model.entityName)).alert(true);
					serviceErrorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_READ_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_READ_PERMISSION.replace("{}",model.entityName)));
					return;
				}
				var headers = {
					Accept : "application/json",
					session_token : this.sessionToken.token
				};
				if(!kony.appfoundation.constants["ISCLOUD"]){
					headers["tenant"] = this.sessionToken.tenant;
				}
				kony.appfoundation.theAjaxProvider.get(kony.appfoundation.constants.DATA_ENDPOINT
						+ model.entityName + "?$filters="
						+ model.entityDetails.primaryKeyName + "[eq]" + id,
						kony.appfoundation.constants.HTTP_METHOD_GET, headers,
						callbackHandler, serviceErrorCallback, null);
				function callbackHandler(result) {
					var newModel = new kony.appfoundation.Model(model.entityName);
					for ( var key in result[0]) {
						if (result[0].hasOwnProperty(key)) {
							newModel.fields[key] = result[0][key];
						}
					}
					if (typeof readSuccessCallback === 'function')
						readSuccessCallback(newModel);
				}
			},
			deleteRecord : function(model, id,
					deleteSuccessCallback, serviceErrorCallback) {
				if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(model.entityName,"","delete")){
					//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_DELETE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_DELETE_PERMISSION.replace("{}",model.entityName)).alert(true);
					serviceErrorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_DELETE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_DELETE_PERMISSION.replace("{}",model.entityName)));
					return;
				}
				var headers = {
					Accept : "application/json",
					session_token : this.sessionToken.token,
					"X-HTTP-Method-Override" : "DELETE"
				};
				if(!kony.appfoundation.constants["ISCLOUD"]){
					headers["tenant"] = this.sessionToken.tenant;
				}
				kony.appfoundation.theAjaxProvider.get(kony.appfoundation.constants.DATA_ENDPOINT
						+ model.entityName + "?$filters="
						+ model.entityDetails.primaryKeyName + "[eq]" + id,
						kony.appfoundation.constants.HTTP_METHOD_GET, headers,
						deleteSuccessCallback, serviceErrorCallback, null);
			},
			downloadClientArtifact : function(successcallback, errorcallback) {
				
				var appVersion = "";
				konysyncSQLLiteDDLCommands = [];
				konysyncClientSyncConfig = {};
				var credStore = kony.store.getItem(kony.appfoundation.credStoreName);
				
				if(credStore && credStore[kony.appfoundation.credStoreDb]) {
					var sql = "select "+kony.sync.syncConfigurationColumnVersion +" from " + kony.sync.syncConfigurationTableName;
					kony.sync.single_select_execute(credStore[kony.appfoundation.credStoreDb], sql, null, fetchSuccess, fetchError);
					function fetchSuccess(resultSet) {
						//If data base is already intialized then fetch the version
						if (resultSet !== null && resultSet.length > 0 
								&& resultSet[0][kony.sync.syncConfigurationColumnVersion]) {
							//Always "syncConfigurationTableName" has only one row
							appVersion = resultSet[0][kony.sync.syncConfigurationColumnVersion];
						}
						kony.appfoundation.log.info("Sync Config version : "+appVersion+" is in DB so requesting only required information");
						kony.appfoundation.getClientConfigFromSaasServer(kony.appfoundation.syncSessionToken,kony.appfoundation.syncTenant,
							appVersion,successcallback, errorcallback); 			
					}
					function fetchError() {
						kony.appfoundation.log.info("Sync Config version is not in DB so requesting complete config");
						kony.appfoundation.getClientConfigFromSaasServer(kony.appfoundation.syncSessionToken,kony.appfoundation.syncTenant,"",
							successcallback, errorcallback);
					}
				} else {
					kony.appfoundation.getClientConfigFromSaasServer(kony.appfoundation.syncSessionToken,kony.appfoundation.syncTenant,"",successcallback, errorcallback);
				}
			},
			getRelationData : function(entityName, entityKeyName,
					entityKeyValue, relation, uiFields, successcallback,
					errorcallback,queryObj) {
				if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(entityName,"","retrieve")){
					//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_READ_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_READ_PERMISSION.replace("{}",entityName)).alert(true);
					errorcallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_READ_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_READ_PERMISSION.replace("{}",entityName)));
					return;
				}
				if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(relation["entityName"],"","retrieve")){
					//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_READ_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_READ_PERMISSION.replace("{}",relation["entityName"])).alert(true);
					errorcallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_READ_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_READ_PERMISSION.replace("{}",relation["entityName"])));
					return;
				}
				var relatedEntityRecordsUrl = kony.appfoundation.constants.RELATED_ENTITY_ENDPOINT;
				var url = relatedEntityRecordsUrl + "/" + entityName + "("
						+ entityKeyValue + ")/" + relation["relationshipName"];
				
				if (queryObj && (queryObj.getColumns().length !== 0
						|| queryObj.getCriterias().length !== 0
						|| queryObj.getLimit() !== null
						|| queryObj.getSkip() !== null)) {
					url = url + "?";
					if (queryObj.getColumns() && queryObj.getColumns().length !== 0) {
						url = url + "$select=";
						for ( var i = 0; i < queryObj.getColumns().length; i++) {
							url = url + queryObj.getColumns()[i].getName();
							if (i + 1 < queryObj.getColumns().length) {
								url = url + ",";
							}
						}
					}
					if (queryObj.getCriterias() && queryObj.getCriterias().length !== 0) {
						if (queryObj.getColumns().length !== 0) {
							url = url + "&";
						}
						url = url + "$filters=";
						var criteriaObj;
						for ( var i = 0; i < queryObj.getCriterias().length; i++) {
							criteriaObj = queryObj.getCriterias()[i];
							url = url+ queryObj.getCriterias()[i].getColumn()
											.getName();
							if(criteriaObj instanceof kony.appfoundation.Match){
								switch(criteriaObj.getMatchType().name.toUpperCase()){
									case "EQUALS":
										url = url + "[eq]";
										break;
									case "GREATER":
										url = url + "[gt]";
										break;
									case  "GREATEREQUAL":
										url = url + "[ge]";
										break;
									case "LESS":
										url = url + "[lt]";
										break;
									case  "LESSEQUAL":
										url = url + "[le]";
										break;
									case  "STARTSWITH":
										url = url + "[sw]";
										break;
									case "CONTAINS":
										url = url + "[cn]";
										break;
									case "ENDSWITH":
										url = url + "[ew]";
										break;
									case "NOTEQUAL":
										url = url + "[ne]";
										break;
									case "ISNULL":
										url = url + "[null]";
										break;
									case "ISNOTNULL":
										url = url + "[nn]";
										break;	
									case "LIKE":
										url = url + "[lk]";
										break;
									default :
										kony.appfoundation.log.error("match type doesnt match any operator");
								}
								url = url + criteriaObj.getValue();
							}
							else if(criteriaObj instanceof kony.appfoundation.InCriteria){
								url = url + "[in]" ;
								var values = criteriaObj.getValues();
								for(var j=0;j< values.length;j+=1){
									url  = url + values[j];
									if(j < values.length - 1)
									   url += ",";
								}
							}
							else if(criteriaObj instanceof kony.appfoundation.Between){
								url = url + "[btn]" ;
								var values = criteriaObj.getValues();
								for(var j=0;j< values.length;j+=1){
									url  = url + values[j];
									if(j < values.length - 1)
									   url += ",";
								}
							}
							
							if (i + 1 < criteriaObj.length) {
								url = url + " and ";
							}
						}
					}
					if (queryObj.getLimit() !== null) {
						if (queryObj.getColumns().length !== 0
								|| queryObj.getCriterias().length !== 0) {
							url = url + "&";
						}
						url = url + "$limit=" + queryObj.getLimit();
					}
					if (queryObj.getSkip() !== null) {
						if (queryObj.getColumns().length !== 0
								|| queryObj.getCriterias().length !== 0
								|| queryObj.getLimit() !== null) {
							url = url + "&";
						}
						url = url + "$skip=" + queryObj.getSkip();
					}
				}
				
				
				var headers = {
					Accept : "application/json",
					session_token : this.sessionToken.token
				};
				if(!kony.appfoundation.constants["ISCLOUD"]){
					headers["tenant"] = this.sessionToken.tenant;
				}
				kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants.HTTP_METHOD_GET,
						headers, successcallback, errorcallback, null);
			},
			associate : function(pkName, parent,parentId,child,payload,relation, relationshipname,successcallback,errorcallback){
				//Keeping in sync with server code.
				if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(parent,"","create")){
					//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_UPDATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_UPDATE_PERMISSION.replace("{}",model.entityName)).alert(true);
					errorcallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_CREATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_CREATE_PERMISSION.replace("{}",parent)));
					return;
				}

				if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(child,"","create")){
					//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_CREATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_CREATE_PERMISSION.replace("{}",child)).alert(true);
					errorcallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_CREATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_CREATE_PERMISSION.replace("{}",child)));
					return;
				}
				var result = kony.appfoundation.validateFormDataModel(payload, true, child); 
				if(!result.isValid){
					errorcallback(result);
					return;
				}
				var url = kony.appfoundation.constants["DATA_ENDPOINT"]+"associate/"+parent+"("+parentId+")/"+relationshipname;
				var headers = {Accept: "application/json", session_token: this.sessionToken.token, "Content-Type":"application/json"};
				if(!kony.appfoundation.constants["ISCLOUD"]){
					headers["tenant"] = this.sessionToken.tenant;
				}
				kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants["HTTP_METHOD_POST"], headers, successcallback, errorcallback, payload);
			},
			associateexistingrecord : function(pkName, parent,parentId,child,childId,relation, relationshipname,successcallback,errorcallback){
				if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(parent,"","create")){
					//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_UPDATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_UPDATE_PERMISSION.replace("{}",model.entityName)).alert(true);
					errorcallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_CREATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_CREATE_PERMISSION.replace("{}",parent)));
					return;
				}
				if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(child,"","create")){
					//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_UPDATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_UPDATE_PERMISSION.replace("{}",model.entityName)).alert(true);
					errorcallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_CREATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_CREATE_PERMISSION.replace("{}",child)));
					return;
				}
				var url = kony.appfoundation.constants["DATA_ENDPOINT"]+"associate/"+parent+"("+parentId+")/"+relationshipname+"/"+child+"("+childId+")";

				var headers = {
					session_token : dataProvider.sessionToken.token,
					"Content-Type" : "application/json",
					"X-HTTP-Method-Override" : "PUT"};
				if(!kony.appfoundation.constants["ISCLOUD"]){
					headers["tenant"] = dataProvider.sessionToken.tenant;

				}

				kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants["HTTP_METHOD_POST"], headers, successcallback, errorcallback, null);
			},
			dissociate : function(pkName, parent,parentId,child,childId,relation, relationshipname, successcallback, errorcallback){
				if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(parent,"","delete")){
					//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_UPDATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_UPDATE_PERMISSION.replace("{}",model.entityName)).alert(true);
					errorcallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_DELETE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_DELETE_PERMISSION.replace("{}",parent)));
					return;
				}
				if(kony.appfoundation.v2.ApplicationContext && !kony.appfoundation.v2.ApplicationContext.hasPermission(child,"","delete")){
					//new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_UPDATE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_UPDATE_PERMISSION.replace("{}",model.entityName)).alert(true);
					errorcallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_RESOURCE_NO_DELETE_PERMISSION,kony.appfoundation.AppFoundationExceptionCode.MSG_RESOURCE_NO_DELETE_PERMISSION.replace("{}",child)));
					return;
				}
				var url = kony.appfoundation.constants["DATA_ENDPOINT"]+"disassociate/"+parent+"("+parentId+")/"+relationshipname+"/"+child+"("+childId+")";
				var headers = {Accept: "application/json", session_token: this.sessionToken.token, "Content-Type":"application/json"};
				if(!kony.appfoundation.constants["ISCLOUD"]){
					headers["tenant"] = this.sessionToken.tenant;
				}
				kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants["HTTP_METHOD_POST"], headers, successcallback, errorcallback, null);
			},
			executeGeneratedSQLQuery: function(selectQueryObj, generatedsqlquery, sucCallBack, errCallBack){
				throw "This method is not implemented."
			}

		// deleteRecords:function(entityName, criteriaList,
		// deleteSuccessCallback, sessionToken){
		// var request = new kony.net.HttpRequest();
		// request.onReadyStateChange=callbackHandler;
		// var url = kony.appfoundation.constants.DATA_ENDPOINT+entityName+"?";
		// if(criteriaList.length !== 0){
		// url = url + "$filters=";
		// for(var i=0;i<criteriaList.length;i++){
		// url = url + criteriaList[i].getColumn().getName();
		// if(criteriaList[i].getMatchType().name.toUpperCase() === "EQUALS"){
		// url = url + "[eq]";
		// }
		// url = url + criteriaList[i].getValue();
		// if(i+1<criteriaList.length){
		// url = url + ",";
		// }
		// }
		// }

		// request.open(kony.appfoundation.constants.HTTP_METHOD_GET, url);
		// request.setRequestHeader("Accept","application/json");
		// request.setRequestHeader("session_token",sessionToken);
		// request.setRequestHeader("X-HTTP-Method-Override","DELETE");
		// request.send();
		// function callbackHandler(){
		// if (request.readyState == 4) {
		// if (request.status == 200) {
		// var result;
		// if(request.response !== null && request.response !== undefined){
		// if(typeof request.response === 'string' || request.response
		// instanceof String){
		// result = JSON.parse(request.response);
		// }else{
		// result = request.response;
		// }
		// }
		// deleteSuccessCallback(result);
		// }
		// }
		// }
		// }
			
			
		});

kony.appfoundation.DataService = Class({
	constructor : function(isServerOn,mockDevice) {
		var isOnline;
		var isDeviceMocked;
		var dataProviderInstance;
		this.isOnline = isServerOn;
		if(mockDevice != undefined && mockDevice != null){
			this.isDeviceMocked = mockDevice;
		}
	},
	getDataProvider : function(sessionToken) {
		if (this.isOnline === true) {
			this.dataProviderInstance = new kony.appfoundation.dataRestProvider(sessionToken);
			return this.dataProviderInstance;
		} else {
			if(this.isDeviceMocked != undefined && this.isDeviceMocked != null && this.isDeviceMocked === true){
				this.dataProviderInstance = new kony.appfoundation.mockSyncDbProvider(sessionToken, this.isDeviceMocked);
				return this.dataProviderInstance;
			}else{
				this.dataProviderInstance = new kony.appfoundation.konySyncProvider(sessionToken);
				return this.dataProviderInstance;
			}
		}
	}

});

kony.appfoundation.MetadataProvider = Class({
	constructor : function(sessionToken,mockDevice) {
		this.sessionToken = sessionToken;
	    this.deviceMocked = mockDevice;
	},
	getEntities : function() {
		throw "Cannot call this function";
	},
	getEntity : function(entityName) {
		throw "Cannot call this function";
	},
	getEntityRelations:function(tx, entityName){
		throw "Cannot call this function";
	},	
	getUiConfig : function(fetchSuccessCallback,
			serviceErrorCallback) {

	},
	changesSince : function(timestamp) {
		throw "Cannot call this function";
	}/*,
	getCustomizableEntities : function(){
		throw "Cannot call this function";
	}*/
});

kony.appfoundation.metadataRestProvider = Class(
		kony.appfoundation.MetadataProvider,
		{
			constructor : function(sessionToken, mockDevice) {
                var session_token;
                var deviceMocked;
                this.$class.$super.call(this, sessionToken, mockDevice);
                this.session_token = sessionToken;
                this.deviceMocked = mockDevice;
            },
            saveDataIntoDataStore: function(dataObj, succCallback, errCallback){
            	var str_Metadata;
		    	var str_fetchTime = dataObj["fetchTime"];
		    	var dbName = kony.appfoundation.constants["AFNLocalDBName"];
		    	
		    	createTblIfNotExists();
		    	
		    	function createTblIfNotExists(){
		    		var tblCreationSQLStmt = "CREATE TABLE if not exists AFNMetaData (id integer PRIMARY_KEY, metadata text,fetchTime text)";
		    		kony.appfoundation.Utils.executeSingleSqlQuery(dbName , tblCreationSQLStmt, null, createTableOnSuccess, createTableOnError);
		    	}
		    	function createTableOnSuccess(response){
		    		kony.appfoundation.log.info("create table success---"+response);
					var query, sqlInsert, sqlUpdate;
					str_Metadata = JSON.stringify(dataObj["metaData"]);
					checkIfRecordPresent();
					
					function checkIfRecordPresent(){
						query = "SELECT id FROM AFNMetadata WHERE id = 1;"
						sqlInsert = "INSERT INTO AFNMetadata(id, metadata, fetchTime) " +"VALUES ('1', '"+str_Metadata+"', '"+str_fetchTime+"');";
						sqlUpdate = "Update AFNMetadata set metadata = '"+str_Metadata+"', fetchTime = '"+str_fetchTime+"' WHERE id = 1;";
						kony.appfoundation.Utils.executeSingleSqlQuery(dbName, query, null, checksuccCallback, errCallback);
						
						function checksuccCallback(response){
							if(response !== null && response.length == 0){
							//	alert("yet to insert ** "+ type);
								kony.appfoundation.Utils.executeSingleSqlQuery(dbName, sqlInsert, null, succCallback, errCallback);
							} else if(response !== null && response.length == 1 && response[0]["id"] == 1){
								//alert("yet to update ** "+ type);
								kony.appfoundation.Utils.executeSingleSqlQuery(dbName, sqlUpdate, null, succCallback, errCallback);
							} else if(response !== null && response.length > 1){
								//TODO: delete all record and then insert
							} else {
								errCallback();
							}
						}
					}
					
		    	}
		    	function createTableOnError(error){
		    		kony.appfoundation.log.error("create table error---- ");
					errCallback();
		    	}
            },
            fetchDataFromDataStore: function(sqlFetchStr, succCallback, errCallback){
            	kony.appfoundation.Utils.executeSingleSqlQuery(kony.appfoundation.constants["AFNLocalDBName"], sqlFetchStr, null, onFetchSuccess, onFetchFailure);
            	
            	function onFetchSuccess(response){
            		var responseJSONObject = {};
            		for ( var i in response) {
						var responseObject = response[i];
						try{
							responseJSONObject["metaData"] = JSON.parse(responseObject["metadata"]);
							responseJSONObject["fetchTime"] = responseObject["fetchTime"];
						}catch(e){
							errCallback(e);
							return;
						}
					}
					succCallback(responseJSONObject);
            	}
            	function onFetchFailure(error){
            		kony.appfoundation.log.error("Db/table doesnot exist, templateData fetch error---");
					errCallback(error);
            	}
            },
            updateFetchTimeIntoDataStore: function(fetchTime, succCallback, errCallback){
            	var sqlUpdate = "Update AFNMetadata set fetchTime = '"+fetchTime+"' WHERE id = 1;";
            	kony.appfoundation.Utils.executeSingleSqlQuery(kony.appfoundation.constants["AFNLocalDBName"], sqlUpdate, null, succCallback, errCallback);
            },
			getEntities : function(fetchSuccessCallback, serviceErrorCallback) {
				kony.appfoundation.log.info("in get entites meta data rest provider");
				if(this.deviceMocked !== undefined && this.deviceMocked.isMocked === true){
                    var testData = this.deviceMocked.data;
                    if(testData.getEntities)
                    	callbackHandler(testData.getEntities);
                    else
                    	serviceErrorCallback("Error");

                } else {
                	var sqlStrng = "SELECT id, metadata, fetchTime FROM AFNMetadata;";
		        	var lastFetchTime;
					var lastFetchedMetaData;
					var scopeObj = this;
		        	this.fetchDataFromDataStore(sqlStrng, successCallback, errorCallback);
		        	
		        	function successCallback(response){
		        		kony.appfoundation.log.info("fetchfrom datastore for metadata finish!! ");
		        		lastFetchedMetaData = response;
		        		if(response !== null && response["fetchTime"]){
		        			lastFetchTime = new String(lastFetchedMetaData["fetchTime"]);
		        			kony.appfoundation.log.info("metadata lastFetchTime ---"+lastFetchTime);
		        		} else {
							lastFetchTime = null;
						}
						getMetadataFromService();
		        	}
		        	
		        	function errorCallback(){
			        	kony.appfoundation.log.error("Fetching stored templateData failed!! Calling getuiconfig");
						lastFetchTime = null;
						getMetadataFromService();
		        	}
		        	
		        	function getMetadataFromService(){
	        			var headers = {
	                        Accept : "application/json",
	                        session_token : scopeObj.sessionToken.token
	                    };
	                    if(!kony.appfoundation.constants["ISCLOUD"]){
	    					headers["tenant"] = scopeObj.sessionToken.tenant;
	    				}
	    				kony.appfoundation.log.debug("in call ****");
	    				var url = kony.appfoundation.constants.METADATA_ENDPOINT;
	    				if(lastFetchTime !== undefined && lastFetchTime !== null){
			            	url = url + "?$lastfetchtime="+ lastFetchTime;
			            }
			        	kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants.HTTP_METHOD_GET, headers, callbackHandlerFromService, serviceErrorCallback, null);    
		        	}
		        	function callbackHandlerFromService(response){
	                	var result = {};
	                	var fetchTime = response["Metadata"]["fetchTime"];
	                	if(response && (response["Metadata"].changeAfterLastFetchTime === true || response["Metadata"].changeAfterLastFetchTime === "true")){
	                		//kony.appfoundation.log.info(" response in callbackHandler From service for metadata " + kony.appfoundation.util.stringifyKonyObject(response));
							kony.appfoundation.log.info("****Metadata fetched from service****");
							result = response;
							var metaDataObj = {"metaData": response["Metadata"], "fetchTime": fetchTime};
							scopeObj.saveDataIntoDataStore(metaDataObj, callback, saveErrCallback);
	                	} else if(response && (response["Metadata"].changeAfterLastFetchTime === false || response["Metadata"].changeAfterLastFetchTime === "false")){
	                		result.Metadata = lastFetchedMetaData["metaData"];
	                		kony.appfoundation.log.info("****Metadata fetched from localdb****");
	            			scopeObj.updateFetchTimeIntoDataStore(fetchTime, callback, saveErrCallback);
	                	}
	                	function callback(){
							callbackHandler(result);
						} 
						function saveErrCallback(){
							kony.print("Error saving to db ");
							callbackHandler(result);	
						}
	                }
                }
                
                function callbackHandler(result) {
					var tableArray = result["Metadata"]["tables"];
					var entities = [];
					var entityMetadata;
					for ( var i = 0; tableArray !== null
							&& tableArray !== undefined
							&& i < tableArray.length; i++) {
						entityMetadata = new kony.appfoundation.EntityMetadata();
						entityMetadata.name = tableArray[i]["name"];
						entityMetadata.displayName = tableArray[i]["displayName"]
						entityMetadata.fields = tableArray[i]["columns"];
						entityMetadata.entityTypeID = tableArray[i]["entityTypeID"];
				        //entityMetadata.name = tableArray[i]["name"];
				        entityMetadata.sourceEntityName = tableArray[i]["sourceEntityName"];
				        entityMetadata.primaryKeyName = tableArray[i]["primaryKeyName"];
				        entityMetadata.junction = tableArray[i]["junction"];
				        entityMetadata.updateable=tableArray[i]["updateable"];
				        entityMetadata.custom=tableArray[i]["custom"];
				        entityMetadata.customizable=tableArray[i]["customizable"];
				        entityMetadata.childRelationshipList=tableArray[i]["childRelationshipList"];
				        entityMetadata.primaryKeyDatatype = tableArray[i]["primaryKeyDatatype"];
				        entityMetadata.primaryFieldName = tableArray[i]["primaryFieldName"];
				        entityMetadata.primaryFieldDatatype = tableArray[i]["primaryFieldDatatype"];
				        entityMetadata.primaryFieldDisplayName = tableArray[i]["primaryFieldDisplayName"];
				        // The below code is responsible for populating the columns inside the entity json. After succesfully fetching the metadata, 
				        // somehow the jasmine tests are failing. Hence commented out the code for now. Need to revisit this again
				        
				        var entityFields = tableArray[i]["columns"];
				        var fieldMetadata;
				        var fields = [];
				        var entityDetails = new kony.appfoundation.EntityDetails();
				        for ( var k = 0; entityFields !== null
								&& entityFields !== undefined
								&& k < entityFields.length; k++) {
							fieldMetadata = new kony.appfoundation.FieldMetadata();
							fieldMetadata.name = entityFields[k].name;
							fieldMetadata.displayName = entityFields[k].displayName;
							fieldMetadata.type = entityFields[k].datatype;
							fieldMetadata.primaryKey = entityFields[k].primaryKey;
							fieldMetadata.nameField = entityFields[k].nameField;
							fieldMetadata.auditColumn = entityFields[k].auditColumn;
							fieldMetadata.createable = entityFields[k].createable;
							fieldMetadata.custom = entityFields[k].custom;
							fieldMetadata.defaultValue = entityFields[k].defaultValue;
							fieldMetadata.fieldMappingId = entityFields[k].fieldMappingId;
							fieldMetadata.foreignKey = entityFields[k].foreignKey;
							fieldMetadata.foreignKeyFieldName = entityFields[k].foreignKeyFieldName;
							fieldMetadata.foreignKeyRefTable = entityFields[k].foreignKeyRefTable;
							fieldMetadata.foreignKeyColumn = entityFields[k].foreignKeyColumn;
							fieldMetadata.parentPrimaryKeyName = entityFields[k].parentPrimaryKeyName;
							fieldMetadata.parentTableName = entityFields[k].parentTableName;
							fieldMetadata.sourceFieldName = entityFields[k].sourceFieldName;
							fieldMetadata.table = entityFields[k].table;
							fieldMetadata.unique = entityFields[k].unique;
							fieldMetadata.updateable = entityFields[k].updateable;
							fieldMetadata.nullable = entityFields[k].nullable;
							fieldMetadata.customizable = entityFields[k].customizable;	
							fieldMetadata.referencedField = entityFields[k].referencedField;
							if (entityFields[k].primaryKey) {
								entityDetails.primaryKeyName = entityFields[k].name;
								entityDetails.primaryKeyDatatype = entityFields[k].datatype;
							}
							if (entityFields[k].nameField) {
								entityDetails.primaryFieldName = entityFields[k].name;
								entityDetails.primaryFieldDatatype = entityFields[k].datatype;
							}
							// Populate picklist values if the field is of type picklist
							if(kony.appfoundation.Utils.matchIgnoreCase(fieldMetadata.type, kony.appfoundation.constants["picklist"]) || 
									kony.appfoundation.Utils.matchIgnoreCase(fieldMetadata.type, kony.appfoundation.constants["picklistmultiselect"])){
								var pickListValues = [];
								var pickLists = entityFields[k]["picklistValues"];
								var pickList;
								if(pickLists !== null && pickLists !== undefined){
									for(var j=0; j<pickLists.length; j++){
										pickList = new kony.appfoundation.PickList();
										pickList.setId(pickLists[j]["id"]);
										pickList.setFieldMappingId(pickLists[j]["fieldMappingId"]);
										pickList.setActive(pickLists[j]["active"]);
										pickList.setLabel(pickLists[j]["label"]);
										pickList.setValue(pickLists[j]["value"]);
										pickList.setDefaultValue(pickLists[j]["defaultValue"]);
										pickList.setValidFor(pickLists[j]["validFor"]);
										pickListValues.push(pickList);
									}
									fieldMetadata.pickListValues = pickListValues;
								}
							}
							if(kony.appfoundation.Utils.matchIgnoreCase(fieldMetadata.type, kony.appfoundation.constants["reference"])){
								fieldMetadata.parentFieldName = entityFields[k]["parentFieldName"];
								fieldMetadata.parentTableName = entityFields[k]["parentTableName"];
								fieldMetadata.referenceTo = entityFields[k]["referenceTo"];
								fieldMetadata.relationshipName = entityFields[k]["relationshipName"];
								fieldMetadata.referencingField = entityFields[k]["referencingField"];
								fieldMetadata.parentPrimaryKeyName = entityFields[k]["parentPrimaryKeyName"];
							}
							fields.push(fieldMetadata);
						}
						entityMetadata.fields = fields;
						entityDetails["entityName"] = tableArray[i]["name"];
						entityMetadata.entityDetails = entityDetails;
						entities.push(entityMetadata);
					}
					kony.appfoundation.cacheMetadata(entities);
					if (typeof fetchSuccessCallback === 'function')
						fetchSuccessCallback(entities);
				}
			},
			getEntity : function(entityName, 
					entitySuccessCallback, serviceErrorCallback) {
				if (kony.appfoundation.getCachedEntityMetadata(entityName) && kony.appfoundation.getCachedEntityMetadata(entityName)["childRelationshipList"]) {
					entitySuccessCallback(kony.appfoundation.getCachedEntityMetadata(entityName));
				}
				else
				{
				if(this.deviceMocked !== undefined && this.deviceMocked.isMocked === true){
					var testData = this.deviceMocked.data;
					var getEntityMockObj = "getEntity"+entityName;
					if(testData[getEntityMockObj])
                    	callbackHandler(testData[getEntityMockObj]);
                    else
                    	serviceErrorCallback("Error");
                } else {
                    var headers = {
                        Accept : "application/json",
                        session_token : this.sessionToken.token
                    };
                    if(!kony.appfoundation.constants["ISCLOUD"]){
    					headers["tenant"] = this.sessionToken.tenant;
    				}
                    kony.appfoundation.theAjaxProvider.get(kony.appfoundation.constants.METADATA_ENDPOINT + "/"+ entityName, kony.appfoundation.constants.HTTP_METHOD_GET, headers, callbackHandler, serviceErrorCallback, null);
                }
                
				function callbackHandler(result) {
					var entityFields = result["Metadata"]["table"]["columns"];
					var table = result["Metadata"]["table"];
					var fieldMetadata;
					var fields = [];
					var entityMetadata = new kony.appfoundation.EntityMetadata();
					var entityDetails = new kony.appfoundation.EntityDetails();

					for ( var i = 0; entityFields !== null
							&& entityFields !== undefined
							&& i < entityFields.length; i++) {
						fieldMetadata = new kony.appfoundation.FieldMetadata();
						fieldMetadata.name = entityFields[i].name;
						fieldMetadata.displayName = entityFields[i].displayName;
						fieldMetadata.type = entityFields[i].datatype;
						fieldMetadata.primaryKey = entityFields[i].primaryKey;
						fieldMetadata.nameField = entityFields[i].nameField;
						fieldMetadata.auditColumn = entityFields[i].auditColumn;
						fieldMetadata.createable = entityFields[i].createable;
						fieldMetadata.custom = entityFields[i].custom;
						fieldMetadata.defaultValue = entityFields[i].defaultValue;
						fieldMetadata.fieldMappingId = entityFields[i].fieldMappingId;
						fieldMetadata.foreignKey = entityFields[i].foreignKey;
						fieldMetadata.foriegnKeyFieldName = entityFields[i].foreignKeyFieldName;
						fieldMetadata.foreignKeyRefTable = entityFields[i].foreignKeyRefTable;
						fieldMetadata.foreignKeyColumn = entityFields[i].foreignKeyColumn;
						fieldMetadata.parentPrimaryKeyName = entityFields[i].parentPrimaryKeyName;
						fieldMetadata.parentTableName = entityFields[i].parentTableName;
						fieldMetadata.sourceFieldName = entityFields[i].sourceFieldName;
						fieldMetadata.table = entityFields[i].table;
						fieldMetadata.unique = entityFields[i].unique;
						fieldMetadata.updateable = entityFields[i].updateable;
						fieldMetadata.nullable = entityFields[i].nullable;
						fieldMetadata.customizable = entityFields[i].customizable;	
						if (entityFields[i].primaryKey) {
							entityDetails.primaryKeyName = entityFields[i].name;
							entityDetails.primaryKeyDatatype = entityFields[i].datatype;
						}
						if (entityFields[i].nameField) {
							entityDetails.primaryFieldName = entityFields[i].name;
							entityDetails.primaryFieldDatatype = entityFields[i].datatype;
						}
						// Populate picklist values if the field is of type picklist
						if(kony.appfoundation.Utils.matchIgnoreCase(fieldMetadata.type, kony.appfoundation.constants["picklist"]) || 
								kony.appfoundation.Utils.matchIgnoreCase(fieldMetadata.type, kony.appfoundation.constants["picklistmultiselect"])){
							var pickListValues = [];
							var pickLists = entityFields[i]["picklistValues"];
							var pickList;
							if(pickLists !== null && pickLists !== undefined){
								for(var index=0; index<pickLists.length; index++){
									pickList = new kony.appfoundation.PickList();
									pickList.setId(pickLists[index]["id"]);
									pickList.setFieldMappingId(pickLists[index]["fieldMappingId"]);
									pickList.setActive(pickLists[index]["active"]);
									pickList.setLabel(pickLists[index]["label"]);
									pickList.setValue(pickLists[index]["value"]);
									pickList.setDefaultValue(pickLists[index]["defaultValue"]);
									pickList.setValidFor(pickLists[index]["validFor"]);
									pickListValues.push(pickList);
								}
								fieldMetadata.pickListValues = pickListValues;
							}
						}
						if(kony.appfoundation.Utils.matchIgnoreCase(fieldMetadata.type, kony.appfoundation.constants["reference"])){
							fieldMetadata.parentFieldName = entityFields[i]["parentFieldName"];
							fieldMetadata.parentTableName = entityFields[i]["parentTableName"];
							fieldMetadata.referenceTo = entityFields[i]["referenceTo"];
							fieldMetadata.relationshipName = entityFields[i]["relationshipName"];
							fieldMetadata.referencingField = entityFields[i]["referencingField"];
							fieldMetadata.parentPrimaryKeyName = entityFields[i]["parentPrimaryKeyName"];
						}
						fields.push(fieldMetadata);
					}
					entityDetails.entityName = entityName;
					//added by aditya 	 	
					//to send entityType Id for creating custom fields 	 	
					entityDetails.entityTypeID = result["Metadata"]["table"]["entityTypeID"]; 
					entityMetadata.name = entityName;
					entityMetadata.fields = fields;
					entityMetadata.entityDetails = entityDetails;

					entityMetadata.entityTypeID = table["entityTypeID"];
					entityMetadata.displayName = table["displayName"];
			        entityMetadata.sourceEntityName = table["sourceEntityName"];
			        entityMetadata.primaryKeyName = table["primaryKeyName"];
			        entityMetadata.junction = table["junction"];
			        entityMetadata.updateable= table["updateable"];
			        entityMetadata.custom=table["custom"];
			        entityMetadata.customizable=table["customizable"];
			        entityMetadata.childRelationshipList=table["childRelationshipList"];
			        entityMetadata.primaryKeyDatatype = table["primaryKeyDatatype"];
			        entityMetadata.primaryFieldName = table["primaryFieldName"];
			        entityMetadata.primaryFieldDatatype = table["primaryFieldDatatype"];					
			        entityMetadata.primaryFieldDisplayName = table["primaryFieldDisplayName"];					
	
					kony.appfoundation.cacheEntityMetadata(entityMetadata);
					
					if (typeof entitySuccessCallback === 'function')
						entitySuccessCallback(entityMetadata);
				}
			}
			},
			getEntityRelations:function(tx, entityName){
				throw "Cannot call this function";
			},	
			
			/*getCustomizableEntities : function(fetchSuccessCallback,
					serviceErrorCallback) {
				var headers = {
					Accept : "application/json",
					session_token : this.sessionToken.token
				};
				if(!kony.appfoundation.constants["ISCLOUD"]){
					headers["tenant"] = this.sessionToken.tenant;
				}
				kony.appfoundation.theAjaxProvider.get(kony.appfoundation.constants.CUSTOMIZABLE_METADATA_ENDPOINT,
						kony.appfoundation.constants.HTTP_METHOD_GET, headers,
						callbackHandler, serviceErrorCallback, null);
				function callbackHandler(result) {
					var tableArray = result["Metadata"]["tables"];
					var customizableEntities = [];
					var entityMetadata;
					for ( var i = 0; tableArray !== null
							&& tableArray !== undefined
							&& i < tableArray.length; i++) {
						entityMetadata = new kony.appfoundation.EntityMetadata();
						entityMetadata.name = tableArray[i]["name"];
						entityMetadata.fields = tableArray[i]["columns"];
						customizableEntities.push(entityMetadata);
					}
					if (typeof fetchSuccessCallback === 'function')
						fetchSuccessCallback(customizableEntities);
				}
			},*/
			getUiConfig : function(fetchSuccessCallback,
					serviceErrorCallback) {
				try {

					var url =  kony.appfoundation.constants["HOST_URL"]
							+ "/SaaSFoundationWS/uiconfig/v1";
					var headers = {
						Accept : "application/json",
						session_token : this.sessionToken.token,
						"Content-Type" : "application/json"
					};
					if(!kony.appfoundation.constants["ISCLOUD"]){
						headers["tenant"] = this.sessionToken.tenant;
					}
					kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants.HTTP_METHOD_GET,
							headers, fetchSuccessCallback,
							serviceErrorCallback, null);
				} catch (e) {
					if (typeof serviceErrorCallback === 'function')
						serviceErrorCallback(e);
					kony.appfoundation.log.error("exception occurred "+e);	
				}
			},
			changesSince : function(timestamp) {
			},
			//added by KH1861
			createCustomField : function(payload, SuccessCallback,
					serviceErrorCallback) {
				var headers = {
					Accept : "application/json",
					"Content-Type" : "application/json",
					session_token : this.sessionToken.token
				};
				if(!kony.appfoundation.constants["ISCLOUD"]){
					headers["tenant"] = this.sessionToken.tenant;
				}
				kony.appfoundation.log.debug("Inside ---- createCustomLib");
				kony.appfoundation.theAjaxProvider.get(kony.appfoundation.constants.METADATA_ENDPOINT + "/customfield",
						kony.appfoundation.constants.HTTP_METHOD_POST, headers,
						callbackHandler, serviceErrorCallback, payload);
				function callbackHandler(result) {
					var tableArray = result["Metadata"]["tables"][0]["columns"];
					var fields = [];
					var fieldMetadata;
					for ( var i = 0; tableArray !== null
							&& tableArray !== undefined
							&& i < tableArray.length; i++) {
						fieldMetadata = new kony.appfoundation.FieldMetadata();
						fieldMetadata.name = tableArray[i]["name"];
						fieldMetadata.type = tableArray[i]["datatype"];
						fieldMetadata.primaryKey = tableArray[i]["primaryKey"];
						fieldMetadata.nameField = tableArray[i]["nameField"];
						fieldMetadata.custom = tableArray[i]["custom"];
						fields.push(fieldMetadata);
					}
					if (typeof SuccessCallback === 'function')
						SuccessCallback(fields);
				}
				function serviceErrorCallback(error){
					kony.appfoundation.log.error("Error message inside create field"+error.toString());
				
				}
			}
			
		});
		
kony.appfoundation.metadataSyncProvider = Class(
		kony.appfoundation.MetadataProvider, {
    constructor: function(sessionToken, mockDevice) {
        this.$class.$super.call(this, sessionToken,mockDevice);
    },
    getEntities: function(fetchSuccessCallback, serviceErrorCallback) {
    	var provider = new kony.appfoundation.DataService(false,this.deviceMocked);
        syncProvider = provider.getDataProvider();
        var query = kony.appfoundation.constants["GET_METADATA_OBJECT_FIELDS"]
        query = query.replace("AND lower(ent.name) = lower(?) AND fm.sourcefieldname is not null AND trim(fm.sourcefieldname) <> ''","");
        syncProvider.executeSelectQuery(query,successHandler,errorHandler);
    	function successHandler(response){
    		kony.appfoundation.log.debug("entered the success handler for getentities",response);
    		var entities = kony.appfoundation.parseEntityMetadataResponse(response,"getEntities");
			kony.appfoundation.cacheMetadata(entities);
    		fetchSuccessCallback(entities);
    	}
    	function errorHandler(error){
    		serviceErrorCallback(error);
    	}
    },
    getEntity : function(entityName, entitySuccessCallback, serviceErrorCallback) {
		if (kony.appfoundation.getCachedEntityMetadata(entityName) && kony.appfoundation.getCachedEntityMetadata(entityName)["childRelationshipList"]) {
			entitySuccessCallback(kony.appfoundation.getCachedEntityMetadata(entityName));
		}else{
    	var query = kony.appfoundation.constants["GET_METADATA_OBJECT_FIELDS"];
        query = query.replace("?", "'"+entityName+"'");
        var provider = new kony.appfoundation.DataService(false,this.deviceMocked);
        syncProvider = provider.getDataProvider();
    	syncProvider.executeSelectQuery(query,successHandler,errorHandler);
    	function successHandler(response){
    		kony.appfoundation.log.debug("entered the success handler for getentity");
    		var entity = kony.appfoundation.parseEntityMetadataResponse(response,"getEntity");
    		
    		var relationsQuery =kony.appfoundation.constants["FETCH_ENTITY_RELATIONS_BY_ENTITYID"];
    		relationsQuery = relationsQuery.replace("er.referenced_entity_id = ?","er.referenced_entity_id = '"+entity["entityTypeID"]+"'");
	        relationsQuery = relationsQuery.replace("er.referencing_entity_id = ?", "er.referencing_entity_id = '"+entity["entityTypeID"]+"'");
	        
	        var provider = new kony.appfoundation.DataService(false,this.deviceMocked);
	        syncProvider = provider.getDataProvider();
	    	syncProvider.executeSelectQuery(relationsQuery,relationsSuccessHandler,relationsErrorHandler);
	    	
	    	function relationsSuccessHandler(response){
	    		var relations = kony.appfoundation.parseEntityRelationshipResponse(response);
	    		entity["childRelationshipList"] = relations;
	    		kony.appfoundation.cacheEntityMetadata(entity);
	    		entitySuccessCallback(entity);
	    	}
	    	
	    	function relationsErrorHandler(error){
	    		serviceErrorCallback(error);
	    	}
    	}
    	function errorHandler(error){
    		serviceErrorCallback(error);
    	}
    }
    },
    getEntityRelations:function(tx, entityName){
    	var query = kony.appfoundation.constants["GET_METADATA_OBJECT_FIELDS"];
        query = query.replace("?", "'"+entityName+"'");
        var resultSet = kony.sync.executeSql(tx, query, null);
        if(resultSet == false || resultSet == null)
        	return null;
        	
        var response = [];
        var num_records = resultSet.rows.length;
		for(var i = 0; i <= num_records - 1; i++){
			response[i] = kony.db.sqlResultsetRowItem(tx, resultSet, i);
		}
        
        var entity = kony.appfoundation.parseEntityMetadataResponse(response,"getEntity");
		var relationsQuery =kony.appfoundation.constants["FETCH_ENTITY_RELATIONS_BY_ENTITYID"];
		relationsQuery = relationsQuery.replace("er.referenced_entity_id = ?","er.referenced_entity_id = '"+entity["entityTypeID"]+"'");
        relationsQuery = relationsQuery.replace("er.referencing_entity_id = ?", "er.referencing_entity_id = '"+entity["entityTypeID"]+"'");
        var relationsQueryresultSet = kony.sync.executeSql(tx, relationsQuery, null);
        
        if(relationsQueryresultSet == false || relationsQueryresultSet == null)
        	return null;
        
        var realtionsResponse = [];
        var num_records = relationsQueryresultSet.rows.length;
		for(var i = 0; i <= num_records - 1; i++){
			realtionsResponse[i] = kony.db.sqlResultsetRowItem(tx, relationsQueryresultSet, i);
		}
        
        var relations = kony.appfoundation.parseEntityRelationshipResponse(realtionsResponse);
	    entity["childRelationshipList"] = relations;
	    return entity;
	},	
    
     getUiConfig: function(fetchSuccessCallback, fetchErrorCallback) {
    	 kony.appfoundation.fetchSyncUIConfiguration(this.sessionToken, fetchSuccessCallback, fetchErrorCallback);
    },
    changesSince: function(timestamp) {}
});
    

kony.appfoundation.MetadataService = Class({
	constructor : function(serverStatus, mockDevice) {
		var isOnline;
		var isDeviceMocked;
		var metadataProviderInstance;
		this.isOnline = serverStatus;
        this.isDeviceMocked = mockDevice;
        kony.appfoundation.log.info("server Status in metadata service -- "+serverStatus);
	},
	getMetadataProvider : function(sessionToken) {
		if (this.isOnline === true) {
			kony.appfoundation.log.info("Get metadata provideer -- rest provider");
			this.metadataProviderInstance = new kony.appfoundation.metadataRestProvider(
					sessionToken, this.isDeviceMocked);
			return this.metadataProviderInstance;
		} else {
			if(this.isDeviceMocked && this.isDeviceMocked.isMocked) {
				this.metadataProviderInstance = new kony.appfoundation.metadataMockSyncProvider(sessionToken, this.isDeviceMocked);
				return this.metadataProviderInstance;
			} else {
				kony.appfoundation.log.info("Get metadata provideer -- sync provider");
				this.metadataProviderInstance = new kony.appfoundation.metadataSyncProvider(
						sessionToken, this.isDeviceMocked);
				return this.metadataProviderInstance;	
			}
			
		}
	}
});

kony.appfoundation.EntityMetadata = Class({
	constructor : function() {
		 //variables to store metadata of the entity.
        var entityTypeID;
        var name;
        var displayName;
        var sourceEntityName;
        var primaryKeyName;
        var junction;
        var updateable;
        var custom;
        var customizable;
        var primaryKeyDatatype;
        var childRelationshipList;
        //fields will store the details of the columns in the entity
        var fields;
        //stores the details of the entity.
        var entityDetails;
        
        var primaryFieldName;
        var primaryFieldDatatype;
        var primaryFieldDisplayName;
	}
});

kony.appfoundation.FieldMetadata = Class({
	constructor : function() {
		var name;
		var displayName;
		var sourceFieldName;
        var type;
        var custom;
        var createable;
        var updateable;
        var customizable;
        var auditColumn;
        var hasIndex;
        var nullable;
        var primaryKey;
        var relationshipId;
        var table;
        var unique;
        var nameField;
        var parentFieldName;
        var parentTableName;
        var nameField;
        var parentPrimaryKeyName;
        var foreignKeyFieldName;
        var foreignKey;
        var foreignKeyRefTable;
        var foreignKeyColumn;
        var fieldMappingId;
        
        // array of picklistValueDto objects to hold the pick list values. This will be populated only when the data type is of picklist type
        var pickListValues;
        
        // populate the parent table's name field name
        var referenceTo;
        var relationshipName;
        var referencingField;
        var referencedField;
	}
});

/*function EntityDetails(entityName, entityTypeID, description, primaryKeyName, primaryKeyDatatype, primaryFieldName, primaryFieldDatatype) {
    this.entityTypeID = entityTypeID;
    this.entityName = entityName;
    this.description = description;
    this.primaryKeyName = primaryKeyName;
    this.primaryKeyDatatype = primaryKeyDatatype;
    this.primaryFieldName = primaryFieldName;
    this.primaryFieldDatatype = primaryFieldDatatype;
    return this;
}
*/
kony.appfoundation.EntityDetails = Class ({
	constructor : function(entityName, entityTypeID, description, primaryKeyName, primaryKeyDatatype, primaryFieldName, primaryFieldDatatype) {
		
		var entityTypeID;
	    var entityName;
	    var description;
	    var primaryKeyName;
	    var primaryKeyDatatype;
	    var primaryFieldName;
	    var primaryFieldDatatype;
	    
    this.entityTypeID = entityTypeID;
    this.entityName = entityName;
    this.description = description;
    this.primaryKeyName = primaryKeyName;
    this.primaryKeyDatatype = primaryKeyDatatype;
    this.primaryFieldName = primaryFieldName;
    this.primaryFieldDatatype = primaryFieldDatatype;
    return this;
}
});
/*
var EntityDetails = Class({
	constructor: function() {
	  var custom;
	  var customizable;
	  var description;
	  var displayName;
	  var entityType;
	  var entityTypeID;
	  var junction;
	  var label;
	  var metadataObject;
	  var name;
	  var operationType;
	  var pageTemplates;
	  var primaryFieldDatatype;
	  var primaryFieldName;
	  var primaryKeyDatatype;
	  var primaryKeyName;
	  var sourceEntityName;
	  var updateable;
	}
});
*/
kony.appfoundation.EntityRelationship = Class({
  constructor : function() {
	  var entityName;
	  var entityPageTemplateId;
	  var id;
	  var junctionTableName;
	  var operationType;
	  var parentEntity;
	  var referencingField;
	  var relationshipName;
	  var relationshipType;
	  var custom;
  }
});


/**
 * The input to update service and create service should be modified using the
 * classes defined below so that they will be written to the corresponding
 * objects on the server
 */
kony.appfoundation.columnValueDto = Class({
	constructor : function(columnName, value) {
		var columnName;
		var val;
		this.columnName = columnName;
		this.val = value;
	}
});

kony.appfoundation.insertInput = Class({
	constructor : function(array) {
		var columnValueDto;
		this.columnValueDto = array;
	}
});

kony.appfoundation.updateDto = Class({
	constructor : function(columnValues, criteria) {
		var columnValues;
		var criteria;
		this.columnValues = columnValues;
		this.criteria = criteria;
	}
});

kony.appfoundation.updateInput = Class({
	constructor : function(updateDto) {
		var updateDto;
		this.updateDto = updateDto;
	}
});

kony.appfoundation.UIConfigDataProvider = Class({
	constructor:function(sessionToken, mockDevice){
        this.sessionToken = sessionToken;
        this.mockDevice = mockDevice;
    },
	getTemplates:function(successCallback, errorCallback, forVisualizer){
		throw "This method is not implemented";
	},
	getUIConfig:function(listOfEntities, successCallback, errorCallback, forVisualizer){
		throw "This method is not implemented";
	},
	setUIConfig:function(entityFormData, successCallback, errorCallback){
		throw "This method is not implemented";
	}	
});

kony.appfoundation.UIConfigSyncProvider = Class(kony.appfoundation.UIConfigDataProvider,{
	
	constructor:function(sessionToken){
		this.$class.$super.call(this, sessionToken);
 
	},
	getThemesData:function(successCallback, errorCallback){
    	kony.appfoundation.log.debug("in getthemesdata");
    	var platformName = kony.appfoundation.Utils.getPlatformName(); 
		
		try{
			var query = "select MAX(datetime(lastmodifiedts)), platform_theme_json, name from themes"+
			" where platform_name = '" + platformName + "'" + " and is_default = 'true'";
			
			var provider = new kony.appfoundation.DataService(false,false);			
            syncProvider = provider.getDataProvider();			
			syncProvider.executeSelectQuery(query,succCallback,errCallback);
			
			function succCallback(response){
				var currentTheme = {};
				if(response !== null && response !== undefined){
					if(response.length === 1) {
						for(var i=0; i<response.length; i++){
							currentTheme[response[i]["name"]] = response[i]["platform_theme_json"];
						}
					} else if(response.length > 1) {
						errorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_MULTIPLE_DEFAULT_THEME, kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_MULTIPLE_DEFAULT_THEME));
					} else {
						errorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_FETCHING_THEME, kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_FETCHING_THEME));
					}					
				}
				if(typeof successCallback === 'function')
					successCallback(currentTheme);
			}
			function errCallback(error){
				kony.appfoundation.log.error("error while fetching default theme from db :"+error);
				if(typeof errorCallback === 'function')
					errorCallback(error);
			}
		}	catch(e){
				if(typeof errorCallback === 'function')
					errorCallback(e);
				kony.appfoundation.log.error("Exception occured "+e);
		}
		
    },
	getTemplates:function(successCallback, errorCallback, forVisualizer){

		var channelName = kony.appfoundation.Utils.getChannelName();
		var platformName = kony.appfoundation.Utils.getPlatformName();
		
		try{
		
			var query = "select ef.formconfig, efj.formjs,efi.form_id,efi.templatetype from entity_formdata_instances efi"+
			" inner join entity_formdata ef on ef.entity_formdata_instances_id = efi.id and efi.channel = '" +  channelName + "'" +
			" inner join entity_formdata_javascript efj on efj.entity_formdata_instances_id = efi.id and efj.platform = '" + platformName + "'" +
			" where efi.istemplate = 'true'";	
                    			
			var provider = new kony.appfoundation.DataService(false,false);			
            syncProvider = provider.getDataProvider();			
			syncProvider.executeSelectQuery(query,succCallback,errCallback);
			function succCallback(response){
				
				var uiConfig = {};
				var entityFormData = [];
				
				var templateTypeMap = {};

				if(response !== null && response !== undefined){
					for(var i=0; i<response.length; i++){
						
						var formData = [];
						var channelFormData = {};
						
						channelFormData["channelName"] = channelName;
						channelFormData["formConfig"] = response[i]["formconfig"];
						channelFormData["formID"] = response[i]["form_id"];
						channelFormData["formJSON"] = undefined;
						
						var platformData = [];
						var platformSpecificFormData = {};
						platformSpecificFormData["formJS"] = response[i]["formjs"];
						platformSpecificFormData["platformName"] = platformName;
						
						platformData.push(platformSpecificFormData);
						
						channelFormData["platformData"] = platformData;
						
						var templateType = response[i]["templatetype"];
						if(templateTypeMap.hasOwnProperty(templateType)){
							templateTypeMap[templateType].push(channelFormData);
						} else {
							templateTypeMap[templateType] = [];
							templateTypeMap[templateType].push(channelFormData);
						}
					}
					
					var templateTypesArray = Object.keys(templateTypeMap);
					for(var i=0;i<templateTypesArray.length;i++){
						var templateType = templateTypesArray[i];
						var templateUIConfig = {}; 						
						templateUIConfig["templateType"] = templateType;
						templateUIConfig["formData"] = templateTypeMap[templateType];
						
						entityFormData.push(templateUIConfig);
					}
					
					uiConfig["entityFormData"] = entityFormData;
				}
				if(typeof successCallback === 'function')
					successCallback(uiConfig);
			}
			function errCallback(error){
				kony.appfoundation.log.error("error while fetching metadata from db :"+error);
				if(typeof errorCallback === 'function')
					errorCallback(error);
			}
		}catch(e){
			if(typeof errorCallback === 'function')
				errorCallback(e);
			kony.appfoundation.log.error("Exception occured "+e);
		}		
	
	},
    getUIConfig: function(entityName, successCallback, errorCallback, forVisualizer) {
        var channelName = kony.appfoundation.Utils.getChannelName();
        var platformName = kony.appfoundation.Utils.getPlatformName();
        try {

            var query = "select ef.formconfig as formconfig, efj.formjs as formjs, et.name as entity_name, efi.form_id as formid from entity_formdata_instances efi " +
			" inner join entitytype et on et.id = efi.entity_id " +
			" inner join entity_formdata ef on ef.entity_formdata_instances_id = efi.id and efi.channel = '" + channelName + "'" + 
			" inner join entity_formdata_javascript efj on efj.entity_formdata_instances_id = efi.id and efj.platform = '"+ platformName + "'";
            
 			var provider = new kony.appfoundation.DataService(false,false);
        	syncProvider = provider.getDataProvider();
			syncProvider.executeSelectQuery(query,succCallback,errCallback);

            function succCallback(response) {
                var uiConfig = {};
                var entityMap = {};
				var entityFormData = [];
                
				if(response !== null && response !== undefined){
					for(var i=0; i<response.length; i++){
						
						var formData = [];
						var channelFormData = {};
						
						channelFormData["channelName"] = channelName;
						var formConfig = response[i]["formconfig"];
						if (formConfig === null || formConfig === "" || formConfig === undefined) {
							channelFormData["formConfig"] = "{}";
						} else {
							channelFormData["formConfig"] = formConfig;							
						}
						channelFormData["formID"] = response[i]["formid"];
						channelFormData["formJSON"] = undefined;
						
						var platformData = [];
						var platformSpecificFormData = {};
						platformSpecificFormData["formJS"] = response[i]["formjs"];
						platformSpecificFormData["platformName"] = platformName;
						
						platformData.push(platformSpecificFormData);
						
						channelFormData["platformData"] = platformData;
						
						var entityName = response[i]["entity_name"];
						if(entityMap.hasOwnProperty(entityName)){
							entityMap[entityName].push(channelFormData);
						} else {
							entityMap[entityName] = [];
							entityMap[entityName].push(channelFormData);
						}
						
					}
					
					
					var entitiesArray = Object.keys(entityMap);
					for(var i=0;i<entitiesArray.length;i++){
						var entityName = entitiesArray[i];
						var entityUIConfig = {};
						entityUIConfig["entityName"] = entityName;
						entityUIConfig["formData"] = entityMap[entityName];
						
						entityFormData.push(entityUIConfig);
					}
					
					uiConfig["entityFormData"] = entityFormData;
					
					var startupFormQuery = "select channel, form_id as formid from entity_formdata_instances efi where efi.channel = '" + channelName + "'" + 
						" and efi.isstartup = 'true'";
						
					syncProvider.executeSelectQuery(startupFormQuery,innerSuccCallBack,innerErrCallback);
					
					function innerSuccCallBack (startupResponse) {
						if (startupResponse) {
							if (startupResponse.length > 1) {
								if (typeof errCallback === 'function')
									return errCallback("More than one form is marked as startup");
							} else if (startupResponse.length === 0) {
								if (typeof errCallback === 'function')
									return errCallback("No form is marked as startup");
							}
							var startUpFormData = [];
							var startUpFormJson = {};
							startUpFormJson["channel"] = startupResponse[0].channel;
							startUpFormJson["formID"] = startupResponse[0].formid;
							startUpFormData.push(startUpFormJson);
							uiConfig["startUpFormData"] = startUpFormData;
							if (typeof successCallback === 'function') successCallback(uiConfig);
						} else {
							if (typeof errCallback === 'function')
								return errCallback("Error occured while querying for startup form");
						}
					}
					
					function innerErrCallback (error) {
						kony.appfoundation.log.error("error while fetching startup from db "+error);
		                if (typeof errCallback === 'function') errCallback(error);						
					}

                }
            }

            function errCallback(error) {
            	kony.appfoundation.log.error("error while fetching metadata from db "+error);
                if (typeof errorCallback === 'function') errorCallback(error);
            }
        } catch (e) {
            if (typeof errorCallback === 'function') errorCallback(e);
            kony.appfoundation.log.error("exception occurred"+e);
        }
    },
	setUIConfig:function(entityFormData, successCallback, errorCallback){
		throw "This method is not supported";
	},
	getAppMenuJson : function(successCallback, errorCallback){
		try{
			var channelName = kony.appfoundation.Utils.getChannelName();
			var query = "select ap.key, ap.value as value from applicationproperties ap ";
			var provider = new kony.appfoundation.DataService(false,false);
	    	syncProvider = provider.getDataProvider();
			syncProvider.executeSelectQuery(query,succCallback,errCallback);
			
			function succCallback(response){
				if(typeof successCallback === 'function'){
					kony.appfoundation.log.debug(" in sync get app props json ");
					if(response){
						for(var i=0; i<response.length; i++){
							response[i]["value"] = JSON.parse(response[i]["value"]);
						}
						successCallback(response);
					} else {
						successCallback();
					}
				}
			}
	
			function errCallback(error){
				kony.appfoundation.log.error("Error Response in get App menu json --- "+ error.toString());
				if(typeof errorCallback === 'function')
					errorCallback(error);
			}
		} catch(e) {
			kony.appfoundation.log.debug("Exception occurred - getAppMenuJson --> "+e.toString());
			if(typeof errorCallback === 'function')
				errorCallback(e);
		}
			
	} 
});

kony.appfoundation.UIConfigRESTProvider = Class(kony.appfoundation.UIConfigDataProvider,{
	constructor:function(sessionToken, mockedDevice){
        this.$class.$super.call(this, sessionToken, mockedDevice); 
    },
    fetchDataFromDataStore: function(type, sqlFetchStr, succCallback, errCallback){
    	function onFetchSuccess(response){
    		kony.appfoundation.log.info(type+" Data fetch response from local db");
    		var responseJSONObject = {};
    		if(type === "templates"){
    			responseJSONObject["formData"] = [];
    			for ( var i in response) {
					var responseObject = response[i];
					try{
						responseJSONObject["formData"].push(JSON.parse(responseObject["formData"]));
						responseJSONObject["fetchTime"] = responseObject["fetchTime"];
					}catch(e){
						errCallback(e);
						return;
					}
				}
    		} else if(type === "forms"){
    			responseJSONObject["formData"] = [];
    			for(var i in response){
    				var responseObject = response[i];
    				try{
						responseJSONObject["fetchTime"] = responseObject["fetchTime"];
						responseJSONObject["formData"].push(JSON.parse(responseObject["formData"]));
					} catch(e){
						errCallback(e);
						return;
					}
    			}
    		}
    		succCallback(responseJSONObject);
    	}
    	function onFetchFailure(error){
    		kony.appfoundation.log.error("Db/table doesnot exist, templateData fetch error---");
			errCallback(error);
    	}
    	kony.appfoundation.Utils.executeSingleSqlQuery(kony.appfoundation.constants["AFNLocalDBName"], sqlFetchStr, null, onFetchSuccess, onFetchFailure);
    },
    saveDataIntoDataStore: function(type, dataObj, succCallback, errCallback){
    	var str_fetchTime = dataObj["fetchTime"];
    	var dbName = kony.appfoundation.constants["AFNLocalDBName"];
    	var values_array = [];
    	createTblIfNotExists();
    	
    	function createTblIfNotExists(){
    		kony.appfoundation.log.info("checking/creating formData table");
    		var tblCreationSQLStmt = "";
    		if(type === "templates"){
    			tblCreationSQLStmt = "CREATE TABLE if not exists AFNtemplateData (id integer PRIMARY_KEY, formData text, fetchTime text)";
    		} else if(type === "forms"){
    			tblCreationSQLStmt = "CREATE TABLE if not exists AFNformData (id integer PRIMARY_KEY, formData text, fetchTime text)";
    		} else {
    			errCallback();//TODO: wrong type passed
    		}
			kony.appfoundation.Utils.executeSingleSqlQuery(dbName , tblCreationSQLStmt, null, createTableOnSuccess, createTableOnError);
    	}
    	function createTableOnSuccess(response){
			kony.appfoundation.log.info("create table success---"+response);
			var query, tableName;
			function deleteAllRecords(){
				if(type === "templates"){
					tableName = "AFNtemplateData";
					query = "DELETE FROM AFNtemplateData;"
				} else if(type === "forms"){
					tableName = "AFNformData";
					query = "DELETE FROM AFNformData;"
				}
				kony.appfoundation.Utils.executeSingleSqlQuery(dbName, query, null, deleteCallback, errCallback);	//delete all existing records
				function deleteCallback(response){
					if(response !== null){
						for(var idx = 0;  idx < dataObj["formData"].length; idx++){
			    			var values_table = {};
			    			values_table["id"] = idx + 1;
			    			values_table["formData"] = JSON.stringify(dataObj["formData"][idx]);
			    			values_table["fetchTime"] = str_fetchTime;
			    			values_array.push(values_table);
			    		}
						kony.appfoundation.Utils.batchInsert(dbName, tableName, values_array, succCallback, errCallback)
					} else {
						errCallback();
					}
				}
			}
			deleteAllRecords();
		}
		function createTableOnError(error){
			kony.appfoundation.log.error("create table error---- ");
			errCallback();
		}
    },
    updateFetchTimeIntoDataStore: function(type, fetchTime, succCallback, errCallback){
    	var sqlUpdate = "";
    	if(type === "templates"){
    		sqlUpdate = "Update AFNtemplateData set fetchTime = '"+fetchTime+"';";
    	} else if(type === "forms"){
    		sqlUpdate = "Update AFNformData set fetchTime = '"+fetchTime+"';";
    	}
    	kony.appfoundation.Utils.executeSingleSqlQuery(kony.appfoundation.constants["AFNLocalDBName"], sqlUpdate, null, succCallback, errCallback);
    },
	getThemesData:function(successCallback, errorCallback){
    	kony.appfoundation.log.debug("in getthemesdata");
    	var platformName = kony.appfoundation.Utils.getPlatformName(); 
    	var url = kony.appfoundation.constants.THEME_ENDPOINT + "?$platform="+platformName;
    	var headers = {Accept: "application/json", session_token: this.sessionToken.token};;
    	if(!kony.appfoundation.constants["ISCLOUD"]){
			headers["tenant"] = this.sessionToken.tenant;
		}
    	function callbackHandler(result){
    		if(typeof successCallback === 'function')
    			successCallback(result);
    	}
    	kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants.HTTP_METHOD_GET, headers, callbackHandler, errorCallback, null);
    },
	getTemplates:function(successCallback, errorCallback, forVisualizer){
		
		if(this.mockDevice && this.mockDevice.isMocked){
			kony.appfoundation.log.debug("in gettemplates get config");
            var testData = this.mockDevice.data;
            var result = testData.testTemplatesJson;
            if(result)
            	successCallback(result);
            else {
            	kony.appfoundation.log.error("in error");
            	errorCallback("Error");
            }
            	
        } else {
        	var sqlStrng = "SELECT id, formData, fetchTime FROM AFNtemplateData;";
        	var lastFetchTime;
			var lastFetchedTmpltData;
			var scopeObj = this;
			var metadatatype = "templates";
        	this.fetchDataFromDataStore(metadatatype, sqlStrng, fetchSuccessCallback, fetchErrorCallback);
        	function fetchSuccessCallback(response){
        		kony.appfoundation.log.info("fetchfromdatastore for templates finish!! ");
				lastFetchedTmpltData = response;
				if(response !== null && response["fetchTime"]){
					lastFetchTime = new String(lastFetchedTmpltData["fetchTime"]);
					kony.appfoundation.log.info("template lastFetchTime ---"+lastFetchTime);
				} else {
					lastFetchTime = null;
				}
				getTemplatesFromService();
        	}
        	function fetchErrorCallback(error){
        		kony.appfoundation.log.error("Fetching stored templateData failed!! Calling getuiconfig");
				lastFetchTime = null;
				getTemplatesFromService();
        	}
        	
        	function getTemplatesFromService(){
        		kony.appfoundation.log.debug("in gettemplates else get config");
	            if(forVisualizer === undefined || forVisualizer === null)
	            forVisualizer = true;   
	            var channelName = kony.appfoundation.Utils.getChannelName();
	            var platformName = kony.appfoundation.Utils.getPlatformName();         
	            var url = kony.appfoundation.constants.TEMPLATES_ENDPOINT + "?$select=formjs,formconfig&$platform="+ platformName +"&$channel="+channelName;
	            if(lastFetchTime !== undefined && lastFetchTime !== null){
	            	url = url + "&$lastfetchtime="+ lastFetchTime;
	            }
	            var headers = {Accept: "application/json", session_token: scopeObj.sessionToken.token};
	            if(!kony.appfoundation.constants["ISCLOUD"]){
					headers["tenant"] = scopeObj.sessionToken.tenant;
				}
	            kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants.HTTP_METHOD_GET, headers, callbackHandler, errorCallback, null);	
        	}
        	
        }
        
        function callbackHandler(response){
			if(typeof successCallback === 'function'){
				var result = {};
				var fetchTime = response.fetchTime;
				if(response && (response.changeAfterLastFetchTime === true || response.changeAfterLastFetchTime === "true")){
					//kony.print(" Response from service to get templates " + kony.appfoundation.util.stringifyKonyObject(response));
					kony.appfoundation.log.info("****TemplateData fetched from service****");
					result = response;
					var templateDataObj = {"formData": response.entityFormData, "fetchTime": fetchTime};
					scopeObj.saveDataIntoDataStore(metadatatype, templateDataObj, callback, saveErrCallback);
            	} else if(response && (response.changeAfterLastFetchTime === false || response.changeAfterLastFetchTime === "false")){
            		result.entityFormData = lastFetchedTmpltData["formData"];
            		kony.appfoundation.log.info("****TemplateData fetched from localdb****");
            		scopeObj.updateFetchTimeIntoDataStore(metadatatype, fetchTime, callback, saveErrCallback);
            	} else { //for response === undefined || response === null || response.changeAfterLastFetchTime anything else than true/false
            		errorCallback(new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_LOADING_TEMPLATES, kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_LOADING_TEMPLATES));
            	}
            	function callback(){
					successCallback(result);
				} 
				function saveErrCallback(){
					kony.print("Error saving to db ");
					successCallback(result);	
				}	
			}
				
		}					
			
	},		
	getUIConfig:function(entityName, successCallback, errorCallback, forVisualizer){
		
		if(this.mockDevice && this.mockDevice.isMocked) {
            var testData = this.mockDevice.data;	
            var result = testData.testFormJson;
            if(result)
            	successCallback(result);
            else {
            	errorCallback("Error");
            }
        } else {
        	var sqlStrng = "SELECT id, formData, fetchTime FROM AFNformData;";
        	var lastFetchTime;
			var lastFetchedTmpltData;
			var scopeObj = this;
			var metadatatype = "forms";
        	this.fetchDataFromDataStore(metadatatype, sqlStrng, fetchSuccessCallback, fetchErrorCallback);
        	function fetchSuccessCallback(response){
        		kony.appfoundation.log.info(" fetchfromdatastore for forms finish!! ");
				lastFetchedFormData = response;
				if(response !== null && response["fetchTime"]){
					lastFetchTime = new String(lastFetchedFormData["fetchTime"]);
					kony.appfoundation.log.info("forms lastFetchTime ---"+lastFetchTime);
				} else {
					lastFetchTime = null;
				}
				getFormsFromService();
        	}
        	function fetchErrorCallback(err){
        		kony.appfoundation.log.info("Fetching stored lastFetchedFormData failed!! Calling getuiconfig");
				lastFetchTime = null;
				getFormsFromService();
        	}
        	
        	function getFormsFromService(){
	            if(forVisualizer === undefined || forVisualizer === null)
	           		forVisualizer = true;
	            var entityURI = undefined;
	            if(entityName === undefined || entityName === null || entityName == "") {
	                entityURI = "";
	            } else {
	                entityURI = "&$entity=" + entityName;
	            }   
	            var url = undefined;
	            if(forVisualizer){
	                url = kony.appfoundation.constants.UICONFIG_ENDPOINT + "?$select=formjson,formconfig" + entityURI;
	            } else {
	                var channelName = kony.appfoundation.Utils.getChannelName();
	                var platformName = kony.appfoundation.Utils.getPlatformName(); 
	                url = kony.appfoundation.constants.UICONFIG_ENDPOINT + "?$select=formjs,formconfig&$platform="+ platformName + "&$channel="+ channelName;
	                if(lastFetchTime !== undefined && lastFetchTime !== null){
	            		url = url + "&$lastfetchtime="+ lastFetchTime;
	            	}
	                url = url + entityURI;
	            }
	            var headers = {Accept: "application/json", session_token: scopeObj.sessionToken.token};
	            if(!kony.appfoundation.constants["ISCLOUD"]){
					headers["tenant"] = scopeObj.sessionToken.tenant;
				}
	            kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants.HTTP_METHOD_GET, headers, callbackHandler, errorCallback, null);
        	}
        	
        }
        function callbackHandler(response){
        	var result = {};
        	var fetchTime = response.fetchTime;
			if(typeof successCallback === 'function'){
				if(response && (response.changeAfterLastFetchTime === true || response.changeAfterLastFetchTime === "true")){
					result = response;
					var fetchTime = response.fetchTime; 
					var formDataObj = {"formData": response.entityFormData, "fetchTime": fetchTime};
					//kony.appfoundation.log.info(" response from service to get forms "+ kony.appfoundation.util.stringifyKonyObject(response));	
					kony.appfoundation.log.info("****FormData fetched from service****");
					scopeObj.saveDataIntoDataStore(metadatatype, formDataObj, callback, saveErrCallback);
				} else if(response && (response.changeAfterLastFetchTime === false || response.changeAfterLastFetchTime === "false")){
					kony.appfoundation.log.info("****FormData fetched from localdb****");
					result.entityFormData = lastFetchedFormData["formData"];
					result.startUpFormData = response.startUpFormData;		// we don't save startup data, we use the service response iteslf.
					scopeObj.updateFetchTimeIntoDataStore(metadatatype, fetchTime, callback, saveErrCallback);
					
				}else { //for response === undefined || response === null || response.changeAfterLastFetchTime anything else than true/false
            		errorCallback( new kony.appfoundation.AppFoundationException(kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_FETCHING_FORMS, kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_FETCHING_FORMS));
            	}
            	
            	function callback(){
					successCallback(result);
				} 
				function saveErrCallback(){
					kony.print("Error saving to db ");
					successCallback(result);	
				}	
			}
				//successCallback(response);
		}		
	},
	setUIConfig:function(entityFormData, successCallback, errorCallback){
		
		var headers = {Accept: "application/json", session_token: this.sessionToken.token, "Content-Type":"application/json"};
		if(!kony.appfoundation.constants["ISCLOUD"]){
			headers["tenant"] = this.sessionToken.tenant;
		}
		
		kony.appfoundation.theAjaxProvider.get(kony.appfoundation.constants.UICONFIG_ENDPOINT, kony.appfoundation.constants.HTTP_METHOD_POST, headers, successCallback, errorCallback, entityFormData);
	
	},
	getAppMenuJson: function(successCallback, errorCallback){
		
		if(this.mockDevice && this.mockDevice.isMocked) {
			var testData = this.mockDevice.data;	
            var result = testData.getAppMenu;
            if(result){
				callbackHandler(result);
            } else {
            	errorCallback("Error");
            }
		} else {
			var url = kony.appfoundation.constants.APPPROPS_ENDPOINT;
			//url = url + "?$keys="+kony.appfoundation.constants["APP_MENU_KEY"];
			var headers = {Accept: "application/json", session_token: this.sessionToken.token, i18nlocale: kony.appfoundation.getDeviceLocale()};
	        if(!kony.appfoundation.constants["ISCLOUD"]){
				headers["tenant"] = this.sessionToken.tenant;
			}
	        kony.appfoundation.theAjaxProvider.get(url, kony.appfoundation.constants.HTTP_METHOD_GET, headers, callbackHandler, errorCallback, null);
		}
        function callbackHandler(result){
        	kony.appfoundation.log.info("Response in get App menu json --- ");
        	if(typeof successCallback === 'function') {
				if(result && result["Response"] !== null && result["Response"] !== undefined){
					successCallback(result["Response"]);
				} else {
					successCallback();				
				}
			}
		}
	}	
	
});

kony.appfoundation.UIConfigService = Class({
	constructor:function(serverStatus, mockDevice){
        var isOnline;
        var uiConfigProviderInstance;
        this.isOnline = serverStatus;
        this.mockDevice = mockDevice;
    },
	getUIConfigProvider:function(sessionToken){
		if(this.isOnline === true){
			this.uiConfigProviderInstance = new kony.appfoundation.UIConfigRESTProvider(sessionToken, this.mockDevice);
			return this.uiConfigProviderInstance;
		}else{
			this.uiConfigProviderInstance = new kony.appfoundation.UIConfigSyncProvider(sessionToken, this.mockDevice);
			return this.uiConfigProviderInstance;
		}
	}
});

/**
 * These are all the enum functions that consists of key-value pairs used in
 * constructing Criteria Object.
 */
kony.appfoundation.Aggregation = {
	NONE : "",
	COUNT : "COUNT",
	SUM : "SUM",
	MAX : "MAX",
	MIN : "MIN",
	AVG : "AVG"
};

kony.appfoundation.OrderType = {
	ASCENDING : "ASC",
	DESCENDING : "DESC"
};

kony.appfoundation.MatchType = {
	EQUALS : {
		value : "=",
		name : "EQUALS"
	},
	GREATER : {
		value : ">",
		name : "GREATER"
	},
	GREATEREQUAL : {
		value : ">=",
		name : "GREATEREQUAL"
	},
	LESS : {
		value : "<",
		name : "LESS"
	},
	LESSEQUAL : {
		value : "<=",
		name : "LESSEQUAL"
	},
	STARTSWITH : {
		value : "LIKE",
		name : "STARTSWITH"
	},
	CONTAINS : {
		value : "LIKE",
		name : "CONTAINS"
	},
	LIKE : {
		value : "LIKE",
		name : "LIKE"
	},
	ENDSWITH : {
		value : "LIKE",
		name : "ENDSWITH"
	},
	NOTEQUAL : {
		value : "<>",
		name : "NOTEQUAL"
	},
	ISNULL : {
		value : "IS NULL",
		name : "ISNULL"
	},
	ISNOTNULL : {
		value : "IS NOT NULL",
		name : "ISNOTNULL"
	}

};

kony.appfoundation.JoinType = {
	INNER : "INNER",
	LEFT : "LEFT",
	RIGHT : "RIGHT"

};

kony.appfoundation.ParameterType = {
	IN : "IN",
	OUT : "OUT",
	INOUT : "INOUT"
};

kony.appfoundation.ColumnUsage = {
	SELECTCOLUMN : "0",
	CRITERIACOLUMN : "1",
	UPDATECOLUMN : "2",
	INSERTCOLUMN : "3"
};

kony.appfoundation.Operator = {
	AND : "AND",
	OR : "OR"
};
var getMetricsPayload=function()
{
 //constructing metris

    var deviceInfo = kony.os.deviceInfo();
    kony.appfoundation.log.info("device info");
    var name=deviceInfo.name;
    var platform,channel;
    
    platform=kony.appfoundation.Utils.getPlatformName();
    channel=kony.appfoundation.Utils.getChannelName();
    if(platform==="iphone"||platform==="ipad")
    	platform="ios";
    else
    	platform="android";
    
    var devicemodel=deviceInfo.model;
    var deviceid=deviceInfo.deviceid;
    var deviceos=deviceInfo.version;
    
    if(devicemodel !== null && typeof devicemodel === 'number'){
    	devicemodel=devicemodel.toString();
    }
    if(deviceid !== null && typeof deviceid === 'number'){
    	deviceid=deviceid.toString();
    }
    if(deviceos !== null && typeof deviceos === 'number'){
    	deviceos=deviceos.toString();
    }
    
    var payload={
    	    plat : platform,
    	    chnl : channel,
    	    dm : devicemodel,
    	    did : deviceid,
    	    os : deviceos
    	    }
    return payload;
}
kony.appfoundation.authenticateService = function(username, password, tenant,
		authenticateSuccesscallback, authenticateErrorcallback,connectToUpgradedVersion) {
	var headers = {
		username : username,
		password : password,
		connectToUpgradedVersion:connectToUpgradedVersion
	};
	if(!kony.appfoundation.constants["ISCLOUD"]){
		headers["tenant"] = tenant;
	}
	if(kony.appfoundation.metricsPayload==null){
		kony.appfoundation.metricsPayload=getMetricsPayload();
	}
	
	
	kony.appfoundation.theAjaxProvider.get(kony.appfoundation.constants.AUTH_ENDPOINT,
			kony.appfoundation.constants.HTTP_METHOD_POST, headers, callbackHandler,
			authenticateErrorcallback,kony.appfoundation.metricsPayload, true);

	function callbackHandler(response) {
		var result;
		if (typeof authenticateSuccesscallback === 'function') {
			if (response !== null && response !== undefined) {
				if (typeof response === 'string' || response instanceof String) {
					result = JSON.parse(response);
				} else {
					result = response;
				}
				var authResult = new Object();
				authResult["token"] = result["session_token"];
				authResult["tenant"] = tenant;
				authResult["version"] = result.version;
				if(result["sync_auth_token"]!=undefined && result["sync_auth_token"]!=null){
					authResult["sync_auth_token"] = result["sync_auth_token"];
				}
				if(result["isTenantSyncEnabled"]!=undefined && result["isTenantSyncEnabled"]!=null){
					authResult["isTenantSyncEnabled"] = result["isTenantSyncEnabled"];
				}
			}
			kony.appfoundation.getUserAuthProfile(authResult, authenticateSuccesscallback, authenticateErrorcallback);
		}
	}
}

kony.appfoundation.getUserProfile = function(access_token, refresh_token, instance_url, user_id,
		tenant, authenticateSuccesscallback, authenticateErrorcallback,connectToUpgradedVersion) {
	var headers = {
		access_token : access_token,
		user_id : user_id,
		refresh_token : refresh_token,
		instance_url : instance_url,
		connectToUpgradedVersion:connectToUpgradedVersion
	};
	if(!kony.appfoundation.constants["ISCLOUD"]){
		headers["tenant"] = tenant;
	}
	
	if(kony.appfoundation.metricsPayload==null){
		kony.appfoundation.metricsPayload=getMetricsPayload();
	}
	
	
	kony.appfoundation.theAjaxProvider.get(kony.appfoundation.constants.AUTH_USER_PROFILE_ENDPOINT,
			kony.appfoundation.constants.HTTP_METHOD_POST, headers, callbackHandler,
			authenticateErrorcallback,kony.appfoundation.metricsPayload);

	function callbackHandler(response) {
		var result;
		kony.appfoundation.v2.ApplicationContext.dismissLoadingScreen();
		if (typeof authenticateSuccesscallback === 'function') {
			if (response !== null && response !== undefined) {
				if (typeof response === 'string' || response instanceof String) {
					result = JSON.parse(response);
				} else {
					result = response;
				}
				var authResult = new Object();
				authResult["token"] = result["session_token"];
				authResult["username"] = result["username"];
				authResult["tenant"] = tenant;
				authResult["version"] = result.version;
				authResult["isTenantSyncEnabled"] =  result["isTenantSyncEnabled"];
			}
			kony.appfoundation.getUserAuthProfile(authResult,authenticateSuccesscallback,authenticateErrorcallback);
		}
	}
}

kony.appfoundation.getUserAuthProfile = function(authResult,successcallback,errorcallback){
	var headers = {};
	headers["session_token"] = authResult["token"];
	
	if(!kony.appfoundation.constants["ISCLOUD"]){
		headers["tenant"] = authResult["tenant"];
	}
	kony.appfoundation.v2.ApplicationContext.showLoadingScreen("Getting User Auth Profile...");
	kony.appfoundation.print("Getting User Auth Profile...")
	kony.appfoundation.theAjaxProvider.get(kony.appfoundation.constants.AUTH_USER_AUTH_PROFIlE_ENDPOINT,
			kony.appfoundation.constants.HTTP_METHOD_GET, headers, callbackHandler,
			errorcallback, null);

	function callbackHandler(response) {
		var result;
		if (typeof successcallback === 'function') {
			if (response !== null && response !== undefined) {
				if (typeof response === 'string' || response instanceof String) {
					result = JSON.parse(response);
				} else {
					result = response;
				}
				
				authResult["authprofile"] = result["authprofile"];
				kony.appfoundation.v2.ApplicationContext.AUTHPROFILE = result["authprofile"];
				kony.appfoundation.print("received authprofile for logged in user as ")
			}
			successcallback(authResult);
		}
	}
}

kony.appfoundation.parseEntityMetadataResponse = function(response,methodName){
	var entities = [];
	var entityMetadata = new kony.appfoundation.EntityMetadata();
	entityMetadata.fields = [];
	entityMetadata.childRelationshipList = [];
	var entityDetails = new kony.appfoundation.EntityDetails(); 
	if (response !== null && response !== undefined) {
        for (var i = 0; i < response.length; i++) {
            var fm = new kony.appfoundation.FieldMetadata();
            var pickListAdded = false;
            fm.fieldMappingId = response[i]["fieldMappingId"];
            fm.name = response[i]["fieldName"];
            fm.displayName = response[i]["fmDisplayName"];
            fm.sourceFieldName = response[i]["fmSrcName"];
            fm.type = response[i]["fmDataType"];
            if(response[i]["fmIsCustom"] !== undefined && response[i]["fmIsCustom"] !== null){
            	fm.custom = (response[i]["fmIsCustom"] === "true") ? true:false;
            }
            if(response[i]["fmIsCreateable"] !== undefined && response[i]["fmIsCreateable"] !== null){
            	fm.createable = (response[i]["fmIsCreateable"] === "true") ? true:false;
            }
            if(response[i]["fmIsUpdateable"] !== undefined && response[i]["fmIsUpdateable"] !== null){
            	fm.updateable = (response[i]["fmIsUpdateable"] === "true") ? true:false;
            }
            if(response[i]["fmIsCustomizable"] !== undefined && response[i]["fmIsCustomizable"] !== null){
            	fm.customizable = (response[i]["fmIsCustomizable"] === "true") ? true:false;
            }
            if(response[i]["fmIsAudit"] !== undefined && response[i]["fmIsAudit"] !== null){
            	fm.auditColumn = (response[i]["fmIsAudit"] === "true") ? true:false;
            }
            if(response[i]["fmHasIndx"] !== undefined && response[i]["fmHasIndx"] !== null){
            	fm.hasIndex = (response[i]["fmHasIndx"] === "true") ? true:false;
            }
            if(response[i]["fmIsNullable"] !== undefined && response[i]["fmIsNullable"] !== null){
            	fm.nullable = (response[i]["fmIsNullable"] === "true") ? true:false;
            }
            if(response[i]["fmIsPrimaryKey"] !== undefined && response[i]["fmIsPrimaryKey"] !== null){
            	fm.primaryKey = (response[i]["fmIsPrimaryKey"] === "true") ? true:false;
            }
            if(response[i]["fmIsNameField"] !== undefined && response[i]["fmIsNameField"] !== null){
            	fm.nameField = (response[i]["fmIsNameField"] === "true") ? true:false;
            }
            
            if(response[i]["fmIsUnique"] !== undefined && response[i]["fmIsUnique"] !== null){
            	fm.unique = (response[i]["fmIsUnique"] === "true") ? true:false;
            }
            if(response[i]["fmRelationshipId"] !== undefined && response[i]["fmRelationshipId"] !== null){
            	fm.relationshipId = parseInt(response[i]["fmRelationshipId"]);
            }
            
            fm.foreignKeyFieldName = response[i]["foreign_key"];
         	fm.table = response[i]["entityName"];
           	if(!(fm.foreignKeyFieldName) && !(fm.foreignKeyFieldName != "")){
           		fm.foreignKey = true;
           	}else{
           		fm.foreignKey = false;
           	}

	        
           	if(kony.appfoundation.Utils.matchIgnoreCase(fm.type, kony.appfoundation.constants["picklist"])|| 
					kony.appfoundation.Utils.matchIgnoreCase(fm.type, kony.appfoundation.constants["picklistmultiselect"])){
				var pickListValues = [];
				
				var pickList;
				pickList = new kony.appfoundation.PickList();
				pickList.setId(response[i]["pickid"]);
				pickList.setFieldMappingId(response[i]["pickfieldmappingid"]);
				pickList.setActive(response[i]["pickactive"]);
				pickList.setLabel(response[i]["picklabel"]);
				pickList.setValue(response[i]["pickvalue"]);
				if(response[i]["pickdefaultvalue"] !== undefined && response[i]["pickdefaultvalue"] !== null){
					pickList.setDefaultValue((response[i]["pickdefaultvalue"] === "true") ? true:false);
				}
				pickList.setValidFor(response[i]["pickvalidfor"]);
				for(var k=0; k<entityMetadata.fields.length; k++){
					if(entityMetadata.fields[k]["fieldMappingId"] === response[i]["fieldMappingId"]){
						var tempFM = entityMetadata.fields[k];
						tempFM.pickListValues.push(pickList);
						entityMetadata.fields[k] = tempFM;
						pickListAdded = true;
					}
				}
				if(pickListAdded === false){
					pickListValues.push(pickList);
					fm.pickListValues = pickListValues;
				}
           	}
           	if(kony.appfoundation.Utils.matchIgnoreCase(fm.type, kony.appfoundation.constants["reference"])){
           		fm.parentFieldName = response[i]["parentNameField"];
           		fm.parentTableName = response[i]["referenceTo"];
           		fm.parentPrimaryKeyName = response[i]["referencingField"];
           		fm.referenceTo = response[i]["referenceTo"];
           		fm.relationshipName = response[i]["relationshipName"];
           		fm.referencingField = response[i]["referencingField"];
           		
			}
           	
           	if(kony.appfoundation.Utils.matchIgnoreCase(fm.type, kony.appfoundation.constants["extendedfield"])){
           		fm.parentTableName = response[i]["referenceTo"];
                fm.parentFieldName = response[i]["parent_fieldname"];             	
                fm.referencedField = response[i]["referencedField"];        	
           	}
			
            if(entityMetadata.entityTypeID == undefined || entityMetadata.entityTypeID != response[i]["entityId"]){
            	//if(entityMetadata.entityTypeID !== undefined){
            		entityMetadata = new kony.appfoundation.EntityMetadata();
            		entityMetadata.fields=[];
	            	entityMetadata.fields.push(fm);
	            	entityMetadata.childRelationshipList = [];
	            	kony.appfoundation.log.debug("entityMetadata is initialized ",entityMetadata);
            	//}
            	if(fm.primaryKey == true || fm.primaryKey == "true"){
                	entityDetails.primaryKeyName = fm.name;
    				entityMetadata.primaryKeyName = fm.name;
    				entityDetails.primaryKeyDatatype = fm.type;
    				entityMetadata.primaryKeyDatatype = fm.type;
                }
                if(fm.nameField == true  || fm.nameField == "true"){
                	entityDetails.primaryFieldName = fm.name;
    				entityMetadata.primaryFieldName = fm.name;
    				entityDetails.primaryFieldDatatype = fm.type;
    				entityMetadata.primaryFieldDatatype = fm.type;
    			}
	            entityMetadata.entityTypeID = response[i]["entityId"];
	            entityMetadata.name = response[i]["entityName"];
	            entityMetadata.displayName = response[i]["entDisplayName"];
				entityDetails.entityName =response[i]["entityName"];
	            entityMetadata.sourceEntityName = response[i]["entSrcName"];
	            entityMetadata.customizable = response[i]["entIsCustomizable"];
	            entityMetadata.updateable = response[i]["updateable"];
	            entityMetadata.junction = response[i]["entJunction"];
	            entityMetadata.custom = response[i]["custom"];
	            entityMetadata.entityDetails = entityDetails;
	            entities.push(entityMetadata);
            }
            else{
	            if(pickListAdded === false){
	            	kony.appfoundation.log.debug("fm being pushed for entity"+response[i]["entityName"]+" is === ",fm);
					if(fm.primaryKey == true || fm.primaryKey == "true"){
	                	entityDetails.primaryKeyName = fm.name;
	    				entityMetadata.primaryKeyName = fm.name;
	    				entityDetails.primaryKeyDatatype = fm.type;
	    				entityMetadata.primaryKeyDatatype = fm.type;
	                }
	                if(fm.nameField == true  || fm.nameField == "true"){
	                	entityDetails.primaryFieldName = fm.name;
	    				entityMetadata.primaryFieldName = fm.name;
	    				entityDetails.primaryFieldDatatype = fm.type;
	    				entityMetadata.primaryFieldDatatype = fm.type;
	    			}
					entityMetadata.fields.push(fm);
				}
            }
        }
        kony.appfoundation.log.info("methodName is "+methodName + "entities response length is "+entities.length);
        if(methodName == "getEntities"){
        	for(var i=0;i<entities.length;i++){
        		var curr = entities[i];
				kony.appfoundation.log.info("entities["+i+"][name] is "+
						curr["name"]+"entities["+i+"][entityTypeID] is "+
							curr["entityTypeID"]+" entities["+i+"].fields.length is "+
								curr.fields.length);
        	}
        }
        
        if(methodName == "getEntity"){
        	if(entities.length == 1){
        		return entities[0];
        	}
        	else{
	        	return entities;
        	}
        }else{
        	return entities;
        }
    }
 	return entities;
}

kony.appfoundation.parseEntityRelationshipResponse = function(response){
	var relationships = [];
	if (response !== null && response !== undefined) {
        for (var i = 0; i < response.length; i++) {
        	if(response[i]["relationshipName"] !== undefined && response[i]["relationshipName"] !== null && response[i]["relationshipName"] !== ""){
 			   var childRelation = new kony.appfoundation.EntityRelationship();
 			   childRelation["entityName"] = response[i]["childEntityName"];
 			   childRelation["entityPageTemplateId"] = 0;
 			   childRelation["id"] = response[i]["id"];
 			   childRelation["parentEntity"] = response[i]["parentEntityName"];
 			   childRelation["referencingField"] = response[i]["referencing_field_name"];
 			   childRelation["relationshipName"] = response[i]["relationshipName"];
 			   childRelation["relationshipType"] = response[i]["relationshipType"];
 			   childRelation["custom"] = response[i]["isCustom"];
 			   childRelation["junctionTableName"] = response[i]["junction_table"];
 			   childRelation["operationType"] = "PATCH";
 			   relationships.push(childRelation);
		   }
        }
    }
    return relationships;

}
kony.appfoundation.validateDataType = function(dataType, fieldValue, fieldMetadata, result){
	dataType = dataType.toLowerCase();
	kony.print("Field DataType : "+dataType);

	// we are getting dataType for numberic(otherthan saleforce) with precision and scale, like numberic(4,3)... so adding validations.
	var numericObj = {};
	var regexNumeric = /^numeric[(]([1-9][0-9]{0,2}|1000),([0-9]{0,3}|1000)[)]$/;
	if(dataType.search(regexNumeric) !== -1){
	  numericObj.precision = dataType.substring(dataType.indexOf("(")+1, dataType.indexOf(","))
	  numericObj.scale = dataType.substring(dataType.indexOf(",")+1, dataType.indexOf(")"))
	  numericObj.val = fieldValue;
	  dataType = "numeric"
	}
	   
    switch (dataType) {
   		case "int":
        case "integer":
        	if(!kony.appfoundation.Utils.isValidInteger(fieldValue))
        		result.isValid = false;
        	break;
        case "email":
        	//TO-DO
        	//data type not present on server side
        	break;
		case "varchar":
        case "text":
			//null and empty check already done
			break;
        case "picklist":
			if(fieldValue !== "" && !kony.appfoundation.Utils.isValidPickListData(fieldValue, fieldMetadata.pickListValues, fieldMetadata.fieldMappingId))
				result.isValid = false;
        	break;
        case "multipicklist":
        	//no datatype validation required, not implemented a multipicklist yet
        	break;	
        case "boolean":
        	if(!kony.appfoundation.Utils.isValidBooleanType(fieldValue))
        		result.isValid = false;
        	break;
        case "date":
        	var regExp = /^((\d{4})(-)(0[1-9]|1[012])(-)(0[1-9]|1[0-9]|2[0-9]|3[01]))$/;
        	if(fieldValue.search(regExp) === -1)
        		result.isValid = false;
        	break;
        case "timestamp":
        	var regExp = /^((\d{4})(-)(0[1-9]|1[012])(-)(0[1-9]|[12][0-9]|3[01])\s([01][0-9]|2[0-3])(:)([0-5][0-9])(:)([0-5][0-9])(.)(\d{1}|\d{2}|\d{3}|\d{4}|\d{5}|\d{6}))$/;
                if (fieldValue.search(regExp) === -1) {
                    regExp = /^((\d{4})(-)(0[1-9]|1[012])(-)(0[1-9]|[12][0-9]|3[01])\s([01][0-9]|2[0-3])(:)([0-5][0-9])(:)([0-5][0-9]))$/;
                    if (fieldValue.search(regExp) === -1) {
                    	result.isValid = kony.appfoundation.util.isValidDateFormat(fieldValue);
                    }
                }
                break;
        case "time":
		case "datetime":
        	var regExp = /^((\d{4})(-)(0[1-9]|1[012])(-)(0[1-9]|[12][0-9]|3[01])\s([01][0-9]|2[0-3])(:)([0-5][0-9])(:)([0-5][0-9]))$/;
        	if(fieldValue.search(regExp) === -1)
        		result.isValid = false;
        	//time datatype check not implemented in service yet
        	break;
        case "extendedfield":
        	//no datatype validation required
			break;
        case "id":
        case "serial":
        	//Primary Key Data Types, no datatype validation required
        	break;
        case "reference":
        	//no datatype validation required
        	break;
        case "lookup":
        	//no datatype validation required
        	break;
        case "double":
            if(!kony.appfoundation.Utils.isValidFloat(fieldValue))
        		result.isValid = false;
        	break;
        case "numeric":
			if(!kony.appfoundation.Utils.isValidNumeric(numericObj))
        		result.isValid = false;
        	break;
        //SalesForce DataTypes, not yet implemented on service side
        case "url":
        case "encryptedstring":	
        case "textarea":
        case "string":
        case "phone":
        case "percent":
        case "currency":
        	//validations not implemented on service side
        	break;
		default:{
            kony.print("Not a pre-defined datatype, invalid!!!");
            //Not Blocking unknown dataType, similar to the service side dataType Validation
        }			
    }
    if(!result.isValid){
    	result.errorCode = kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_DATA_VALIDATION_INVALID_INPUT_DATA;
    	result.errorMsg = kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_DATA_VALIDATION_INVALID_INPUT_DATA;
    }
    return result;
}
    
kony.appfoundation.validateFormDataModel = function(model, isInsert, entity){
	var result = {};//Future implementation, if collective failure data needs to be maintained.
	result.isValid = true;
	result.finalmodel = model;
	if(model === undefined || model === null){
		result.isValid = false;
		result.errorCode = kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_DATA_VALIDATION_INVALID_MODEL;
		result.errorMsg = kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_DATA_VALIDATION_INVALID_MODEL;
	}else if(model instanceof kony.appfoundation.Model){
		if(model.entityDetails === undefined || model.entityDetails === null){
			result.isValid = false;
			result.errorCode = kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_DATA_VALIDATION_INVALID_ENTITY;
			result.errorMsg = kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_DATA_VALIDATION_INVALID_ENTITY;
		}else if(model.entityDetails.entityName === undefined ||model.entityDetails.entityName === null
		        ||(model.entityDetails.entityName !== undefined && model.entityDetails.entityName !== null 
			     && model.entityDetails.entityName.toString().trim() === "")){
				result.isValid = false;
				result.errorCode = kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_DATA_VALIDATION_INVALID_ENTITY;
				result.errorMsg = kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_DATA_VALIDATION_INVALID_ENTITY;
		}
	}else{
		if(entity === undefined || entity === null || 
			(entity !== undefined && entity !== null 
			 && entity.toString().trim() === "")){
			result.isValid = false;
			result.errorCode = kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_DATA_VALIDATION_INVALID_ENTITY;
			result.errorMsg = kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_DATA_VALIDATION_INVALID_ENTITY;
		}
	}
	if(!result.isValid){
		return result;
	}
		
	var index, fields, primaryKeyName;
	
		function getFields(payLoad){
			var fields ={};
			var colArray = payLoad["columnValueDto"];
			for(index = 0; index < colArray.length; index++){
				var fieldObj = colArray[index];
				fields[fieldObj["columnName"]] = fieldObj["val"];
				kony.print("GP%% -> FieldName : "+fieldObj["columnName"]+" FieldValue :"+fields[fieldObj["columnName"]]);
			}
			return fields;
		}
		
	if(model instanceof kony.appfoundation.Model){
		kony.print("GP$$ : Entity name : "+model.entityDetails.entityName+" Entity -> "+kony.appfoundation.getCachedEntityMetadata(model.entityDetails.entityName));
		var entityMetadata = kony.appfoundation.getCachedEntityMetadata(model.entityDetails.entityName);
		//primaryKeyName = entityMetadata.primaryKeyName;
		if(entityMetadata !== undefined && entityMetadata !== null)
			fields = entityMetadata.fields;
	}else{
		kony.print("GP$$ : Entity name : "+entity+" Entity -> "+kony.appfoundation.getCachedEntityMetadata(entity));
		var entityMetadata = kony.appfoundation.getCachedEntityMetadata(entity);
		fields = getFields(model);
	}
	if(entityMetadata === undefined || entityMetadata === null){
		result.isValid = false;
		result.errorCode = kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_DATA_VALIDATION_ENTITYMETADATA_NOTFOUND;
		result.errorMsg = kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_DATA_VALIDATION_ENTITYMETADATA_NOTFOUND;
		if(model instanceof kony.appfoundation.Model)
			result.errorField = model.entityDetails.entityName;
		else
			result.errorField = entity;
	}
	if(result.isValid && fields !== undefined && fields !== null && fields !== ''){
    	for(index = 0; index < fields.length; index++ ){
			if(!result.isValid)//For Fail Fast
				break;
			var fieldMetadata = fields[index];
			if(!isInsert && fieldMetadata.primaryKey !== undefined && fieldMetadata.primaryKey !== null 
				&& fieldMetadata.primaryKey === true)
				continue;
			result.errorField = fieldMetadata.name;
			var nullable = fieldMetadata.nullable;
			var dataType = fieldMetadata.type;
			var createable = fieldMetadata.createable;
			var updateable = fieldMetadata.updateable;
			var fieldValue = model.get(fieldMetadata.name);
			kony.print("GP@ : FieldMetadata name : "+fieldMetadata.name+" Model FieldValue : "+fieldValue);
			if(isInsert){
				if(createable){
					if(!nullable && (fieldValue === undefined || fieldValue === null || (fieldValue !== undefined && fieldValue !== null && fieldValue.toString().trim() === ""))){
						result.isValid = false;
						result.errorCode = kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_DATA_VALIDATION_FIELD_NOT_NULLABLE;
						result.errorMsg = kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_DATA_VALIDATION_FIELD_NOT_NULLABLE;
					}
					if(result.isValid && fieldValue !== undefined && fieldValue !== null && fieldValue.toString().trim() !== ""){
						kony.appfoundation.validateDataType(dataType, fieldValue, fieldMetadata, result);
					}
				}else{
					if(fieldValue === "") {
						delete model.fields[fieldMetadata.name];
					} else if(!(fieldValue === undefined || fieldValue === null)){
						result.isValid = false;
						result.errorCode = kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_DATA_VALIDATION_FIELD_NOT_CREATEABLE;
						result.errorMsg = kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_DATA_VALIDATION_FIELD_NOT_CREATEABLE;
					}
				}
			}else{
				if(updateable){
					if(fieldValue !== undefined){//in update case field values will be undefined, if they are not updated.
						if(!nullable && (fieldValue === null || fieldValue.toString().trim() === "")){
							result.isValid = false;
							result.errorCode = kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_DATA_VALIDATION_FIELD_NOT_NULLABLE;
							result.errorMsg = kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_DATA_VALIDATION_FIELD_NOT_NULLABLE;
						}
						if(result.isValid && fieldValue !== null && fieldValue.toString().trim() !== ""){
							kony.appfoundation.validateDataType(dataType, fieldValue, fieldMetadata, result);
						}	
					}
				}else{
					if(fieldValue !== undefined){//in update case field values will be undefined, if they are not updated.
						result.isValid = false;
						result.errorCode = kony.appfoundation.AppFoundationExceptionCode.CD_ERROR_DATA_VALIDATION_FIELD_NOT_UPDATEABLE;
						result.errorMsg = kony.appfoundation.AppFoundationExceptionCode.MSG_ERROR_DATA_VALIDATION_FIELD_NOT_UPDATEABLE;
					}
				}
			}
    	}
    	result.finalmodel = model;	
	}
	if(!result.isValid)
		kony.print("GP$$ --> Validation Error : ");
	return result;
}


//This function is called as a handler to pre-appinit event for creating dummy app menu
/* function createAppMenuOnAppInit(){
	var appMenuItem1 = ["appmenuitemid1", "Main1", "account_icova.png", onClickClosure1];
	var appMenu = [appMenuItem1];
	kony.application.createAppMenu(kony.appfoundation.AppMenuId, appMenu, "skn1", "fcskn1");
	kony.application.setCurrentAppMenu(kony.appfoundation.AppMenuId);
	function onClickClosure1(){     
		return;
	}
} */

/*
 * This is the starting method for cascade delete and should be called.
 * Other methods below are helper methods.
 */
kony.appfoundation.deleteRecordCascade = function(model, id, successCallback, errorCallback){
	var isError = false;
	var markForUpload = false;
	var tbname = model.entityName;
	var whereClause = [];
	var wcs = [];
	
	whereClause.key = model.entityDetails.primaryKeyName;
	whereClause.value = id;
	kony.table.insert(wcs,whereClause);
	var dbName = kony.appfoundation.getDbName();
	var dbconnection = kony.sync.getConnectionOnly(dbName, dbName, txError);
	if(dbconnection != null){
		kony.sync.startTransaction(dbconnection, transactionCallback, txSuccess, txError);
	}
	
	function txSuccess(){
		if(successCallback != null && successCallback != undefined && typeof(successCallback) == 'function'){
			var response = {};
			response.deletedRecords = 1;
			kony.appfoundation.print("inside tx success callback " + response);
			successCallback(response);
		}
	}
	
	function txError(){
		genericError();
	}
	
	function genericError(){
		var errorStr = kony.appfoundation.DataAccessAppsExceptionCode.CD_ERROR_10149
				+ ":"
				+ kony.appfoundation.DataAccessAppsExceptionCode.MSG_ERROR_10149;
		kony.appfoundation.print("inside tx error callback " + errorStr);
		if (typeof (errorCallback) == 'function') {
			errorCallback(errorStr);
		}
	}

	function transactionCallback(tx){
		record = kony.sync.getOriginalRow(tx, tbname, wcs, genericError);
		if(record===false){
			isError = true;
			return;
		}
		if(record != null){
			var deletedRows = kony.sync.remove(tx, tbname, wcs, false, true, null);
			if(deletedRows === false){
				isError = true;
				return;
			}
			
			var metaDataProvider = new kony.appfoundation.MetadataService(false, false).getMetadataProvider();
			var entity = metaDataProvider.getEntityRelations(tx, tbname);
			
			if(entity != null){
				var relations = entity["childRelationshipList"];
				if(relations!=null && relations!=undefined){
					for(var i=0; i<relations.length;i++){
						var relation = relations[i];
						var relationType = relation["relationshipType"];
						if(relationType == "ManyToMany"){
							var junctionDetails = kony.appfoundation.fetchJunctionTableDetails(relation, tbname, model.entityDetails.primaryKeyName);
							if(!kony.appfoundation.cascadeDeleteHelper(tx, model.entityDetails.primaryKeyName, junctionDetails.parentColumn, tbname, "", junctionDetails.name, true, genericError, null, record, true)){
								isError = true;	
								kony.sync.rollbackTransaction(tx);
								return;
							}
						}else{
							if(relation["referencingField"] && !kony.appfoundation.cascadeDeleteHelper(tx, model.entityDetails.primaryKeyName, relation["referencingField"], tbname, "", relation["entityName"] ,true, genericError,null, record, true)){
								
								isError = true;	
								kony.sync.rollbackTransaction(tx);
								return;
							}	
						}
					}
				}else{
					isError = true;
					return;
				}
			}else{
				isError = true;
				return;
			}
		}else{
			isError = true;
			return;
		}
	}
}

kony.appfoundation.cascadeDelete = function(tx, srcAttribute, targetAttribute, targetObjectName, wcs, errorcallback, markForUpload, isCascade, parentTable, isLocal){
	var tbname = targetObjectName;
	markForUpload = kony.sync.getUploadStatus(markForUpload);
	
	if(isCascade){
		if(removeCascadeChildren()===false){
			return false;
		}
		if(kony.appfoundation.deleteBatch(tx, tbname, wcs, isLocal,markForUpload, null)===false){
			return false;
		}
		return true;
	}else{
		var sql = "select * from " + tbname + wcs;
		var resultSet = kony.sync.executeSql(tx, sql, null);
		if(resultSet===false){
			return false;
		}	
		var num_records = resultSet.rows.length;
		if(num_records === 0){
			return true;
		}else{
			errorcallback();
			return false;
		}
	}
	
	function removeCascadeChildren(){
		var metaDataProvider = new kony.appfoundation.MetadataService(false, false).getMetadataProvider();
		var entity = metaDataProvider.getEntityRelations(tx, tbname);
		if(entity != null){
			var relations = entity["childRelationshipList"];
			if(relations!=null && relations!=undefined){
				for(var i=0; i<relations.length;i++){
					var relation = relations[i];
					var relationType = relation["relationshipType"];
					if(relationType == "ManyToMany"){
						var junctionDetails = kony.appfoundation.fetchJunctionTableDetails(relation, tbname, srcAttribute);
						if(!kony.appfoundation.cascadeDeleteHelper(tx, srcAttribute, junctionDetails.parentColumn, tbname, wcs, junctionDetails.name, true, errorcallback, markForUpload, null, isLocal)){
							return false;
						}
					}else{
						if(relation["referencingField"] && !kony.appfoundation.cascadeDeleteHelper(tx, srcAttribute, relation["referencingField"], tbname, wcs, relation["entityName"], true, errorcallback, markForUpload, null, isLocal)){
							return false;
						}
					}
				}
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
};

kony.appfoundation.fetchJunctionTableDetails = function(relation, tbname, entityKeyName){
	var childTableName = '';
	var entityName = tbname;
	
	if(relation["entityName"] == tbname)
		childTableName = relation["parentEntity"];
	else if(relation["parentEntity"] == tbname)
		childTableName = relation["entityName"];
	
	var junctionTableName = relation["junctionTableName"];
	var relationShipName =  relation["relationshipName"];
	
	// any name ending with __k
	var endsWith = "__k";
	var customRegex = new RegExp("[.]*[" + endsWith + "]$");
	var isCustomRelation = relationShipName.search(customRegex) == -1 ? false : true;
	var isCustomEntityTable = entityName.search(customRegex) == -1 ? false : true;
	var isCustomChildTable = childTableName.search(customRegex) == -1 ? false : true;
	
	var junctionTable = {};
	
	var junctionTableChildRefName = "";
	var junctionTableParentRefName = "";
	
	// Column name should not contain "__" (double under score)
	if(!isCustomRelation){
		junctionTableChildRefName = childTableName + "_" + entityKeyName;
		junctionTableParentRefName = entityName + "_" + entityKeyName;
		junctionTableParentRefName = kony.appfoundation.Utils.replaceAll(junctionTableParentRefName,"__","_");
		junctionTableChildRefName = kony.appfoundation.Utils.replaceAll(junctionTableChildRefName,"__","_");
	}else{
		var junctionTableChildRefName = "";
		var junctionTableParentRefName = "";
		
		if(isCustomChildTable){
			var index = childTableName.lastIndexOf(endsWith);
			junctionTableChildRefName = childTableName.substr(0, index);
			junctionTableChildRefName = junctionTableChildRefName + "_k" + "_" + entityKeyName;
		}else{
			junctionTableChildRefName = childTableName + "_" + entityKeyName;
		}
			
		if(isCustomEntityTable){
			var index = entityName.lastIndexOf(endsWith);
			junctionTableParentRefName = entityName.substr(0, index);
			junctionTableParentRefName = junctionTableParentRefName + "_k" + "_" + entityKeyName;
		}else{
			junctionTableParentRefName = entityName + "_" + entityKeyName;
		}
		junctionTableParentRefName = kony.appfoundation.Utils.replaceAll(junctionTableParentRefName,"__","_");
		junctionTableParentRefName += endsWith;
		junctionTableChildRefName = kony.appfoundation.Utils.replaceAll(junctionTableChildRefName,"__","_");
		junctionTableChildRefName += endsWith;
	}
	
	junctionTable.name = junctionTableName;
	junctionTable.parentColumn =  junctionTableParentRefName;
	junctionTable.childColumn = junctionTableChildRefName;
	
	return junctionTable;
}

kony.appfoundation.cascadeDeleteHelper = function (tx, srcAttribute, targetAttribute, tbname, wcs, targetObjectName, isCascade, errorcallback, markForUpload, pkRecord, isLocal) {
	var wcsCascade = null;
	if (pkRecord === null) {
		var sqlTarget = "select " + srcAttribute + " from " + tbname + wcs;
		var resultSet = kony.sync.executeSql(tx, sqlTarget, null);
		if (resultSet === false) {
			return false;
		}
		var num_records = resultSet.rows.length;
		if (num_records === 0) {
			return true;
		}

		for (var i = 0; i <= num_records - 1; i++) {
			var record = kony.db.sqlResultsetRowItem(tx, resultSet, i);
			wcsCascade = " where " + targetAttribute + " = '" + record[srcAttribute] + "'";
			if (kony.appfoundation.cascadeDelete(tx, srcAttribute, targetAttribute, targetObjectName, wcsCascade, errorcallback, markForUpload, isCascade, tbname, isLocal) === false) {
				return false;
			}
		}
	} else {
		wcsCascade = " where " + targetAttribute + " = '" + pkRecord[srcAttribute] + "'";
		return kony.appfoundation.cascadeDelete(tx, srcAttribute, targetAttribute, targetObjectName, wcsCascade, errorcallback, markForUpload, isCascade, tbname, isLocal);
	}
	return true;
};

kony.appfoundation.deleteBatch = function (tx, tablename, wc, isLocal, markForUpload, errorCallback) {
	var scopename = kony.sync.scopes.syncTableScopeDic[tablename];
	var i = null;
	var record = null;
	var query = kony.sync.qb_createQuery();
	kony.sync.qb_select(query, null);
	kony.sync.qb_from(query, tablename);
	var query_compile = kony.sync.qb_compile(query);
	var sql = query_compile[0] + " " + wc;
	var params = query_compile[1];
	var resultSet = kony.sync.executeSql(tx, sql, params, errorCallback);
	if (resultSet === false) {
		return false;
	}
	var num_records = resultSet.rows.length;
	if (isLocal === false) {
		for (i = 0; i <= num_records - 1; i++) {
			record = kony.db.sqlResultsetRowItem(tx, resultSet, i);
			record[kony.sync.originalTableChangeTypeColumn] = kony.sync.deleteColStatus;
			record[kony.sync.originalTableSyncVersionColumn] = record[kony.sync.originalTableChangeTypeColumn];
			record[kony.sync.mainTableChangeTypeColumn] = null;
			record[kony.sync.mainTableSyncVersionColumn] = null;
			kony.sync.insertEx(tx, tablename + kony.sync.originalTableName, record, null, false);
		}
	}
	query = kony.sync.qb_createQuery();
	kony.sync.qb_select(query, null);
	kony.sync.qb_from(query, tablename);
	query_compile = kony.sync.qb_compile(query);
	sql = query_compile[0] + " " + wc;
	params = query_compile[1];
	var syncorder = kony.sync.getSyncOrder(scopename, tx, errorCallback);
	if(syncorder === false){
		return false;
	}
	resultSet = kony.sync.executeSql(tx, sql, params, errorCallback);
	if(resultSet === false){
		return false;
	}
	num_records = resultSet.rows.length;
	if ((syncorder !== null)) {
		for (i = 0; i < num_records; i++) {
			record = kony.db.sqlResultsetRowItem(tx, resultSet, i);
			//adding change replay to history tables
			if (isLocal === false) {
				syncorder = syncorder + 1;
				record[kony.sync.historyTableReplaySequenceColumn] = syncorder;
				if (markForUpload === false) {
					record[kony.sync.historyTableChangeTypeColumn] = kony.sync.deleteColStatusDD;
				} else {
					record[kony.sync.historyTableChangeTypeColumn] = kony.sync.deleteColStatus;
				}
				record[kony.sync.historyTableSyncVersionColumn] = kony.sync.currentSyncScopesState[scopename];
				if(kony.sync.insertEx(tx, tablename + kony.sync.historyTableName, record, errorCallback)===false){
					return false;
				}
			}
			else {
				/*
					sync.log.debug("Removing Local Changes: ", record);
					query = kony.sync.qb_createQuery();
					kony.sync.qb_delete(query, null);
					kony.sync.qb_from(query, tablename + kony.sync.historyTableName);
					query_compile = kony.sync.qb_compile(query);
					sql = query_compile[0] + " " + wc;
					params = query_compile[1];				
					if(kony.sync.executeSql(tx, sql, params, errorCallback)===false){
						return false;
					}
				*/
				query = kony.sync.qb_createQuery();
				kony.sync.qb_delete(query, null);
				kony.sync.qb_from(query, tablename + kony.sync.originalTableName);				
				query_compile = kony.sync.qb_compile(query);
				sql = query_compile[0] + " " + wc;
				params = query_compile[1];
				if(kony.sync.executeSql(tx, sql, params, errorCallback) === false) {
					return false;
				}
			}
		}
		if(kony.sync.setSyncOrder(scopename, syncorder, tx, errorCallback)===false){
			return false;
		}
	} else {
		// not expected to come here
	}
	//deleting main tables
	resultSet = kony.sync.removeEx(tx, tablename, wc, true, errorCallback);
	if(resultSet === false){
		return false;
	}
	var deleteResult = {};
	deleteResult[kony.sync.numberOfRowsDeleted] = resultSet.rowsAffected;
	return deleteResult;
};
