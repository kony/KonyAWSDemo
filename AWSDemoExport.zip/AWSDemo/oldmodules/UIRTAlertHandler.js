kony.override = {
	ds : {
			alertStack : []
	},
	customAlertOverride : {		
	
		alertfunction : function(args){
			var formId = kony.application.getCurrentForm().id;
			var json = {};
			json[formId] = args;
			kony.override.ds.alertStack.push(json);
		},
		
		clearStack : function(){
			kony.override.ds.alertStack = [];
		},
		
		getAlertStack : function(){
			return kony.override.ds.alertStack;
		}
	}	
};