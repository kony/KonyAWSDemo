function S3Request(){
  
 var request = new kony.net.HttpRequest();
  request.onReadyStateChange=httpCallBack;

//url = "http://konypoc-contentdelivery-mobilehub-241316623.s3-website-us-east-1.amazonaws.com/example-image-1.png";	
 url = "http://s3.amazonaws.com/konypoc-contentdelivery-mobilehub-241316623/example-image-1.png"; 
  
var accessKeyId='AKIAIFWTP3CDAUVDVCHQ';
var secretKey='6IBg2cPSBBmMrrYAAWO';

 //AWSsign = new AWSSigner(accessKeyId, secretKey); 
  
	request.open(constants.HTTP_METHOD_GET,url,true);
	request.setRequestHeader("x-tf-access","yes");
	request.setRequestHeader("Content-type","image");
	request.send();
}

function httpCallBack(){
  
  
  //alert (this.readyState);
  if(this.readyState==constants.HTTP_READY_STATE_HEADERS_RECEIVED){
    this.onReadyStateChange=httpCallBack;
  }else if (this.readyState==4){
    //alert("Response Type"+this.responseType);
   // alert (getSignatureKey());
    //alert("DONE");
       home.lbltext.text="wassup";
       //request.response;
    var res = this.response;
    //res.UserData;

    kony.print("PRERESPONSE"+kony.convertToBase64(res.UserData));
    kony.print("RESPONSE"+res.UserData);
    kony.print("RES3"+ res);
    home.lbltext.text=res.UserData;
 
    alert (res);
   // var tmpimage =kony.convertToBase64(res);
    //alert(tmpimage);
    var tmpfile = "myfile.png";
   var myfile = kony.io.FileSystem.getFile('myfile.txt');
   //var myfile = new kony.io.File(tmpimage);
   // var myfile = new kony.io.File(“myfile.png”);
    myfile.write(tmpfile);
    
    tmpimage = kony.convertToRawBytes(res);
    home.imgTest.src=tmpimage;
    
  }
  
}