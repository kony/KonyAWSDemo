
function HometoDetails(title){
  
  switch(title) {
    case "User Sign-in":
    frmDetails.lblOverviewDetails.text="Whether your users sign in or not, the User sign-in feature configures Amazon Cognito to uniquely identify the user and provide your app the appropriate credentials to access your AWS resources.";
    frmDetails.lblDescriptionDetails.text="The Sample App demonstrates assignment of a unique identifier for the user, the Amazon Cognito User ID. If optional or mandatory User Sign-in has been enabled in your project, then the Sample App also includes a sign-in screen, with a button for each configured sign-in provider.";
    frmDetails.lblPoweredBy.text="Powered by Amazon Cognito";
    frmDetails.lblUserIdentity.text="Demo User Identity";
    frmDetails.title ="User Identity";
    frmDetails.flxIdentity.isVisible=true;
    frmDetails.flxPoweredby.isVisible=true;
    frmDetails.flxDataStorageDetails.isVisible=false;
    frmDetails.imgUserIdentity.src="signinsmall.png";
    frmDetails.show();
      
        break;
    case "App Content Delivery":
    frmDetails.lblOverviewDetails.text="Store app assets like resource files in the cloud. Download and cache files in your app.";
    frmDetails.lblDescriptionDetails.text="The Sample App demonstrates file download and caching by providing a remote file explorer. You can download files from Amazon S3 (and optionally Amazon CloudFront) and pin them to the cache on device by clicking on each file entry. From the menu, you can download all recent files, set the cache size limit, or clear the cache.";
    frmDetails.lblPoweredBy.text="Powered by Amazon S3 and Amazon CloudFront";
    frmDetails.lblUserIdentity.text="Demo Content Delivery";
    frmDetails.title="App Content Delivery";
    frmDetails.flxIdentity.isVisible=true;
    frmDetails.flxPoweredby.isVisible=true;
    frmDetails.flxDataStorageDetails.isVisible=false;
    frmDetails.imgUserIdentity.src="appcontentdeliverysmall.png";
    frmDetails.show();
        
        break;
    case "User Data Storage":
      frmDetails.lblOverviewDetails.text="Store user files such as photos in the cloud. Save user data in key/value pairs and sync across devices that are signed-in with the same user.";
      frmDetails.lblDescriptionDetails.text="The Sample App demonstrates User File Storage and User Profile Data. The User File Storage demonstration includes a remote file explorer, which allows you to upload and download files from your Amazon S3 bucket. You will have access to two folders, a public folder where files are accessible to all users and a private folder where files are only accessible by the current app user." +'\n\n'+"The User Profile Data demonstration stores an app color theme using Amazon Cognito Sync and synchronizes that data across all of the user's devices as key/value pairs.";
      frmDetails.lblPoweredBy.text="Powered by Amazon Cognito and Amazon S3";
      frmDetails.title="User Data Storage";
      frmDetails.flxIdentity.isVisible=false;
      frmDetails.flxPoweredby.isVisible=false;
      frmDetails.flxDataStorageDetails.isVisible=true;
      frmDetails.show();

        break;
    case "Mobile Analytics":
      frmDetails.lblOverviewDetails.text="Amazon Mobile Analytics allows you to collect, visualize, and export app event data. You can track app usage and monetization in the Amazon Mobile Analytics console, or run custom analysis by automatically exporting app events to Amazon S3 and Amazon Redshift.";
      frmDetails.lblDescriptionDetails.text="The Sample App records user session activity in metrics that may be viewed in the Amazon Mobile Analytics console. It also provides buttons to demonstrate generating a custom or monetization event, which records user activity, such as the sale of an in-app purchase item.";
      frmDetails.lblPoweredBy.text="Powered by Amazon Mobile Analytics";
      frmDetails.lblUserIdentity.text="Demo App Analytics";
      frmDetails.title="Mobile Analytics";
      frmDetails.imgUserIdentity.src="appanalyticssmall.png";
      frmDetails.flxIdentity.isVisible=true;
      frmDetails.flxPoweredby.isVisible=true;
      frmDetails.flxDataStorageDetails.isVisible=false;
      frmDetails.show();
        break;
    case "Cloud Logic":
      frmDetails.lblOverviewDetails.text="Run backend code in the cloud.";
      frmDetails.lblDescriptionDetails.text="The Sample App demonstrates the ability of a mobile app to invoke an AWS Lambda function. Enter the name of the function you wish to run and provide a list of request inputs. Invoke the function and see results.";
      frmDetails.lblPoweredBy.text="Powered by AWS Lambda";
      frmDetails.lblUserIdentity.text="Demo Cloud Logic";
      frmDetails.title="Cloud Logic";
      frmDetails.imgUserIdentity.src="cloudlogicsmall.png";
      frmDetails.flxIdentity.isVisible=true;
      frmDetails.flxPoweredby.isVisible=true;
      frmDetails.flxDataStorageDetails.isVisible=false;
      frmDetails.show();
        break;
}  
}
