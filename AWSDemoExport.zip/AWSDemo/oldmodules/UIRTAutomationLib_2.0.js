kony.automationLib = {};
kony.automationLib.v2 = {};
kony.automationLib.v2.widgetEvents = {};
kony.automationLib.v2.widgetEvents["ON_TOUCH_START"] = "onTouchStart";
kony.automationLib.v2.widgetEvents["ON_TOUCH_MOVE"] = "onTouchMove";
kony.automationLib.v2.widgetEvents["ON_TOUCH_END"] = "onTouchEnd";
kony.automationLib.v2.widgetEvents["ON_CLICK"] = "onClick";
kony.automationLib.v2.widgetEvents["ON_ROW_CLICK"] = "onRowClick";
kony.automationLib.v2.widgetEvents["ON_DONE"] = "onDone";
kony.automationLib.v2.widgetEvents["ON_TEXT_CHANGE"] = "onTextChange";
kony.automationLib.v2.syncOptns = {};
kony.automationLib.v2.syncOptns["SYNC_DATA"] = "syncData";
kony.automationLib.v2.syncOptns["SYNC_METADATA"] = "syncMetaData";
kony.automationLib.v2.formInfo = [];

kony.autoLib = {};
/**
 * This class has all the UIRT Api for automating the App in testing mode
 * 
 */
kony.automationLib.v2.UIRTAutomationLib = Class({
    /**
     * Contructor that initiates the apis by obtaining the Ip of the test server to
     * put the results back. 
     */
    constructor: function(testUrl, scope) {
        this.testServerUrl = testUrl;
        this.parentScopeObj = scope;
    },
    /**
     * Api used for login to the App , should be changed by App developer to login
     * 
     */
    login: function(inputs, success, error) {
        frmHome.show();
        success("login success");
    },
    /**
     * Sync Api 
     * @Inputs : sync Json
     * 
     */
    sync: function(inputs, success, error) {
       
    },
    /**
     * Api used for getting the form Configs.
     * 
     */
    getFormConfig: function(inputs, success, error) {
        try {
            var scopeObj = this;
            var formConfig;
            var currentFormObj = kony.application.getCurrentForm();
            var currentFormId = currentFormObj.id;
            var widgets = currentFormObj.widgets();
            getAllWidgets(widgets);
            // Getting All the Child Widgets through Iteration
            function getAllWidgets(widgets) {
                for (var i = 0; i < widgets.length; i++) {
                    //Getting all Events
                    var onTouchStart = widgets[i].onTouchStart;
                    var onTouchMove = widgets[i].onTouchMove;
                    var onTouchEnd = widgets[i].onTouchEnd;
                    var onClick = widgets[i].onClick;
                    var xObj = {};
                    xObj.events = {}
                    xObj.id = widgets[i].id;
                    xObj.type = kony.type(widgets[i]);
                    if (typeof onTouchStart == 'function') {
                        xObj.events.onTouchStart = escape(onTouchStart.toString());
                    }
                    if (typeof onTouchMove == 'function') {
                        xObj.events.onTouchMove = escape(onTouchMove.toString());
                    }
                    if (typeof onTouchEnd == 'function') {
                        xObj.events.onTouchEnd = escape(onTouchEnd.toString());
                    }
                    if (typeof onClick == 'function') {
                        xObj.events.onClick = escape(onClick.toString());
                    }
                    if (isContainerWidget(widgets[i])) {
                        kony.automationLib.v2.formInfo.push(xObj);
                        getAllWidgets(widgets[i].widgets());
                    }
                    kony.automationLib.v2.formInfo.push(xObj);
                }
            }
            // All container widgets handled except "Tab"
            function isContainerWidget(widget) {
                if (kony.type(widget) == "kony.ui.FlexContainer" || kony.type(widget) == "kony.ui.FlexScrollContainer" || kony.type(widget) == "kony.ui.TabPane" || kony.type(widget) == "kony.ui.Box" || kony.type(widget) == "kony.ui.ScrollBox") {
                    return true;
                }
                return false;
            }
            //Appending formConfig and Other Widgets to response
            var responseObj = {
                "allWidgets": kony.automationLib.v2.formInfo,
                "formid" : currentFormId
            };
            kony.automationLib.v2.formInfo = [];
            success(responseObj);
        } catch (err) {
            error(err);
        }
    },
    /**
     * Api used for triggering UI events (Except Segment Events)
     * 
     */
    triggerWidgetEvents: function(inputs, success, error) {
        try {
            var currentFormObj = kony.application.getCurrentForm();
            var currentFormId = currentFormObj.id;
            var widgetObjList = kony.autoLib.getWidgetListFromFormObj(currentFormObj);
            var widgetInstance = kony.autoLib.getWidgetObject(widgetObjList, inputs.widgetId);            
            var onTouchStart = widgetInstance.onTouchStart;
            var onTouchMove = widgetInstance.onTouchMove;
            var onTouchEnd = widgetInstance.onTouchEnd;
            var onClick = widgetInstance.onClick;            
            if (typeof onTouchStart == 'function') {
                onTouchStart();
            }
            if (typeof onTouchMove == 'function') {
                onTouchMove();
            }
            if (typeof onTouchEnd == 'function') {
                onTouchEnd();
            }
            if (typeof onClick == 'function') {
                onClick();
            }
            success({
                "msg": "The Widget event is triggered successfully"
            });
        } catch (err) {
            error(err);
        }
    },
    /**
     * Api for triggering segment events
     * 
     */
    triggerSegmentEvents: function(inputs, success, error) {
        try {
           	var currentFormObj = kony.application.getCurrentForm();
            var currentFormId = currentFormObj.id;
            var widgetInstance = eval.call(null,currentFormId+"."+inputs.segmentId);           
            var onTouchStart = widgetInstance.onTouchStart;
            var onTouchMove = widgetInstance.onTouchMove;
            var onTouchEnd = widgetInstance.onTouchEnd;
			var onRowClick = widgetInstance.onRowClick;
			var dataOnSegment = eval.call(null,currentFormId+"."+inputs.segmentId+"."+"data;");
			var sectionNumber;
			if(inputs.sectionNumber)
				sectionNumber = inputs.sectionNumber-1;
			else
				sectionNumber = 0;
			if(typeof onTouchStart == 'function'){
				onTouchStart();
			}
			if(typeof onTouchMove == 'function'){
				onTouchMove();
			}
			if(typeof onTouchEnd == 'function'){
				onTouchEnd();
			}
			if(typeof onRowClick == 'function' ){
				eval.call(null,currentFormId+ "."+ inputs.segmentId + ".selectedRowIndex = ["+sectionNumber + ","+ (inputs.rowNumber-1) + "]");
			   	eval.call(null,currentFormId+ "."+ inputs.segmentId + ".selectedIndex = ["+sectionNumber + ","+ (inputs.rowNumber-1) + "]");
				onRowClick();
			}
			
			success("The Segment Row Click Executed Successfully");
        } catch (err) {
            error(err);
        }
    },
    /**
     * Api for writing Data to From
     */
    writeDataToWidgets: function(inputs, success, error) {
        try {
            var currentFormObj = kony.application.getCurrentForm();
            var currentFormId = currentFormObj.id;
            this.resultObj = [];
            this.widgetKeyValue = {};
            this.currentFormId = currentFormId;
            this.inputs = inputs;
            var scope = this;
            scope.index=0;
            function writeDta(){
            	if(scope.index > (scope.inputs.writeData).length-1){
            		return;
            	}
            	if(scope.inputs.writeData[scope.index].value == null && scope.inputs.writeData[scope.index].value == undefined){
            		scope.index = scope.index+1;
            		writeDta();
            		return;
            	}
            	var widObj = eval.call(null,scope.currentFormId+"."+scope.inputs.writeData[scope.index].widgetId); 
            	kony.autoLib.viewModel.writeData(scope.currentFormId,scope.inputs.writeData[scope.index].widgetId,kony.type(widObj),scope.inputs.writeData[scope.index].value);
            	scope.widgetKeyValue.value = scope.inputs.writeData[scope.index].value;
            	scope.widgetKeyValue.widgetId = inputs.writeData[scope.index].widgetId;
            	scope.resultObj[scope.index] = scope.widgetKeyValue;
                scope.widgetKeyValue = {};
                scope.index = scope.index+1;
                kony.timer.schedule("timer"+scope.index,writeDta,2,false);
            }
            writeDta(scope.index);
            var readData = {
                "data": scope.resultObj
            }
            function scb(){
            	 if(success == undefined || success == null){
            		return readData;
	             }else{
	            	success(readData);
	             }	
	        }
	        kony.timer.schedule("timerId"+(scope.inputs.writeData).length+10,scb,2*((inputs.writeData).length + 4),false);          
        } catch (err) {
       		if(error == undefined || error == null){
            	return null;
            }else{
            	error(err);
            }	
        }
    },
    /**
     * Reading data form Form
     */
    readDataFromWidgets: function(inputs, success, error) {
        try {
            var currentFormObj = kony.application.getCurrentForm();
            var currentFormId = currentFormObj.id;
            var resultObj = [];
            var widgetKeyValue = {};
            for (var i = 0; i < (inputs.readData).length; i++) {
                widgetKeyValue.widgetId = inputs.readData[i].widgetId;
                var widgetObj = eval.call(null,currentFormId+"."+inputs.readData[i].widgetId);
                widgetKeyValue.value = kony.autoLib.viewModel.readData(currentFormId,inputs.readData[i].widgetId,kony.type(widgetObj));

                widgetKeyValue.isStatic = false;
                resultObj[i] = widgetKeyValue;
                widgetKeyValue = {};
            }
            var readData = {
                "data": resultObj,
                "alertstack" : kony.override.customAlertOverride.getAlertStack()
            }
            kony.override.customAlertOverride.clearStack();
            if(success == undefined || success == null){
            	return readData;
            }else{
            	success(readData);
            }	
        } catch (err) {
            if(error == undefined || error == null){
            	return null;
            }else{
            	error(err);
            }
        }
    },
    getJasmineTestReport: function(inputs, success, error) {
        try {
            success(kony.reporter);
        } catch (err) {
            error(err);
        }
    },
    getAppWidgetStructure : function(inputs,success,error){
    	try{
    		var formObj = eval.call(null,inputs.formId);
    		formObj.show();
    		var widgetObjList = kony.autoLib.getWidgetListFromFormObj(formObj);
    		var widgetIdList = [];
    		// Getting Required Info from the List
			for(var i=0;i < widgetObjList.length; i++){
				widgetIdList.push({"id":widgetObjList[i].id,"type":kony.type(widgetObjList[i]),"value":"Give Your value"});				
			}
    		success(widgetIdList);
    	}catch(err){
    		error(err);
    	}    
    },
    takeScreenShot : function(inputs,success,error){
    	try{
    		//Creates an object of class 'ScreenShot'
			var ScreenShotObject = new ScreenShot();
			//Invokes method 'takeScreenShot' on the object
			ScreenShotObject.takeScreenShot();    
			success("screeen shot successfull");		
    	}catch(err){
    		error(err)
    	}
    }
});
kony.autoLib = {

		getWidgetObject : function(widgetList,widgetId){
			for(var i=0;i < widgetList.length;i++){
				if(widgetList[i].id == widgetId){
					return widgetList[i];
				}
			}
			return null;
		},
		
		getWidgetListFromFormObj : function(formObj){
			var widgetList = [];
			var widgetsObj = getWidgetObjs(formObj,0);
					
			function getWidgetObjs(formObj,k){
				var widgetsObj = formObj.widgets();
				if(widgetsObj.length != 0){
					return widgetsObj;
				}else if((widgetsObj.length == 0 || widgetsObj.length == undefined)&& k<=5){
					return getWidgetObjs(formObj,++k);
				}else{
					return widgetsObj;
				}
			}
			
			// All container widgets handled except "Tab"
            function isContainerWidget(widget) {
                if (kony.type(widget) == "kony.ui.FlexContainer" || kony.type(widget) == "kony.ui.FlexScrollContainer" || kony.type(widget) == "kony.ui.TabPane" || kony.type(widget) == "kony.ui.Box" || kony.type(widget) == "kony.ui.ScrollBox") {
                    return true;
                }
                return false;
            }
			function getAllWidgets(widgets){
				  for (var i = 0; i < widgets.length; i++) {
				  	widgetList.push(widgets[i]);			  	
					if (isContainerWidget(widgets[i])) {
	                     getAllWidgets(widgets[i].widgets());
	                }			
				 }
		    }		    
		    getAllWidgets(widgetsObj);
		    return widgetList;	 			
		},
		viewModel : {
			writeData : function(formid,widgetId,widgetType,value){
				if(widgetType == "kony.ui.TextBox" || widgetType == "kony.ui.TextArea"){
					eval.call(null,formid+"."+widgetId+"."+"text = "+"\""+value+"\"");
				}else if(widgetType == "kony.ui.ListBox"){
					eval.call(null,formid+"."+widgetId+"."+"selectedKey = "+"\""+value+"\"");
				}else if(widgetType == "kony.ui.Calender"){
					//alert("Please implement the code to set values to calender !!!");
				}else{
					//alert("Please implement this widget type in kony.autoLib.viewModel.writeData()");	
				}		
			},
			readData : function(formid,widgetId,widgetType){
				if(widgetType == "kony.ui.TextBox" || widgetType == "kony.ui.TextArea" || widgetType == "kony.ui.Label")
					return eval.call(null,formid+"."+widgetId+"."+"text");
				else if(widgetType == "kony.ui.ListBox")
					return eval.call(null,formid+"."+widgetId+"."+"selectedKey");
				else if(widgetType == "kony.ui.Calender")
					//alert("Please implement the code to get values from calender !!!");
					return null;
				else if(widgetType == "kony.ui.SegmentedUI2" || widgetType == "kony.ui.SegmentUI2")
					return eval.call(null,formid+"."+widgetId+".data");
				else
					return null;
					//alert("Please implement this widget type in kony.autoLib.viewModel.readData()");			
			}
		} 		
}		