function headerBackBtnClick() {
    switch (FlexContainer040318fa6a58b47.hdrLabel.text) {
        case "NoSQL Demo: SelectTable":
            frmDynamoDB.show();
            break;
        case "NoSQL Demo:Records":
            frmDynamoDBDetails.show();
            break;
        default:
            frmHome.show();
    }
}

function createNewUser() {
    frmSignIn.flxLogin.txtCognitoPasswordCon.isVisible = true;
    frmSignIn.flxLogin.btnCoginitoLogin.text = 'Sign Up';
}

function frmSingInPreShow() {
    frmSignIn.flxLogin.txtCognitoUser.text = "";
    frmSignIn.flxLogin.txtCognitoPassword.text = "";
    FlexContainer040318fa6a58b47.hdrLabel.text = 'Login';
    frmSignIn.flxLogin.txtCognitoPasswordCon.isVisible = false;
    //frmSignIn.btnCoginitoLogin.text = 'Sign In';
    FlexContainer040318fa6a58b47.backBtn.isVisible = true;
}

function frmDynamoDB_PreShow() {
    FlexContainer040318fa6a58b47.hdrLabel.text = 'NoSQL DB';
    FlexContainer040318fa6a58b47.backBtn.isVisible = true;
    getDynamodb();
}

function frmUserIdentity_PreShow() {
    FlexContainer040318fa6a58b47.hdrLabel.text = 'User Identity';
    FlexContainer040318fa6a58b47.backBtn.isVisible = true;
}

function frmDynamoDBDetails_PreShow() {
    FlexContainer040318fa6a58b47.hdrLabel.text = 'NoSQL Demo: SelectTable';
    FlexContainer040318fa6a58b47.backBtn.isVisible = true;
    getDynamodb();
}

function frmUserFileStorage_PreShow() {
    FlexContainer040318fa6a58b47.hdrLabel.text = 'Photos';
    FlexContainer040318fa6a58b47.backBtn.isVisible = true;
    //FlexContainer040318fa6a58b47.backBtn.text = 'Back';
    getPhotos();
}
/**
 * @function
 *
 */
function frmHome_PreShow() {
    frmHome.segHome.onRowClick = segHomeRowClick;
}
/**
 * @function
 *
 */
function segHomeRowClick() {
    if (frmHome.segHome.selectedItems[0].lblTitle == "NoSQL Database") {
        frmDynamoDB.show();
    } else if (frmHome.segHome.selectedItems[0].lblTitle == "User Data Storage") {
        frmUserFileStorage.show();
    } else if (frmHome.segHome.selectedItems[0].lblTitle == "Cloud Logic") {
        frmClogic.show();
    } else if (frmHome.segHome.selectedItems[0].lblTitle == "User Sign-in") {
        if (loggedin == 1) {
            frmUserIdentity.show();
        } else {
            frmSignIn.show();
        }
    }
}