var queries = [
    [{
        TableName: News,
        KeyConditionExpression: "userId = :id and articleId = :article",
        ExpressionAttributeValues: {
            ":id": {
                "S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
            },
            ":article": {
                "S": "demo-articleId-500000"
            }
        }
    }],
    [{
        TableName: News,
        KeyConditionExpression: "userId = :id",
        ExpressionAttributeValues: {
            ":id": {
                "S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
            }
        }
    }, {
        TableName: News,
        KeyConditionExpression: "userId = :id",
        FilterExpression: "author > :name",
        ExpressionAttributeValues: {
            ":id": {
                "S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
            },
            ":name": {
                "S": "demo-author-500000"
            }
        }
    }, {
        TableName: News,
        KeyConditionExpression: "userId = :id and articleId < :article",
        ExpressionAttributeValues: {
            ":id": {
                "S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
            },
            ":article": {
                "S": "demo-articleId-500000"
            }
        }
    }, {
        TableName: News,
        KeyConditionExpression: "userId = :id and articleId < :article",
        FilterExpression: "author > :name",
        ExpressionAttributeValues: {
            ":id": {
                "S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
            },
            ":article": {
                "S": "demo-articleId-500000"
            },
            ":name": {
                "S": "demo-author-500000"
            }
        }
    }],
    [{
        TableName: News,
        IndexName: "Categories",
        KeyConditionExpression: "category = :cat",
        ExpressionAttributeValues: {
            ":cat": {
                "S": "demo-category-3"
            }
        }
    }, {
        TableName: News,
        IndexName: "Categories",
        KeyConditionExpression: "category = :cat",
        FilterExpression: "articleId > :article",
        ExpressionAttributeValues: {
            ":cat": {
                "S": "demo-category-3"
            },
            ":article": {
                "S": "demo-articleId-500000"
            }
        }
    }, {
        TableName: News,
        IndexName: "Categories",
        KeyConditionExpression: "category = :cat and creationDate > :date",
        ExpressionAttributeValues: {
            ":cat": {
                "S": "demo-category-3"
            },
            ":date": {
                "N": "1111500000"
            }
        }
    }, {
        TableName: News,
        IndexName: "Categories",
        KeyConditionExpression: "category = :cat and creationDate < :date",
        FilterExpression: "articleId > :article",
        ExpressionAttributeValues: {
            ":cat": {
                "S": "demo-category-3"
            },
            ":date": {
                "N": "1111500000"
            },
            ":article": {
                "S": "demo-articleId-500000"
            }
        }
    }],
    [{
        TableName: News
    }, {
        TableName: News,
        FilterExpression: "author > :name",
        ExpressionAttributeValues: {
            ":name": {
                "S": "demo-author-500000"
            }
        }
    }]
]; //Type your code here