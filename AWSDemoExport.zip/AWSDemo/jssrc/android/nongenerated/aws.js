var bucket;
var dynamodb;

function ppInit(AWS, config) {
    AWS.config.update({
        accessKeyId: config.accessKeyId,
        secretAccessKey: config.secretAccessKey,
        httpOptions: {
            timeout: 1800000,
            xhrAsync: true
        }
    });
    AWS.config.region = config.region;
    bucket = new AWS.S3({
        params: {
            Bucket: config.Bucket
        }
    });
    dynamodb = new AWS.DynamoDB({
        apiVersion: '2012-08-10'
    });
    lambda = new AWS.Lambda();
    cognitoidentity = new AWS.CognitoIdentity({
        apiVersion: '2014-06-30'
    });
    var poolData = {
        UserPoolId: config.UserPoolId,
        ClientId: config.ClientId
    };
    cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider(poolData);
}

function getBucketDetails(params, callback) {
    alert("Getting details");
    params.Bucket = config.Bucket;
    bucket.listObjects(params, function(err, data) {
        kony.print(JSON.stringify(data));
        if (err) {
            kony.print('Could not load objects from S3' + err);
            alert(err);
        } else {
            //alert(data);
            callback(data);
        }
    });
}

function getSignedUrl(params) {
    params.Bucket = config.Bucket;
    return bucket.getSignedUrl('getObject', params);
}

function getTableDetails(tablename, callback) {
    var params = {
        'TableName': tablename
    };
    dynamodb.describeTable(params, function(err, data) {
        if (err) alert(JSON.stringify(err)); // an error occurred
        else callback(data); // successful response
    });
}

function getUserDetails(params, callback) {
    dynamodb.scan(params, function(err, data) {
        if (err) alert(JSON.stringify(err)); // an error occurred
        else callback(data); // successful response
    });
}

function ClogicLambda(params, callback) {
    lambda.invoke(params, function(err, data) {
        if (err) kony.print(err); // an error occurred
        else {
            if (data && data.Payload) {
                callback(data);
            }
        }
    });
}

function queryDynamoDB(params, callback) {
    dynamodb.query(params, function(err, data) {
        if (err) {
            kony.print("Unable to query. Error:" + JSON.stringify(err));
        } else {
            kony.print("Query succeeded.");
            callback(data);
        }
    });
}

function addUserDetails(tablename, record, callback) {
    var params = {
        'TableName': tablename,
        Item: record
    };
    dynamodb.putItem(params, function(err, data) {
        if (err) {
            kony.print('JSON err' + err);
        } else {
            callback(data);
        }
    });
}

function addUserDetailsLambda(userDetails, callback) {
    var params = {
        FunctionName: createUserFunction,
        InvocationType: 'RequestResponse',
        LogType: 'None',
        Payload: JSON.stringify(userDetails)
    };
    lambda.invoke(params, function(err, data) {
        if (err) kony.print("harsha23" + err); // an error occurred
        else {
            if (data && data.Payload) {
                createUser(userDetails.username, userDetails.passkey.toString(), callback);
                // callback && callback(JSON.parse(data.Payload]));    
            }
        }
    });
}

function validateUser(userDetails, callback) {
    var params = {
        FunctionName: validateUserFunction,
        InvocationType: 'RequestResponse',
        LogType: 'None',
        Payload: JSON.stringify(userDetails)
    };
    lambda.invoke(params, function(err, data) {
        if (err) kony.print("Error in validation " + err); // an error occurred
        else {
            var playLoad = JSON.parse(data.Payload);
            callback && callback(playLoad);
        }
    });
}

function getUserCredentials(userId, callback) {
    var params = {
        IdentityPoolId: config.IdentityPoolId,
        Logins: {
            'login.kony.awstest': kony.crypto.createHash('md5', userId).toString()
        }
    };
    cognitoidentity.getOpenIdTokenForDeveloperIdentity(params, function(err, data) {
        if (err) {
            kony.print("Error: " + err);
            return;
        } else {
            kony.print(JSON.stringify(data));
            callback && callback(data);
        }
    });
}

function createUser(username, passkey, callback) {
    //alert();
    alert(username);
    alert(passkey);
    var params = {
        ClientId: config.ClientId,
        Password: passkey,
        Username: username,
        UserAttributes: [{
            Name: 'name',
            Value: username
        }, ]
    };
    cognitoidentityserviceprovider.signUp(params, function(err, data) {
        if (err) alert(err); // an error occurred
        else {
            confirmUser(username, callback);
        }
    });
}

function confirmUser(username, callback) {
    var params = {
        UserPoolId: config.UserPoolId,
        Username: username
    };
    cognitoidentityserviceprovider.adminConfirmSignUp(params, function(err, data) {
        if (err) kony.print(err); // an error occurred
        else {
            kony.print(data);
            callback && callback(data);
        } // successful response
    });
}