var responseData = {};

function getPhotos() {
    var prefix = "public/";
    var params = {
        Prefix: prefix
    };
    getBucketDetails(params, function(data) {
        var currentForm = kony.application.getCurrentForm();
        var photosData = [];
        kony.print('Loaded ' + data.Contents.length + ' items from S3');
        for (var i = 1; i < data.Contents.length; i++) {
            photosData.push({
                lblImageName: data.Contents[i].Key.replace(prefix, ""),
                lblImageSize: data.Contents[i].Size,
                url: getSignedUrl({
                    Key: data.Contents[i].Key
                })
            });
        }
        responseData = photosData;
        currentForm.lblpath.text = "Path:/" + prefix;
        currentForm.flxS3list.segContentS3.setData(photosData);
    });
}

function segPhotoOnClick() {
    var currentForm = kony.application.getCurrentForm();
    var selectedRow = currentForm.flxS3list.segContentS3.selectedRowIndex[1];
    frmImageOpen.imgLocal.src = responseData[selectedRow].url;
    frmImageOpen.title = responseData[selectedRow].lblImageName;
    frmImageOpen.show();
}