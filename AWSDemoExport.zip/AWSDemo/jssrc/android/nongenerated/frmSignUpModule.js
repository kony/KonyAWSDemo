currentUserInfo = {};
var loggedin = 0;
/**
 * @function
 *
 */
function validateUserDetails() {
    var currentForm = kony.application.getCurrentForm();
    kony.application.showLoadingScreen("", "Please wait..", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, null);
    var username = currentForm.flxLogin.txtCognitoUser.text;
    var passkey = currentForm.flxLogin.txtCognitoPassword.text;
    var confPasskey = currentForm.flxLogin.txtCognitoPasswordCon.text;
    if (username && /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(username) && passkey && (/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z$!@#%^&*]{8,}$/).test(passkey)) {
        var userDetails = {
            username: username,
            passkey: passkey
        };
        if (currentForm.flxLogin.txtCognitoPasswordCon.isVisible) {
            if (confPasskey == passkey) {
                signUpUserDetails(username, passkey);
            } else {
                alertMessage('Passwords not same.');
            }
            return;
        }
        var generatedkey = kony.crypto.createHash('md5', username);
        var userId = generatedkey.toString();
        currentUserInfo["userId"] = userId;
        currentUserInfo["username"] = username;
        validateUser(userDetails, function(data) {
            if (data.login) {
                getUserCredentials(userId, function(data) {
                    currentUserInfo["IdentityId"] = data["IdentityId"];
                    currentUserInfo["Token"] = data["Token"];
                    frmUserIdentity.lblIdentity.text = currentUserInfo.IdentityId;
                    frmUserIdentity.lblOverView.text = currentUserInfo.username;
                    loggedin = 1;
                    kony.application.dismissLoadingScreen();
                    targetFormFromFunction(navcfg.Identity.form);
                    frmUserIdentity.show();
                });
            } else {
                alert('Invalid username or password.');
            }
        });
    } else {
        alert('Invalid UserName or password');
    }
}

function signUpUserDetails(username, passkey) {
    if (username && /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(username)) {
        if ((/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z$!@#%^&*]{8,}$/).test(passkey)) {
            var userDetails = {
                username: username,
                passkey: passkey
            };
            addUserDetailsLambda(userDetails, function(err) {
                if (!err) {
                    kony.print('Unable to add user details ' + err);
                }
                kony.application.dismissLoadingScreen();
                frmSignIn.show();
                alert("Successfully SignedUp. Please login to continue.").
                frmSingInPreShow();
            });
        } else {
            alert('Invalid Passward. Atleast 8 characters and Require numbers, special character, uppercase and lowercase letters');
        }
    } else {
        alert('Invalid username');
    }
}