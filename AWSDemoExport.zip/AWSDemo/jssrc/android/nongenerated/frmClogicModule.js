function frmClogicPreshow() {
    FlexContainer040318fa6a58b47.hdrLabel.text = "Cloud Logic";
    //frmClogic.bntLambdaInvoke.onClick = invokeLambda;
}

function invokeLambda() {
    var currentForm = kony.application.getCurrentForm();
    var params = {
        FunctionName: currentForm.txtFunction.text,
        InvocationType: 'RequestResponse',
        LogType: 'None',
        Payload: currentForm.txtArea.text
    };
    ClogicLambda(params, function(data) {
        currentForm.lblResult.text = data.Payload;
    });
}