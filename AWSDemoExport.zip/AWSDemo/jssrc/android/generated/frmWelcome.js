function addWidgetsfrmWelcome() {
    frmWelcome.setDefaultUnit(kony.flex.DP);
    var btnLogin = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "50px",
        "id": "btnLogin",
        "isVisible": true,
        "left": "80%",
        "skin": "CopyslButtonGlossBlue03d1f87a6f7fa40",
        "text": "Log in",
        "top": "2%",
        "width": "130px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblWelcome = new kony.ui.Label({
        "height": "preferred",
        "id": "lblWelcome",
        "isVisible": true,
        "left": "10%",
        "skin": "CopyslLabel0c8977aabbd4f48",
        "text": "Welcome to AWS",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "30%",
        "width": "70%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var btnFacebook = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "8%",
        "id": "btnFacebook",
        "isVisible": true,
        "left": "10%",
        "skin": "CopyslButtonGlossBlue0c1de2223a75a43",
        "text": "f Continue with Facebook",
        "top": "50%",
        "width": "80%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnCreateAccount = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "8%",
        "id": "btnCreateAccount",
        "isVisible": true,
        "left": "10%",
        "skin": "CopyslButtonGlossBlue0d6ba0222ad7049",
        "text": "Create Account",
        "top": "60%",
        "width": "80%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmWelcome.add(btnLogin, lblWelcome, btnFacebook, btnCreateAccount);
};

function frmWelcomeGlobals() {
    frmWelcome = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmWelcome,
        "enabledForIdleTimeout": false,
        "id": "frmWelcome",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm04b50ff231ec34e"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
    frmWelcome.info = {
        "kuid": "bb9c104ea6e04d65b1b7d1ae05ead627"
    };
};