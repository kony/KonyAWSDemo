function addWidgetsfrmDynamoDB() {
    frmDynamoDB.setDefaultUnit(kony.flex.DP);
    var segRecords = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "lblIndex": "",
            "lblIndexKey": "",
            "lblPartition": "",
            "lblPartitionKey": "",
            "lblSort": "",
            "lblSortKey": "",
            "lblTableName": ""
        }],
        "groupCells": false,
        "height": "98%",
        "id": "segRecords",
        "isVisible": true,
        "left": "1%",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_ec3b0e2f7e9f4fe7b44e8362052c085f,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": flxTemplate,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "1%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "flxTemplate": "flxTemplate",
            "lblIndex": "lblIndex",
            "lblIndexKey": "lblIndexKey",
            "lblPartition": "lblPartition",
            "lblPartitionKey": "lblPartitionKey",
            "lblSort": "lblSort",
            "lblSortKey": "lblSortKey",
            "lblTableName": "lblTableName"
        },
        "width": "98%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmDynamoDB.add(segRecords);
};

function frmDynamoDBGlobals() {
    frmDynamoDB = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmDynamoDB,
        "enabledForIdleTimeout": false,
        "headers": [FlexContainer040318fa6a58b47],
        "id": "frmDynamoDB",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "preShow": AS_Form_1abc67bad55f4009904e40b46103d7fc
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
    frmDynamoDB.info = {
        "kuid": "40da2b58b21744eebc93571bc6b33adf"
    };
};