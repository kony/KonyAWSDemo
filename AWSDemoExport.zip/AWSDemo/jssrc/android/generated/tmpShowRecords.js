function initializetmpShowRecords() {
    flxRecordShow = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "70%",
        "id": "flxRecordShow",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "skin": "slFbox",
        "width": "100%"
    }, {}, {});
    flxRecordShow.setDefaultUnit(kony.flex.DP);
    var lblCount = new kony.ui.Label({
        "centerX": "50%",
        "height": "preferred",
        "id": "lblCount",
        "isVisible": true,
        "left": "156dp",
        "skin": "CopyslLabel053a2db4987484e",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0.50%",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblUserId = new kony.ui.Label({
        "height": "5%",
        "id": "lblUserId",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel07904d89b364545",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblUserIdValue = new kony.ui.Label({
        "height": "preferred",
        "id": "lblUserIdValue",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel02f4cb2887d2648",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblArticleId = new kony.ui.Label({
        "height": "5%",
        "id": "lblArticleId",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel07904d89b364545",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblArticleIdValue = new kony.ui.Label({
        "height": "preferred",
        "id": "lblArticleIdValue",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel02f4cb2887d2648",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblAuthor = new kony.ui.Label({
        "height": "5%",
        "id": "lblAuthor",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel07904d89b364545",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblAuthorValue = new kony.ui.Label({
        "height": "preferred",
        "id": "lblAuthorValue",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel02f4cb2887d2648",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblCategory = new kony.ui.Label({
        "height": "5%",
        "id": "lblCategory",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel07904d89b364545",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblCategoryValue = new kony.ui.Label({
        "height": "preferred",
        "id": "lblCategoryValue",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel02f4cb2887d2648",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblContent = new kony.ui.Label({
        "height": "5%",
        "id": "lblContent",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel07904d89b364545",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblContentValue = new kony.ui.Label({
        "height": "preferred",
        "id": "lblContentValue",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel02f4cb2887d2648",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblCreationDate = new kony.ui.Label({
        "height": "5%",
        "id": "lblCreationDate",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel07904d89b364545",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblCreationDateValue = new kony.ui.Label({
        "height": "preferred",
        "id": "lblCreationDateValue",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel02f4cb2887d2648",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblKeyword = new kony.ui.Label({
        "height": "5%",
        "id": "lblKeyword",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel07904d89b364545",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblKeywordValue = new kony.ui.Label({
        "height": "preferred",
        "id": "lblKeywordValue",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel02f4cb2887d2648",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblTitle = new kony.ui.Label({
        "height": "5%",
        "id": "lblTitle",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel07904d89b364545",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblTitleValue = new kony.ui.Label({
        "height": "preferred",
        "id": "lblTitleValue",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel02f4cb2887d2648",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxRecordShow.add(lblCount, lblUserId, lblUserIdValue, lblArticleId, lblArticleIdValue, lblAuthor, lblAuthorValue, lblCategory, lblCategoryValue, lblContent, lblContentValue, lblCreationDate, lblCreationDateValue, lblKeyword, lblKeywordValue, lblTitle, lblTitleValue);
}