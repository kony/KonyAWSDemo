function addWidgetsfrmDynamoDBRecords() {
    frmDynamoDBRecords.setDefaultUnit(kony.flex.DP);
    var segRecordShow = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "lblArticleId": "Label",
            "lblArticleIdValue": "Label",
            "lblAuthor": "Label",
            "lblAuthorValue": "Label",
            "lblCategory": "Label",
            "lblCategoryValue": "Label",
            "lblContent": "Label",
            "lblContentValue": "Label",
            "lblCount": "Label",
            "lblCreationDate": "Label",
            "lblCreationDateValue": "Label",
            "lblKeyword": "Label",
            "lblKeywordValue": "Label",
            "lblTitle": "Label",
            "lblTitleValue": "Label",
            "lblUserId": "Label",
            "lblUserIdValue": "Label"
        }, {
            "lblArticleId": "Label",
            "lblArticleIdValue": "Label",
            "lblAuthor": "Label",
            "lblAuthorValue": "Label",
            "lblCategory": "Label",
            "lblCategoryValue": "Label",
            "lblContent": "Label",
            "lblContentValue": "Label",
            "lblCount": "Label",
            "lblCreationDate": "Label",
            "lblCreationDateValue": "Label",
            "lblKeyword": "Label",
            "lblKeywordValue": "Label",
            "lblTitle": "Label",
            "lblTitleValue": "Label",
            "lblUserId": "Label",
            "lblUserIdValue": "Label"
        }, {
            "lblArticleId": "Label",
            "lblArticleIdValue": "Label",
            "lblAuthor": "Label",
            "lblAuthorValue": "Label",
            "lblCategory": "Label",
            "lblCategoryValue": "Label",
            "lblContent": "Label",
            "lblContentValue": "Label",
            "lblCount": "Label",
            "lblCreationDate": "Label",
            "lblCreationDateValue": "Label",
            "lblKeyword": "Label",
            "lblKeywordValue": "Label",
            "lblTitle": "Label",
            "lblTitleValue": "Label",
            "lblUserId": "Label",
            "lblUserIdValue": "Label"
        }],
        "groupCells": false,
        "height": "100%",
        "id": "segRecordShow",
        "isVisible": true,
        "left": "0%",
        "needPageIndicator": true,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": flxRecordShow,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "0%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "flxRecordShow": "flxRecordShow",
            "lblArticleId": "lblArticleId",
            "lblArticleIdValue": "lblArticleIdValue",
            "lblAuthor": "lblAuthor",
            "lblAuthorValue": "lblAuthorValue",
            "lblCategory": "lblCategory",
            "lblCategoryValue": "lblCategoryValue",
            "lblContent": "lblContent",
            "lblContentValue": "lblContentValue",
            "lblCount": "lblCount",
            "lblCreationDate": "lblCreationDate",
            "lblCreationDateValue": "lblCreationDateValue",
            "lblKeyword": "lblKeyword",
            "lblKeywordValue": "lblKeywordValue",
            "lblTitle": "lblTitle",
            "lblTitleValue": "lblTitleValue",
            "lblUserId": "lblUserId",
            "lblUserIdValue": "lblUserIdValue"
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmDynamoDBRecords.add(segRecordShow);
};

function frmDynamoDBRecordsGlobals() {
    frmDynamoDBRecords = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmDynamoDBRecords,
        "enabledForIdleTimeout": false,
        "headers": [FlexContainer040318fa6a58b47],
        "id": "frmDynamoDBRecords",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm04cdd7f85b5bc48"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
    frmDynamoDBRecords.info = {
        "kuid": "009d062b4cc64bd6943e4866d67d6517"
    };
};