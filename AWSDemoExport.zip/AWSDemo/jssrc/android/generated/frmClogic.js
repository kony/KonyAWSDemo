function addWidgetsfrmClogic() {
    frmClogic.setDefaultUnit(kony.flex.DP);
    var Label0433e4587276741 = new kony.ui.Label({
        "id": "Label0433e4587276741",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0fa090f0e638e48",
        "text": "Function",
        "top": "10dp",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var txtFunction = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "focusSkin": "CopyslTextBox08eebf5c7f75e4b",
        "height": "40dp",
        "id": "txtFunction",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "20dp",
        "secureTextEntry": false,
        "skin": "CopyslTextBox08eebf5c7f75e4b",
        "text": "hello-world",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "40dp",
        "width": "88%",
        "zIndex": 1
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [2, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var CopyLabel0cd0fe2f662c74c = new kony.ui.Label({
        "id": "CopyLabel0cd0fe2f662c74c",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0fa090f0e638e48",
        "text": "Request",
        "top": "90dp",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var txtArea = new kony.ui.TextArea2({
        "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
        "focusSkin": "CopyslTextArea0bbb0e7601d8842",
        "height": "160dp",
        "id": "txtArea",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
        "left": "20dp",
        "numberOfVisibleLines": 3,
        "skin": "CopyslTextArea0bbb0e7601d8842",
        "text": "{\n\"key1\":\"value1\",\n\"key2\":\"value2\",\n\"key3\":\"value3\"\n}",
        "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
        "top": "130dp",
        "width": "88%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [2, 2, 2, 2],
        "paddingInPixel": false
    }, {});
    var Button0aa44fcf93d4344 = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue07eca72faa4504a",
        "height": "40dp",
        "id": "Button0aa44fcf93d4344",
        "isVisible": true,
        "left": "20dp",
        "onClick": AS_Button_fa1b3fbcd60e46278318abd271d820c0,
        "skin": "CopyslButtonGlossBlue07eca72faa4504a",
        "text": "Reset",
        "top": "300dp",
        "width": "40%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var bntLambdaInvoke = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue07eca72faa4504a",
        "height": "40dp",
        "id": "bntLambdaInvoke",
        "isVisible": true,
        "onClick": AS_Button_f3a64a070a26468a824c9c5ef1d986ac,
        "right": "20dp",
        "skin": "CopyslButtonGlossBlue07eca72faa4504a",
        "text": "Invoke",
        "top": "300dp",
        "width": "45%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel044b38899b0f44e = new kony.ui.Label({
        "id": "CopyLabel044b38899b0f44e",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0fa090f0e638e48",
        "text": "Result",
        "top": "360dp",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyTextArea012fe71368c304b = new kony.ui.TextArea2({
        "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
        "focusSkin": "CopyslTextArea0bbb0e7601d8842",
        "height": "150dp",
        "id": "CopyTextArea012fe71368c304b",
        "isVisible": false,
        "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
        "left": "20dp",
        "numberOfVisibleLines": 3,
        "skin": "CopyslTextArea0bbb0e7601d8842",
        "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
        "top": "390dp",
        "width": "88%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [2, 2, 2, 2],
        "paddingInPixel": false
    }, {});
    var FlexContainer0a352ed71d08a4c = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "150dp",
        "id": "FlexContainer0a352ed71d08a4c",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "20dp",
        "skin": "CopyslFbox0dde8fc2c99cd4c",
        "top": "390dp",
        "width": "88%",
        "zIndex": 1
    }, {}, {});
    FlexContainer0a352ed71d08a4c.setDefaultUnit(kony.flex.DP);
    var lblResult = new kony.ui.Label({
        "height": "preferred",
        "id": "lblResult",
        "isVisible": true,
        "left": "5dp",
        "skin": "CopyslLabel05dd460ca2a9a48",
        "top": "5dp",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    FlexContainer0a352ed71d08a4c.add(lblResult);
    frmClogic.add(Label0433e4587276741, txtFunction, CopyLabel0cd0fe2f662c74c, txtArea, Button0aa44fcf93d4344, bntLambdaInvoke, CopyLabel044b38899b0f44e, CopyTextArea012fe71368c304b, FlexContainer0a352ed71d08a4c);
};

function frmClogicGlobals() {
    frmClogic = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmClogic,
        "enabledForIdleTimeout": false,
        "headers": [FlexContainer040318fa6a58b47],
        "id": "frmClogic",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "preShow": AS_Form_c3821e1759d54b95a2a830e53b6692fc,
        "skin": "CopyslForm053bd4bed76e44a",
        "title": "Cloud Logic"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "CopyslTitleBar0ea060e9f07e546",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
    frmClogic.info = {
        "kuid": "dc6487cea29d45d88993f972cd130c7e"
    };
};