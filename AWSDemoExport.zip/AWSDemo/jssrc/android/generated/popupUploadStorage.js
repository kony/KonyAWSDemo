function addWidgetspopupUploadStorage() {
    var HBox0957bcae37dbe44 = new kony.ui.Box({
        "id": "HBox0957bcae37dbe44",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL,
        "position": constants.BOX_POSITION_AS_NORMAL,
        "skin": "slHbox"
    }, {
        "containerWeight": 100,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [5, 0, 5, 5],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": true,
        "widgetAlignment": constants.WIDGET_ALIGN_BOTTOM_CENTER
    }, {});
    var VBox091e0c84e226d46 = new kony.ui.Box({
        "id": "VBox091e0c84e226d46",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_VERTICAL,
        "position": constants.BOX_POSITION_AS_NORMAL,
        "skin": "CopyslVbox048bee8728dd047"
    }, {
        "containerWeight": 100,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_BOTTOM_LEFT
    }, {});
    var CopyButton0888653dcdc8241 = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "id": "CopyButton0888653dcdc8241",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "text": "Upload"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [4, 4, 4, 4],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_BOTTOM_CENTER
    }, {});
    var CopyLine03bb0fe6a628a4b = new kony.ui.Line({
        "id": "CopyLine03bb0fe6a628a4b",
        "isVisible": true,
        "skin": "CopyslLine04a021120aa7147"
    }, {
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "thickness": 1
    }, {});
    var CopyButton05f07c1a689524c = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "id": "CopyButton05f07c1a689524c",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "text": "New Folder"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [4, 4, 4, 4],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_BOTTOM_CENTER
    }, {});
    var CopyLine000b249cc902948 = new kony.ui.Line({
        "id": "CopyLine000b249cc902948",
        "isVisible": true,
        "skin": "CopyslLine04a021120aa7147"
    }, {
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "thickness": 1
    }, {});
    var Button0f6451480e4174a = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "id": "Button0f6451480e4174a",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "text": "Refresh"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [4, 4, 4, 4],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_BOTTOM_CENTER
    }, {});
    var Line065cb55e8b81f43 = new kony.ui.Line({
        "id": "Line065cb55e8b81f43",
        "isVisible": true,
        "skin": "CopyslLine04a021120aa7147"
    }, {
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "thickness": 1
    }, {});
    var CopyButton0f34ca78a67a948 = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "id": "CopyButton0f34ca78a67a948",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "text": "Download Recent"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [4, 4, 4, 4],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    var CopyLine0c59d8fd6309146 = new kony.ui.Line({
        "id": "CopyLine0c59d8fd6309146",
        "isVisible": true,
        "skin": "CopyslLine04a021120aa7147"
    }, {
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "thickness": 1
    }, {});
    var CopyButton02c64fb1904af4d = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "id": "CopyButton02c64fb1904af4d",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "text": "Set Cache Size"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [4, 4, 4, 4],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    var CopyLine0f7d01567a2ad42 = new kony.ui.Line({
        "id": "CopyLine0f7d01567a2ad42",
        "isVisible": true,
        "skin": "CopyslLine04a021120aa7147"
    }, {
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "thickness": 1
    }, {});
    var CopyButton0461c0edf4f0a49 = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue0953b4e4f0ffd48",
        "id": "CopyButton0461c0edf4f0a49",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue0953b4e4f0ffd48",
        "text": "Clear Cache"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [4, 4, 4, 4],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    VBox091e0c84e226d46.add(CopyButton0888653dcdc8241, CopyLine03bb0fe6a628a4b, CopyButton05f07c1a689524c, CopyLine000b249cc902948, Button0f6451480e4174a, Line065cb55e8b81f43, CopyButton0f34ca78a67a948, CopyLine0c59d8fd6309146, CopyButton02c64fb1904af4d, CopyLine0f7d01567a2ad42, CopyButton0461c0edf4f0a49);
    HBox0957bcae37dbe44.add(VBox091e0c84e226d46);
    var Button0238c56078d134c = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue0db3de3caea9643",
        "id": "Button0238c56078d134c",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue0db3de3caea9643",
        "text": "Cancel"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [5, 0, 5, 5],
        "marginInPixel": false,
        "padding": [4, 4, 4, 4],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    popupUploadStorage.add(HBox0957bcae37dbe44, Button0238c56078d134c);
};

function popupUploadStorageGlobals() {
    popupUploadStorage = new kony.ui.Popup({
        "addWidgets": addWidgetspopupUploadStorage,
        "id": "popupUploadStorage",
        "isModal": false,
        "skin": "CopyslPopup0edcb4357ad074c",
        "transparencyBehindThePopup": 40
    }, {
        "containerHeight": 65,
        "containerHeightReference": constants.CONTAINER_HEIGHT_BY_DEVICE_REFERENCE,
        "containerWeight": 100,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "inTransitionConfig": {
            "animation": 0
        },
        "outTransitionConfig": {
            "formTransition": "None"
        },
        "windowSoftInputMode": constants.POPUP_ADJUST_PAN
    });
    popupUploadStorage.info = {
        "notesId": "e5a4ec28d4784f20a4babf6b3263b9bc",
        "kuid": "e5a4ec28d4784f20a4babf6b3263b9bc"
    };
};