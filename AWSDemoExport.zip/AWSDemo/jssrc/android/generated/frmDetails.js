function addWidgetsfrmDetails() {
    frmDetails.setDefaultUnit(kony.flex.DP);
    var flxIdentity = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxIdentity",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "1dp",
        "skin": "slFbox",
        "top": "90%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxIdentity.setDefaultUnit(kony.flex.DP);
    var imgUserIdentity = new kony.ui.Image2({
        "centerX": 70,
        "centerY": 17,
        "id": "imgUserIdentity",
        "isVisible": true,
        "left": "40dp",
        "skin": "slImage",
        "src": "signinsmall.png",
        "top": "10dp",
        "width": 20,
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblUserIdentity = new kony.ui.Label({
        "centerY": 17,
        "id": "lblUserIdentity",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0f273791f654748",
        "text": "Demo User Identity",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxIdentity.add(imgUserIdentity, lblUserIdentity);
    var flxPoweredby = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "5%",
        "id": "flxPoweredby",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10dp",
        "skin": "slFbox",
        "top": "85%",
        "width": "95%",
        "zIndex": 1
    }, {}, {});
    flxPoweredby.setDefaultUnit(kony.flex.DP);
    var lblPoweredBy = new kony.ui.Label({
        "id": "lblPoweredBy",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0ab7c4e3c9c7d49",
        "text": "Powered by Amazon Cognito",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxPoweredby.add(lblPoweredBy);
    var flxDataStorageDetails = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "20%",
        "id": "flxDataStorageDetails",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10dp",
        "skin": "slFbox",
        "top": "80%",
        "width": "95%",
        "zIndex": 1
    }, {}, {});
    flxDataStorageDetails.setDefaultUnit(kony.flex.DP);
    var CopylblPoweredBy0eb712fe8b08248 = new kony.ui.Label({
        "id": "CopylblPoweredBy0eb712fe8b08248",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0ab7c4e3c9c7d49",
        "text": "Powered by Amazon Cognito and Amazon S3",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyFlexContainer0581419dac26b41 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "clipBounds": true,
        "id": "CopyFlexContainer0581419dac26b41",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "1dp",
        "skin": "slFbox",
        "top": "20%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    CopyFlexContainer0581419dac26b41.setDefaultUnit(kony.flex.DP);
    var CopyimgUserIdentity0e8c472c4d9224e = new kony.ui.Image2({
        "centerX": 70,
        "centerY": 17,
        "id": "CopyimgUserIdentity0e8c472c4d9224e",
        "isVisible": true,
        "left": "40dp",
        "skin": "slImage",
        "src": "userdatastoragesmall.png",
        "top": "10dp",
        "width": 20,
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopylblUserIdentity0e306ca98431844 = new kony.ui.Label({
        "centerY": 17,
        "id": "CopylblUserIdentity0e306ca98431844",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0f273791f654748",
        "text": "Demo User File Storage",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    CopyFlexContainer0581419dac26b41.add(CopyimgUserIdentity0e8c472c4d9224e, CopylblUserIdentity0e306ca98431844);
    var CopyFlexContainer00d215877bce745 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "clipBounds": true,
        "id": "CopyFlexContainer00d215877bce745",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "1dp",
        "skin": "slFbox",
        "top": "50%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    CopyFlexContainer00d215877bce745.setDefaultUnit(kony.flex.DP);
    var CopyimgUserIdentity01e3cc02ccc3247 = new kony.ui.Image2({
        "centerX": 70,
        "centerY": 17,
        "id": "CopyimgUserIdentity01e3cc02ccc3247",
        "isVisible": true,
        "left": "40dp",
        "skin": "slImage",
        "src": "userprofilesmall.png",
        "top": "10dp",
        "width": 20,
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopylblUserIdentity0780d4cbd9d7e44 = new kony.ui.Label({
        "centerY": 17,
        "id": "CopylblUserIdentity0780d4cbd9d7e44",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0f273791f654748",
        "text": "Demo User Profile Data",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    CopyFlexContainer00d215877bce745.add(CopyimgUserIdentity01e3cc02ccc3247, CopylblUserIdentity0780d4cbd9d7e44);
    flxDataStorageDetails.add(CopylblPoweredBy0eb712fe8b08248, CopyFlexContainer0581419dac26b41, CopyFlexContainer00d215877bce745);
    var FlexContainer04b732d5f9cb84b = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "80%",
        "id": "FlexContainer04b732d5f9cb84b",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%",
        "zIndex": 3
    }, {}, {});
    FlexContainer04b732d5f9cb84b.setDefaultUnit(kony.flex.DP);
    var lblOverView = new kony.ui.Label({
        "id": "lblOverView",
        "isVisible": true,
        "left": "20dp",
        "skin": "CopyslLabel0d6421e4ff24c4a",
        "text": "Overview",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblOverviewDetails = new kony.ui.Label({
        "id": "lblOverviewDetails",
        "isVisible": true,
        "left": "20dp",
        "skin": "CopyslLabel0fb61446bb46448",
        "text": "Whether your users sign in or not, the User sign-in feature configures Amazon Cognito to uniquely identify the user and provide your app the appropriate credentials to access your AWS resources.",
        "top": 10,
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblDescription = new kony.ui.Label({
        "id": "lblDescription",
        "isVisible": true,
        "left": "20dp",
        "skin": "CopyslLabel0279ba4d50bea48",
        "text": "Sample App Features",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var flxDetails = new kony.ui.FlexScrollContainer({
        "allowHorizontalBounce": true,
        "allowVerticalBounce": true,
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "bounces": true,
        "clipBounds": true,
        "enableScrolling": true,
        "horizontalScrollIndicator": false,
        "id": "flxDetails",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": 0,
        "pagingEnabled": false,
        "scrollDirection": kony.flex.SCROLL_VERTICAL,
        "skin": "slFSbox",
        "top": 0,
        "verticalScrollIndicator": true,
        "width": "100%",
        "zIndex": 3
    }, {}, {});
    flxDetails.setDefaultUnit(kony.flex.DP);
    var lblDescriptionDetails = new kony.ui.Label({
        "height": "100%",
        "id": "lblDescriptionDetails",
        "isVisible": true,
        "left": "20dp",
        "right": "10dp",
        "skin": "CopyslLabel0fb61446bb46448",
        "text": "The Sample App demonstrates assignment of a unique identifier for the user, the Amazon Cognito User ID. If optional or mandatory User Sign-in has been enabled in your project, then the Sample App also includes a sign-in screen, with a button for each configured sign-in provider.",
        "top": "10dp",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxDetails.add(lblDescriptionDetails);
    FlexContainer04b732d5f9cb84b.add(lblOverView, lblOverviewDetails, lblDescription, flxDetails);
    frmDetails.add(flxIdentity, flxPoweredby, flxDataStorageDetails, FlexContainer04b732d5f9cb84b);
};

function frmDetailsGlobals() {
    frmDetails = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmDetails,
        "enabledForIdleTimeout": false,
        "id": "frmDetails",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm053bd4bed76e44a"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "CopyslTitleBar0ea060e9f07e546",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
    frmDetails.info = {
        "kuid": "d3257fd39559479a92ddc12ed07c047c"
    };
};