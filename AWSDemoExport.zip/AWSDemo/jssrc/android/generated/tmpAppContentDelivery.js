function initializetmpAppContentDelivery() {
    FlexContainer024fc41fdcbdc41 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "19%",
        "id": "FlexContainer024fc41fdcbdc41",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox",
        "width": "100%"
    }, {}, {});
    FlexContainer024fc41fdcbdc41.setDefaultUnit(kony.flex.DP);
    var lblImageName = new kony.ui.Label({
        "height": "40%",
        "id": "lblImageName",
        "isVisible": true,
        "left": "3%",
        "skin": "CopyslLabel017a1760fef1445",
        "text": "Label",
        "top": "3%",
        "width": "preferred"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblImageSize = new kony.ui.Label({
        "height": "preferred",
        "id": "lblImageSize",
        "isVisible": true,
        "left": "3%",
        "skin": "CopyslLabel040abe9d96d5245",
        "text": "Label",
        "top": "55%",
        "width": "40%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var imgStar = new kony.ui.Image2({
        "bottom": "10dp",
        "height": "preferred",
        "id": "imgStar",
        "isVisible": false,
        "left": "55%",
        "skin": "slImage",
        "src": "star.png",
        "top": "10dp",
        "width": "40%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var imgCheck = new kony.ui.Image2({
        "height": "preferred",
        "id": "imgCheck",
        "isVisible": false,
        "left": "90%",
        "skin": "slImage",
        "src": "check.png",
        "top": "20dp",
        "width": "preferred",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer024fc41fdcbdc41.add(lblImageName, lblImageSize, imgStar, imgCheck);
}