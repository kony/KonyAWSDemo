//Lambda Functions create by Mobile Hub
var LambdaFunctiontoInvoke = "helloworld-hwHandlr-mobilehub-676070864";
var validateUserFunction = "validateUser-vUserHndlr-mobilehub-676070864";
var createUserFunction = "createUser-cUserHndlr-mobilehub-676070864";
var createIdentitiesFunction = "createIdentities-cIDHndlr-mobilehub-676070864";
var News = "mysampleapp-mobilehub-676070864-News";
var userDetails = "mysampleapp-mobilehub-676070864-userdetails";
var config = {
    /*Please provide the access key id && secret access key for your user */
    accessKeyId: 'AKIAJ5EH55CKT7H2QBSA',
    secretAccessKey: 'o//eBCE43++jb1VrUumwe4ntaQo+DpQB/6b5PSXA',
    region: 'us-east-1',
    Bucket: 'tmysampleapp-deployments-mobilehub-676070864',
    IdentityPoolId: "us-east-1:9c8f0110-3590-4669-a0ae-ad17edfb9afc",
    UserPoolId: 'us-east-1_KBBHl1qHU',
    ClientId: '2d20norfdreu2s3o29seuusek8'
};