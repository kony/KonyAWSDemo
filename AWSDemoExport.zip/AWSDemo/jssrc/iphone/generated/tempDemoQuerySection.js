function initializetempDemoQuerySection() {
    flxSectionHeader = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "clipBounds": true,
        "id": "flxSectionHeader",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0111738f7fb094b",
        "width": "100%"
    }, {}, {});
    flxSectionHeader.setDefaultUnit(kony.flex.DP);
    var lblSectionHead = new kony.ui.Label({
        "height": "preferred",
        "id": "lblSectionHead",
        "isVisible": true,
        "left": "20dp",
        "skin": "CopyslLabel03bac3408a36e49",
        "top": "20dp",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 2],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flxSectionHeader.add(lblSectionHead);
}