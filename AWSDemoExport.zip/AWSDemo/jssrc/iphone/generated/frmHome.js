function addWidgetsfrmHome() {
    frmHome.setDefaultUnit(kony.flex.DP);
    var flxHeader = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxHeader",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox086592890be6143",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxHeader.setDefaultUnit(kony.flex.DP);
    var Label0fdbc58e7027b4e = new kony.ui.Label({
        "centerX": "50%",
        "height": "preferred",
        "id": "Label0fdbc58e7027b4e",
        "isVisible": true,
        "skin": "CopyslLabel0e9249e04f66847",
        "text": "My Sample App",
        "top": "30%",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flxHeader.add(Label0fdbc58e7027b4e);
    var segHome = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "Image07f8a3c9e83d64f": "signin.png",
            "Label06a97ee24d2434a": "Enable user login with popular 3rd party providers",
            "lblTitle": "User Sign-in"
        }, {
            "Image07f8a3c9e83d64f": "userdatastorage.png",
            "Label06a97ee24d2434a": "Save user files in the cloud and sync user data in key/value pairs.",
            "lblTitle": "User Data Storage"
        }, {
            "Image07f8a3c9e83d64f": "cloudlogic.png",
            "Label06a97ee24d2434a": "Run backend functions in the cloud.",
            "lblTitle": "Cloud Logic"
        }, {
            "Image07f8a3c9e83d64f": "database.png",
            "Label06a97ee24d2434a": "Store data in the cloud",
            "lblTitle": "NoSQL Database"
        }],
        "groupCells": false,
        "height": "100%",
        "id": "segHome",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": FlexContainer012deee8f56984d,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "10%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "FlexContainer012deee8f56984d": "FlexContainer012deee8f56984d",
            "FlexContainer029c687ef32254b": "FlexContainer029c687ef32254b",
            "FlexContainer0828b5ad3ffbe44": "FlexContainer0828b5ad3ffbe44",
            "FlexContainer0dc7c0d5b4dee47": "FlexContainer0dc7c0d5b4dee47",
            "Image07f8a3c9e83d64f": "Image07f8a3c9e83d64f",
            "Label06a97ee24d2434a": "Label06a97ee24d2434a",
            "lblTitle": "lblTitle"
        },
        "width": "100%"
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "bounces": true,
        "editStyle": constants.SEGUI_EDITING_STYLE_NONE,
        "enableDictionary": false,
        "indicator": constants.SEGUI_ROW_SELECT,
        "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
        "showProgressIndicator": true
    });
    frmHome.add(flxHeader, segHome);
};

function frmHomeGlobals() {
    frmHome = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmHome,
        "enabledForIdleTimeout": false,
        "id": "frmHome",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "postShow": AS_Form_7971aa9421bf4728bf3919cc55debd6d,
        "preShow": AS_Form_9bbe6b8710f7419282dcd0b2a654f4b6,
        "skin": "CopyslForm053bd4bed76e44a",
        "title": "My Sample App"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "CopyslTitleBar0ea060e9f07e546"
    });
    frmHome.info = {
        "kuid": "bdb62212d04341d19b37b177eaf487aa"
    };
};