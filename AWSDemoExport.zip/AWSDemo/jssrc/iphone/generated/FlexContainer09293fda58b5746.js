function initializeFlexContainer09293fda58b5746() {
    FlexContainer09293fda58b5746 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "clipBounds": true,
        "id": "FlexContainer09293fda58b5746",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox0aa3902e7f38441"
    }, {}, {});
    FlexContainer09293fda58b5746.setDefaultUnit(kony.flex.DP);
    var FlexContainer0828b5ad3ffbe44 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "clipBounds": true,
        "id": "FlexContainer0828b5ad3ffbe44",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox0aa3902e7f38441",
        "top": "0dp",
        "width": "22%"
    }, {}, {});
    FlexContainer0828b5ad3ffbe44.setDefaultUnit(kony.flex.DP);
    var Image07f8a3c9e83d64f = new kony.ui.Image2({
        "id": "Image07f8a3c9e83d64f",
        "isVisible": true,
        "left": "10dp",
        "skin": "slImage08445f76ef0fe41",
        "src": "pinb.png",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "containerWeight": 100,
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    FlexContainer0828b5ad3ffbe44.add(Image07f8a3c9e83d64f);
    var FlexContainer0dc7c0d5b4dee47 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "clipBounds": true,
        "id": "FlexContainer0dc7c0d5b4dee47",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "22%",
        "skin": "slFbox0aa3902e7f38441",
        "top": 0,
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {}, {});
    FlexContainer0dc7c0d5b4dee47.setDefaultUnit(kony.flex.DP);
    var lblTitle = new kony.ui.Label({
        "id": "lblTitle",
        "isVisible": true,
        "left": 0,
        "skin": "CopyslLabel06c3bb6b21d0543",
        "text": "Label",
        "top": "11dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    FlexContainer0dc7c0d5b4dee47.add(lblTitle);
    var FlexContainer029c687ef32254b = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "50dp",
        "id": "FlexContainer029c687ef32254b",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "22%",
        "skin": "slFbox0aa3902e7f38441",
        "top": "20dp",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    FlexContainer029c687ef32254b.setDefaultUnit(kony.flex.DP);
    var Label06a97ee24d2434a = new kony.ui.Label({
        "height": 30,
        "id": "Label06a97ee24d2434a",
        "isVisible": true,
        "left": 0,
        "skin": "CopyslLabel06330b664aa3d42",
        "text": "Label",
        "top": "14dp",
        "width": "80%"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    FlexContainer029c687ef32254b.add(Label06a97ee24d2434a);
    FlexContainer09293fda58b5746.add(FlexContainer0828b5ad3ffbe44, FlexContainer0dc7c0d5b4dee47, FlexContainer029c687ef32254b);
}