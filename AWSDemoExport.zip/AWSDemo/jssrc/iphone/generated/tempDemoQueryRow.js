function initializetempDemoQueryRow() {
    flxMain = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "clipBounds": true,
        "height": "preferred",
        "id": "flxMain",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "skin": "SKNMBLFFFFFF",
        "width": "100%"
    }, {}, {});
    flxMain.setDefaultUnit(kony.flex.DP);
    var lblHeading = new kony.ui.Label({
        "height": "preferred",
        "id": "lblHeading",
        "isVisible": true,
        "left": "1px",
        "skin": "CopyslLabel0d91e5efbfe1643",
        "text": "Label",
        "top": "1px",
        "width": "90%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblDescription = new kony.ui.Label({
        "height": "preferred",
        "id": "lblDescription",
        "isVisible": true,
        "left": "1px",
        "skin": "SKNLBLFFFFFFop50",
        "text": "Label",
        "top": "1px",
        "width": "95%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flxMain.add(lblHeading, lblDescription);
}