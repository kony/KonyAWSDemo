function initializeheader1() {
    FlexContainer040318fa6a58b47 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "50dp",
        "id": "FlexContainer040318fa6a58b47",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "flexHeader",
        "width": "100%"
    }, {}, {});
    FlexContainer040318fa6a58b47.setDefaultUnit(kony.flex.DP);
    var backBtn = new kony.ui.Button({
        "centerY": "50%",
        "focusSkin": "CopyslButtonGlossRed0781dcbd1fe4448",
        "height": "45%",
        "id": "backBtn",
        "isVisible": true,
        "left": "1%",
        "onClick": AS_Button_3873fba490354252a18d1f7215a8670c,
        "skin": "CopyslButtonGlossBlue04931bea67a064f",
        "text": "< Back",
        "width": "15%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    var hdrLabel = new kony.ui.Label({
        "centerX": "50%",
        "height": "50dp",
        "id": "hdrLabel",
        "isVisible": true,
        "skin": "CopyslLabel072c5f576422a4b",
        "text": "Header",
        "top": "0dp",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    FlexContainer040318fa6a58b47.add(backBtn, hdrLabel);
}