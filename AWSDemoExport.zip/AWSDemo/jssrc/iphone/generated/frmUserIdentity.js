function addWidgetsfrmUserIdentity() {
    frmUserIdentity.setDefaultUnit(kony.flex.DP);
    var FlexContainer04b732d5f9cb84b = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "80%",
        "id": "FlexContainer04b732d5f9cb84b",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "skin": "slFbox",
        "top": "20%",
        "width": "100%",
        "zIndex": 3
    }, {}, {});
    FlexContainer04b732d5f9cb84b.setDefaultUnit(kony.flex.DP);
    var Image0a26231c85d8341 = new kony.ui.Image2({
        "centerX": "50%",
        "id": "Image0a26231c85d8341",
        "isVisible": true,
        "skin": "slImage",
        "src": "usericon.png",
        "top": "0dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblOverviewDetails = new kony.ui.Label({
        "centerX": "50%",
        "id": "lblOverviewDetails",
        "isVisible": true,
        "left": 20,
        "skin": "CopyslLabel00f3ec051023749",
        "text": "User's name",
        "top": 10,
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblOverView = new kony.ui.Label({
        "centerX": "50%",
        "id": "lblOverView",
        "isVisible": true,
        "left": "20dp",
        "skin": "CopyslLabel0d6421e4ff24c4a",
        "text": "Guest User",
        "top": "5dp",
        "width": "90%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopylblOverviewDetails05965fdd5e98640 = new kony.ui.Label({
        "centerX": "50%",
        "id": "CopylblOverviewDetails05965fdd5e98640",
        "isVisible": true,
        "left": "20dp",
        "skin": "CopyslLabel00f3ec051023749",
        "text": "User's unique identifier",
        "top": 10,
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblIdentity = new kony.ui.Label({
        "centerX": "50%",
        "height": "preferred",
        "id": "lblIdentity",
        "isVisible": true,
        "left": "20dp",
        "skin": "CopyslLabel00f215d38c8be48",
        "text": "us-east-1:73681b9b-fa9f-493b-bd49-3c6e7a24e730",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    FlexContainer04b732d5f9cb84b.add(Image0a26231c85d8341, lblOverviewDetails, lblOverView, CopylblOverviewDetails05965fdd5e98640, lblIdentity);
    var Button08634bd038eb346 = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossRed0bed8800b2c3847",
        "height": "8%",
        "id": "Button08634bd038eb346",
        "isVisible": true,
        "left": "35%",
        "onClick": AS_Button_bc43f5a61aec476c8ec870d4c8259c98,
        "skin": "CopyslButtonGlossBlue053e2111aaf0147",
        "text": "Sign Out",
        "top": "90%",
        "width": "30%",
        "zIndex": 3
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    frmUserIdentity.add(FlexContainer04b732d5f9cb84b, Button08634bd038eb346);
};

function frmUserIdentityGlobals() {
    frmUserIdentity = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmUserIdentity,
        "enabledForIdleTimeout": false,
        "headers": [FlexContainer040318fa6a58b47],
        "id": "frmUserIdentity",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "preShow": AS_Form_25e8a43dae8b43b9bd4c9ea30d0d87fc,
        "skin": "CopyslForm053bd4bed76e44a",
        "title": "User Identity"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "CopyslTitleBar0ea060e9f07e546"
    });
    frmUserIdentity.info = {
        "notesId": "f567eac3408c4c3d845dc6d9a7d55c2a",
        "kuid": "f567eac3408c4c3d845dc6d9a7d55c2a"
    };
};