function addWidgetsfrmUserFileStorage() {
    frmUserFileStorage.setDefaultUnit(kony.flex.DP);
    var FlexContainer0b13473f745aa4b = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "clipBounds": true,
        "id": "FlexContainer0b13473f745aa4b",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox00e66a3ba50dd4e",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    FlexContainer0b13473f745aa4b.setDefaultUnit(kony.flex.DP);
    var FlexContainer0ef14390d28454a = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "clipBounds": true,
        "height": "preferred",
        "id": "FlexContainer0ef14390d28454a",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "5%",
        "skin": "CopyslFbox0b635c0789f6a4f",
        "top": "12dp",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    FlexContainer0ef14390d28454a.setDefaultUnit(kony.flex.DP);
    var CopyButton07427a5b1f2544e = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue00662a019fd7042",
        "height": "40dp",
        "id": "CopyButton07427a5b1f2544e",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslButtonGlossBlue00662a019fd7042",
        "text": "Public",
        "top": "0dp",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    var CopyButton0b8c79e9aac594d = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue08d69ec5bc65040",
        "height": "40dp",
        "id": "CopyButton0b8c79e9aac594d",
        "isVisible": true,
        "left": "50%",
        "skin": "CopyslButtonGlossBlue08d69ec5bc65040",
        "text": "Private",
        "top": "0dp",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    FlexContainer0ef14390d28454a.add(CopyButton07427a5b1f2544e, CopyButton0b8c79e9aac594d);
    var Button066ef6b23a53c48 = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "50dp",
        "id": "Button066ef6b23a53c48",
        "isVisible": false,
        "left": "10dp",
        "onClick": AS_Button_58b10d870f9b43118d385d316c4dab9d,
        "skin": "btnBackSkinUpload",
        "text": "Upload",
        "top": "62dp",
        "width": "60dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    var CopyButton0c1eb543bd14544 = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "50dp",
        "id": "CopyButton0c1eb543bd14544",
        "isVisible": false,
        "left": "125dp",
        "onClick": AS_Button_18b6c96901244029a7585b83306eaa74,
        "skin": "btnBackSkinUpload",
        "text": "Name",
        "top": "62dp",
        "width": "55dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    var CopyButton08df838f8845340 = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "50dp",
        "id": "CopyButton08df838f8845340",
        "isVisible": false,
        "left": "180dp",
        "onClick": AS_Button_fcbf039b144f4d67b186374fb9f7bd97,
        "skin": "btnBackSkinUpload",
        "text": "Size",
        "top": "62dp",
        "width": "45dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    var CopyButton0f9f148820dbc4b = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "50dp",
        "id": "CopyButton0f9f148820dbc4b",
        "isVisible": false,
        "left": "225dp",
        "onClick": AS_Button_89705506861e4d458f0da17a8dae7393,
        "skin": "btnBackSkinUpload",
        "text": "Modified Date",
        "top": "62dp",
        "width": "105dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    var Label057bd938d9e1842 = new kony.ui.Label({
        "height": "preferred",
        "id": "Label057bd938d9e1842",
        "isVisible": false,
        "left": "70dp",
        "skin": "CopylblPath0e486f798fc6b43",
        "text": "Sort By",
        "top": "78dp",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblpath = new kony.ui.Label({
        "height": "25dp",
        "id": "lblpath",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslLabel02adf10699c4243",
        "text": "Path:/",
        "top": "0dp",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    FlexContainer0b13473f745aa4b.add(FlexContainer0ef14390d28454a, Button066ef6b23a53c48, CopyButton0c1eb543bd14544, CopyButton08df838f8845340, CopyButton0f9f148820dbc4b, Label057bd938d9e1842, lblpath);
    var kmb9df24c0252433f9f170926499b8a3b = new kony.ui.FlexContainer({
        "clipBounds": true,
        "isMaster": true,
        "height": "100%",
        "id": "flxS3list",
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onClick": AS_FlexContainer_2c8d41ae09b440b4a7113bfa3a749e8b,
        "top": "0dp",
        "width": "100%",
        "isVisible": true,
        "skin": "slFbox"
    }, {}, {});
    kmb9df24c0252433f9f170926499b8a3b.setDefaultUnit(kony.flex.DP);
    var km9e95b5c91d7402ea8a8f7476059a568 = new kony.ui.SegmentedUI2({
        "bottom": "0dp",
        "data": [{
            "imgCheck": "",
            "imgStar": "",
            "lblImageName": "",
            "lblImageSize": ""
        }],
        "height": "70%",
        "id": "segContentS3",
        "left": "0dp",
        "onRowClick": AS_Segment_913bd6df60ef44b0834907acbba144c3,
        "scrollingEvents": {},
        "width": "100%",
        "zIndex": 1,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "groupCells": false,
        "isVisible": true,
        "needPageIndicator": true,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": FlexContainer024fc41fdcbdc41,
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "FlexContainer024fc41fdcbdc41": "FlexContainer024fc41fdcbdc41",
            "imgCheck": "imgCheck",
            "imgStar": "imgStar",
            "lblImageName": "lblImageName",
            "lblImageSize": "lblImageSize"
        }
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "bounces": true,
        "editStyle": constants.SEGUI_EDITING_STYLE_NONE,
        "enableDictionary": false,
        "indicator": constants.SEGUI_NONE,
        "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
        "showProgressIndicator": false
    });
    kmb9df24c0252433f9f170926499b8a3b.add(km9e95b5c91d7402ea8a8f7476059a568);
    var Label0e4dabc314fcb4d = new kony.ui.Label({
        "centerX": "50%",
        "height": "preferred",
        "id": "Label0e4dabc314fcb4d",
        "isVisible": true,
        "skin": "CopyslLabel006129191eea742",
        "text": "Cache Summary",
        "top": "70dp",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var Label0be7c56769f9741 = new kony.ui.Label({
        "height": "5%",
        "id": "Label0be7c56769f9741",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0f61064a2a8ce40",
        "text": "Limit",
        "top": "90dp",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var Label00115b49495d641 = new kony.ui.Label({
        "height": "5%",
        "id": "Label00115b49495d641",
        "isVisible": true,
        "left": "27%",
        "skin": "CopyslLabel03d098a06192c4a",
        "text": "InUse",
        "top": "90dp",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var Label0669db6a4f28e40 = new kony.ui.Label({
        "height": "5%",
        "id": "Label0669db6a4f28e40",
        "isVisible": true,
        "left": "47%",
        "skin": "CopyslLabel01c4c2b447aa540",
        "text": "Available",
        "top": "90dp",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyLabel0a6abc9d58a004d = new kony.ui.Label({
        "height": "5%",
        "id": "CopyLabel0a6abc9d58a004d",
        "isVisible": true,
        "left": "53.46%",
        "skin": "CopyslLabel01c4c2b447aa540",
        "text": "∞",
        "top": "120dp",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var Label09d40a8e86c9e49 = new kony.ui.Label({
        "height": "5%",
        "id": "Label09d40a8e86c9e49",
        "isVisible": true,
        "left": "75%",
        "skin": "CopyslLabel05b8cac3c666d45",
        "text": "Pinned",
        "top": "90dp",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyLabel0ec2c99d6aa084f = new kony.ui.Label({
        "height": "5%",
        "id": "CopyLabel0ec2c99d6aa084f",
        "isVisible": true,
        "left": "77%",
        "skin": "CopyslLabel05b8cac3c666d45",
        "text": "0 KB",
        "top": "120dp",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyLabel0b4714f35264344 = new kony.ui.Label({
        "height": "5%",
        "id": "CopyLabel0b4714f35264344",
        "isVisible": true,
        "left": "7.48%",
        "skin": "CopyslLabel0f61064a2a8ce40",
        "text": "∞",
        "top": "120dp",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyLabel0bdaa462ffb294f = new kony.ui.Label({
        "height": "5%",
        "id": "CopyLabel0bdaa462ffb294f",
        "isVisible": true,
        "left": "27%",
        "skin": "CopyslLabel03d098a06192c4a",
        "text": "0 KB",
        "top": "120dp",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var FlexContainer0ac60d1e6acf041 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "1dp",
        "id": "FlexContainer0ac60d1e6acf041",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox01d4f5e19089045",
        "top": "115dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer0ac60d1e6acf041.setDefaultUnit(kony.flex.DP);
    FlexContainer0ac60d1e6acf041.add();
    frmUserFileStorage.add(FlexContainer0b13473f745aa4b, kmb9df24c0252433f9f170926499b8a3b, Label0e4dabc314fcb4d, Label0be7c56769f9741, Label00115b49495d641, Label0669db6a4f28e40, CopyLabel0a6abc9d58a004d, Label09d40a8e86c9e49, CopyLabel0ec2c99d6aa084f, CopyLabel0b4714f35264344, CopyLabel0bdaa462ffb294f, FlexContainer0ac60d1e6acf041);
};

function frmUserFileStorageGlobals() {
    frmUserFileStorage = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmUserFileStorage,
        "enabledForIdleTimeout": false,
        "headers": [FlexContainer040318fa6a58b47],
        "id": "frmUserFileStorage",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "postShow": AS_Form_4478f9a656044c8c80d9f99e3eee1c71,
        "preShow": AS_Form_a6958e45d39a45f598ed631af3f3cd7e,
        "skin": "CopyslForm053bd4bed76e44a",
        "title": "User File Storage"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "CopyslTitleBar0d659d32884f647"
    });
    frmUserFileStorage.info = {
        "notesId": "775b463fd60641fc8ce457c463e3b173",
        "kuid": "775b463fd60641fc8ce457c463e3b173"
    };
};