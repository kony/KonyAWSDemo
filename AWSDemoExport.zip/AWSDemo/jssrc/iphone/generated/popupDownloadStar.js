function addWidgetspopupDownloadStar() {
    var HBox0957bcae37dbe44 = new kony.ui.Box({
        "id": "HBox0957bcae37dbe44",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL,
        "position": constants.BOX_POSITION_AS_NORMAL,
        "skin": "slHbox"
    }, {
        "containerWeight": 100,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [5, 0, 5, 5],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": true,
        "widgetAlignment": constants.WIDGET_ALIGN_BOTTOM_CENTER
    }, {});
    var VBox091e0c84e226d46 = new kony.ui.Box({
        "id": "VBox091e0c84e226d46",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_VERTICAL,
        "position": constants.BOX_POSITION_AS_NORMAL,
        "skin": "CopyslVbox048bee8728dd047"
    }, {
        "containerWeight": 100,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_BOTTOM_LEFT
    }, {});
    var Button0f6451480e4174a = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "id": "Button0f6451480e4174a",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "text": "Open"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [4, 4, 4, 4],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_BOTTOM_CENTER
    }, {
        "showProgressIndicator": true
    });
    var Line065cb55e8b81f43 = new kony.ui.Line({
        "id": "Line065cb55e8b81f43",
        "isVisible": true,
        "skin": "CopyslLine04a021120aa7147"
    }, {
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "thickness": 1
    }, {});
    var CopyButton0f34ca78a67a948 = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "id": "CopyButton0f34ca78a67a948",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "text": "Download"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [4, 4, 4, 4],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "showProgressIndicator": true
    });
    var CopyLine0c59d8fd6309146 = new kony.ui.Line({
        "id": "CopyLine0c59d8fd6309146",
        "isVisible": true,
        "skin": "CopyslLine04a021120aa7147"
    }, {
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "thickness": 1
    }, {});
    var CopyButton02c64fb1904af4d = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "id": "CopyButton02c64fb1904af4d",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "text": "Download & Pin"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [4, 4, 4, 4],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "showProgressIndicator": true
    });
    var CopyLine0f7d01567a2ad42 = new kony.ui.Line({
        "id": "CopyLine0f7d01567a2ad42",
        "isVisible": true,
        "skin": "CopyslLine04a021120aa7147"
    }, {
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "thickness": 1
    }, {});
    var btnPinUnpin = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "id": "btnPinUnpin",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue01a88d3b28eda44",
        "text": "pin"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [4, 4, 4, 4],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "showProgressIndicator": true
    });
    var CopyLine0ca0e84cefc184f = new kony.ui.Line({
        "id": "CopyLine0ca0e84cefc184f",
        "isVisible": true,
        "skin": "CopyslLine04a021120aa7147"
    }, {
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "thickness": 1
    }, {});
    var CopyButton0461c0edf4f0a49 = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue0953b4e4f0ffd48",
        "id": "CopyButton0461c0edf4f0a49",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue0953b4e4f0ffd48",
        "text": "Delete Local Copy"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [4, 4, 4, 4],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "showProgressIndicator": true
    });
    VBox091e0c84e226d46.add(Button0f6451480e4174a, Line065cb55e8b81f43, CopyButton0f34ca78a67a948, CopyLine0c59d8fd6309146, CopyButton02c64fb1904af4d, CopyLine0f7d01567a2ad42, btnPinUnpin, CopyLine0ca0e84cefc184f, CopyButton0461c0edf4f0a49);
    HBox0957bcae37dbe44.add(VBox091e0c84e226d46);
    var Button0238c56078d134c = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue0db3de3caea9643",
        "id": "Button0238c56078d134c",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue0db3de3caea9643",
        "text": "Cancel"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [5, 0, 5, 5],
        "marginInPixel": false,
        "padding": [4, 4, 4, 4],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "showProgressIndicator": true
    });
    popupDownloadStar.add(HBox0957bcae37dbe44, Button0238c56078d134c);
};

function popupDownloadStarGlobals() {
    popupDownloadStar = new kony.ui.Popup({
        "addWidgets": addWidgetspopupDownloadStar,
        "id": "popupDownloadStar",
        "isModal": false,
        "skin": "CopyslPopup0edcb4357ad074c",
        "transparencyBehindThePopup": 40
    }, {
        "containerHeight": 58,
        "containerHeightReference": constants.CONTAINER_HEIGHT_BY_DEVICE_REFERENCE,
        "containerWeight": 100,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "bounces": true,
        "configureExtendTop": false,
        "footerOverlap": false,
        "headerOverlap": false,
        "inTransitionConfig": {
            "transitionDirection": "fromBottom",
            "transitionEffect": "none"
        },
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "outTransitionConfig": {
            "formTransition": "None"
        }
    });
    popupDownloadStar.info = {
        "notesId": "aa499a4daf81480c889cc3a421d6e4cd",
        "kuid": "aa499a4daf81480c889cc3a421d6e4cd"
    };
};