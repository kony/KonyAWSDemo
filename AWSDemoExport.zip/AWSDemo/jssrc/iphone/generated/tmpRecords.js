function initializetmpRecords() {
    flxTemplate = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "20%",
        "id": "flxTemplate",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox",
        "width": "100%"
    }, {}, {});
    flxTemplate.setDefaultUnit(kony.flex.DP);
    var lblPartition = new kony.ui.Label({
        "height": "20%",
        "id": "lblPartition",
        "isVisible": true,
        "left": "40%",
        "skin": "CopyslLabel0c65b722d49d54a",
        "text": "Label",
        "top": "30%",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblSort = new kony.ui.Label({
        "height": "20%",
        "id": "lblSort",
        "isVisible": true,
        "left": "40%",
        "skin": "CopyslLabel0934d3e8bc5074d",
        "text": "Label",
        "top": "50%",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblPartitionKey = new kony.ui.Label({
        "height": "20%",
        "id": "lblPartitionKey",
        "isVisible": true,
        "left": "10%",
        "skin": "CopyslLabel08bd9f667cd7644",
        "text": "PartitionKey",
        "top": "30%",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblSortKey = new kony.ui.Label({
        "height": "20%",
        "id": "lblSortKey",
        "isVisible": true,
        "left": "10%",
        "skin": "CopyslLabel08bd9f667cd7644",
        "text": "SortKey",
        "top": "50%",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblIndexKey = new kony.ui.Label({
        "height": "20%",
        "id": "lblIndexKey",
        "isVisible": true,
        "left": "10%",
        "skin": "CopyslLabel08bd9f667cd7644",
        "text": "Indexes",
        "top": "70%",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblIndex = new kony.ui.Label({
        "height": "20%",
        "id": "lblIndex",
        "isVisible": true,
        "left": "40%",
        "skin": "CopyslLabel0934d3e8bc5074d",
        "text": "Label",
        "top": "70%",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblTableName = new kony.ui.Label({
        "height": "30%",
        "id": "lblTableName",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslLabel0a9dd7811c8d14c",
        "top": "0%",
        "width": "preferred",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flxTemplate.add(lblPartition, lblSort, lblPartitionKey, lblSortKey, lblIndexKey, lblIndex, lblTableName);
}