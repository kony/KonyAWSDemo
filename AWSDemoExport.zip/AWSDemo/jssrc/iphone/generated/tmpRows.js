function initializetmpRows() {
    flxRows = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "30%",
        "id": "flxRows",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox",
        "width": "100%"
    }, {}, {});
    flxRows.setDefaultUnit(kony.flex.DP);
    var lblPartitionKey = new kony.ui.Label({
        "height": "25%",
        "id": "lblPartitionKey",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslLabel0bd8a0823902940",
        "text": "Label",
        "top": "0%",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblPartitionValue = new kony.ui.Label({
        "height": "25%",
        "id": "lblPartitionValue",
        "isVisible": true,
        "left": "50%",
        "skin": "CopyslLabel0bd8a0823902940",
        "text": "Label",
        "top": "0%",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblSortKey = new kony.ui.Label({
        "height": "25%",
        "id": "lblSortKey",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslLabel0bd8a0823902940",
        "text": "Label",
        "top": "25%",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblSortValue = new kony.ui.Label({
        "height": "25%",
        "id": "lblSortValue",
        "isVisible": true,
        "left": "50%",
        "skin": "CopyslLabel0bd8a0823902940",
        "text": "Label",
        "top": "25%",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblcategory = new kony.ui.Label({
        "height": "25%",
        "id": "lblcategory",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslLabel0bd8a0823902940",
        "text": "Label",
        "top": "50.01%",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblCategoryValue = new kony.ui.Label({
        "height": "25%",
        "id": "lblCategoryValue",
        "isVisible": true,
        "left": "50%",
        "skin": "CopyslLabel0bd8a0823902940",
        "text": "Label",
        "top": "50%",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblCreationDate = new kony.ui.Label({
        "height": "25%",
        "id": "lblCreationDate",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslLabel0bd8a0823902940",
        "text": "Label",
        "top": "75%",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblcreationDateValue = new kony.ui.Label({
        "height": "25%",
        "id": "lblcreationDateValue",
        "isVisible": true,
        "left": "50%",
        "skin": "CopyslLabel0bd8a0823902940",
        "text": "Label",
        "top": "75%",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flxRows.add(lblPartitionKey, lblPartitionValue, lblSortKey, lblSortValue, lblcategory, lblCategoryValue, lblCreationDate, lblcreationDateValue);
}