function getDynamodb() {
    var segTableData = [];
    getTableDetails("News", function(data) {
        segTableData.push({
            lblTableName: data.Table.TableName,
            lblPartition: data.Table.KeySchema[0].AttributeName,
            lblSort: data.Table.KeySchema[1].AttributeName,
            lblPartitionKey: "PartitionKey:",
            lblSortKey: "SortKey:",
            lblIndexKey: "Indexes",
            lblIndex: data.Table.GlobalSecondaryIndexes.length
        });
        frmDynamoDB.segRecords.setData(segTableData);
    });
}
/**
 * @function
 *
 */
function InsertSampleData() {
    for (var i = 0; i < 20; i++) addUserDetails("News", sampleRecords[i], function(data) {
        kony.print("putdata" + data);
    });
}
/**
 * @function
 *
 */
function RemoveSampleData() {
    for (var i = 0; i < 20; i++) {
        var params = {
            TableName: "News",
            Key: {
                "userId": {
                    "S": "us-east-1:0f1c4c04-7627-4d00-b8f9-6dbc0f5c4704"
                },
                "articleId": {
                    "S": sampleRecords[i].articleId.S
                }
            }
        };
        dynamodb.deleteItem(params, function(err, data) {
            if (err) {
                kony.print("Unable to delete item. Error JSON:" + JSON.stringify(err));
            } else {
                kony.print("DeleteItem succeeded:" + JSON.stringify(data));
            }
        });
    }
}

function frmDynamoDB_segOnRowClick() {
    var data = frmDynamoDB.segRecords.selectedItems[0];
    var userId = data.lblPartitionKey;
    var tablename = data.lblTableName;
    var segData = [];
    frmDynamoDBDetails.segRows.setData(dynamoDBdata);
    FlexContainer040318fa6a58b47.hdrLabel.text = 'NoSQL Demo: SelectTable';
    frmDynamoDBDetails.show();
}

function frmDynamoDBDetails_segOnRowClick() {
    var selectedQuery = frmDynamoDBDetails.segRows.selectedRowIndex;
    var segData = [];
    if (selectedQuery[0] != 3) {
        queryDynamoDB(queries[selectedQuery[0]][selectedQuery[1]], function(data) {
            for (var i = 0; i < data.Count; i++) {
                segData.push({
                    lblCount: "#" + (i + 1),
                    lblUserId: "userId",
                    lblUserIdValue: data.Items[i].userId.S,
                    lblArticleId: "articleId",
                    lblArticleIdValue: data.Items[i].articleId.S,
                    lblAuthor: "author",
                    lblAuthorValue: data.Items[i].author.S,
                    lblCategory: "category",
                    lblCategoryValue: data.Items[i].category.S,
                    lblContent: "content",
                    lblContentValue: data.Items[i].content.S,
                    lblCreationDate: "creationDate",
                    lblCreationDateValue: data.Items[i].creationDate.N,
                    lblKeyword: "keyword",
                    lblKeywordValue: data.Items[i].keywords.S,
                    lblTitle: "Title",
                    lblTitleValue: data.Items[i].title.S
                });
            }
            frmDynamoDBRecords.segRecordShow.setData(segData);
            FlexContainer040318fa6a58b47.hdrLabel.text = 'NoSQL Demo:Records';
            frmDynamoDBRecords.show();
        });
    } else {
        getUserDetails(queries[selectedQuery[0]][selectedQuery[1]], function(data) {
            for (var i = 0; i < data.Count; i++) {
                segData.push({
                    lblCount: "#" + (i + 1),
                    lblUserId: "userId",
                    lblUserIdValue: data.Items[i].userId.S,
                    lblArticleId: "articleId",
                    lblArticleIdValue: data.Items[i].articleId.S,
                    lblAuthor: "author",
                    lblAuthorValue: data.Items[i].author.S,
                    lblCategory: "category",
                    lblCategoryValue: data.Items[i].category.S,
                    lblContent: "content",
                    lblContentValue: data.Items[i].content.S,
                    lblCreationDate: "creationDate",
                    lblCreationDateValue: data.Items[i].creationDate.N,
                    lblKeyword: "keyword",
                    lblKeywordValue: data.Items[i].keywords.S,
                    lblTitle: "Title",
                    lblTitleValue: data.Items[i].title.S
                });
            }
            frmDynamoDBRecords.segRecordShow.setData(segData);
            FlexContainer040318fa6a58b47.hdrLabel.text = 'NoSQL Demo:Records';
            frmDynamoDBRecords.show();
        });
    }
}