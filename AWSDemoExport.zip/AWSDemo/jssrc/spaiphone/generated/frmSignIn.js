function addWidgetsfrmSignIn() {
    frmSignIn.setDefaultUnit(kony.flex.DP);
    var kmdcb87a5cd5842abbfaaeaee33767b53 = new kony.ui.FlexContainer({
        "clipBounds": true,
        "isMaster": true,
        "height": "80%",
        "id": "flxLogin",
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "top": "0dp",
        "width": "100%",
        "zIndex": 3,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "isVisible": true,
        "skin": "slFbox"
    }, {}, {});
    kmdcb87a5cd5842abbfaaeaee33767b53.setDefaultUnit(kony.flex.DP);
    var kmd982c0a0f6348cfa16b96188671a618 = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "id": "txtCognitoUser",
        "left": "5%",
        "placeholder": "E-mail",
        "secureTextEntry": false,
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "3%",
        "width": "90%",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "skin": "CopyslTextBox0fd22b9e996dc41"
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [2, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoComplete": false,
        "autoCorrect": false
    });
    var km7ecfd0628d440bfb68aa87e5460c4ed = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "id": "txtCognitoPassword",
        "left": "5%",
        "placeholder": "Password",
        "secureTextEntry": true,
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "15%",
        "width": "90%",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "skin": "CopyslTextBox081640878a4e440"
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [2, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoComplete": false,
        "autoCorrect": false
    });
    var km8166df9a6a54d4ea03233e984c228a7 = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "preferred",
        "id": "txtCognitoPasswordCon",
        "left": "5%",
        "placeholder": "Conform Password",
        "secureTextEntry": true,
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "28%",
        "width": "90%",
        "isVisible": false,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "skin": "CopyslTextBox081640878a4e440"
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [2, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoComplete": false,
        "autoCorrect": false
    });
    var km34f8dcce1b84d739aa5eea7de41b07f = new kony.ui.Button({
        "height": "10%",
        "id": "btnCoginitoLogin",
        "left": "15.07%",
        "onClick": AS_Button_f15cca82721b435a8bf1c0250dd6e540,
        "text": "Sign In",
        "top": "40.60%",
        "width": "70%",
        "zIndex": 1,
        "focusSkin": "slButtonGlossRed",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue04931bea67a064f"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var km387fe682a8240a282a23976ff58d41b = new kony.ui.Label({
        "id": "CopylblOverviewDetails0564c2b9de1e143",
        "left": "51.04%",
        "text": "Forgot your password?",
        "textStyle": {},
        "top": "57.93%",
        "width": "45%",
        "zIndex": 1,
        "isVisible": true,
        "skin": "CopyslLabel01a3b70084e2e46"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var kmbe41dbab56d4951956451012e50852c = new kony.ui.Button({
        "height": "10%",
        "id": "btnCognitoFacebook",
        "left": "15%",
        "text": "Button",
        "top": "75.36%",
        "width": "70%",
        "zIndex": 1,
        "focusSkin": "slButtonGlossRed",
        "isVisible": false,
        "skin": "CopyslButtonGlossBlue04529dc92935d4b"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var km0e4ed312e7842509943a22bc9069e16 = new kony.ui.Label({
        "height": "preferred",
        "id": "CopylblOverviewDetails0374926068ae84e",
        "left": "35.93%",
        "text": "or sign in with",
        "textStyle": {},
        "top": "67.63%",
        "width": "28%",
        "zIndex": 1,
        "isVisible": false,
        "skin": "CopyslLabel0941191d0506247"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var kmbc89bc65a4c4e22818d14dfe0515a46 = new kony.ui.Label({
        "height": "preferred",
        "id": "CopylblOverviewDetails03685fb79b7bf40",
        "left": "5%",
        "text": "or sign in with",
        "textStyle": {},
        "top": "53%",
        "width": "28%",
        "zIndex": 1,
        "isVisible": false,
        "skin": "CopyslLabel02cca89c98f214c"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var km9aae931ded54ea7ab19538cd818b66f = new kony.ui.Label({
        "height": "preferred",
        "id": "CopylblOverviewDetails045fd896a82d54b",
        "left": "67%",
        "text": "or sign in with",
        "textStyle": {},
        "top": "53%",
        "width": "28%",
        "zIndex": 1,
        "isVisible": false,
        "skin": "CopyslLabel02cca89c98f214c"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var kme096641617d49aeb18129f324f3e784 = new kony.ui.Button({
        "height": "preferred",
        "id": "btnNewAcc",
        "left": "5%",
        "onClick": AS_Button_d904919cb81946d2acfb7cb8f8e450d3,
        "text": "Create New Account",
        "top": "57.97%",
        "width": "44%",
        "zIndex": 1,
        "focusSkin": "CopyslButtonGlossRed0efb887ae3e7442",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue03c133adaab6e4b"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    kmdcb87a5cd5842abbfaaeaee33767b53.add(kmd982c0a0f6348cfa16b96188671a618, km7ecfd0628d440bfb68aa87e5460c4ed, km8166df9a6a54d4ea03233e984c228a7, km34f8dcce1b84d739aa5eea7de41b07f, km387fe682a8240a282a23976ff58d41b, kmbe41dbab56d4951956451012e50852c, km0e4ed312e7842509943a22bc9069e16, kmbc89bc65a4c4e22818d14dfe0515a46, km9aae931ded54ea7ab19538cd818b66f, kme096641617d49aeb18129f324f3e784);
    frmSignIn.add(kmdcb87a5cd5842abbfaaeaee33767b53);
};

function frmSignInGlobals() {
    frmSignIn = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmSignIn,
        "enabledForIdleTimeout": false,
        "id": "frmSignIn",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "preShow": AS_Form_93d79f77536640edbb1769e40dd1ad25,
        "skin": "CopyslForm053bd4bed76e44a"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false
    });
    frmSignIn.info = {
        "notesId": "8195a51215fe4ffea8d9accfdefa3ca0",
        "kuid": "8195a51215fe4ffea8d9accfdefa3ca0"
    };
};