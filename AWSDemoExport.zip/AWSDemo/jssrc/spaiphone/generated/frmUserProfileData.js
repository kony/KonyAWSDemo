function addWidgetsfrmUserProfileData() {
    frmUserProfileData.setDefaultUnit(kony.flex.DP);
    var FlexContainer04b732d5f9cb84b = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "80%",
        "id": "FlexContainer04b732d5f9cb84b",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%",
        "zIndex": 3
    }, {}, {});
    FlexContainer04b732d5f9cb84b.setDefaultUnit(kony.flex.DP);
    var lblOverView = new kony.ui.Label({
        "id": "lblOverView",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0d6421e4ff24c4a",
        "text": "Please choose a theme:",
        "top": "5%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var CopyButton0fd37e90d662440 = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "25%",
        "id": "CopyButton0fd37e90d662440",
        "isVisible": true,
        "left": "52%",
        "skin": "CopyslButtonGlossBlue0b4c973979e014c",
        "top": "15%",
        "width": "43%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Button02bfe1ab2f98945 = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "25%",
        "id": "Button02bfe1ab2f98945",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslButtonGlossBlue0aad4b640e1be4c",
        "top": "15%",
        "width": "43%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyButton0faf3a18a99ee45 = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "25%",
        "id": "CopyButton0faf3a18a99ee45",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslButtonGlossBlue0f8cc8c27863b4d",
        "top": "45%",
        "width": "43%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyButton034d8fc8237ab49 = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "25%",
        "id": "CopyButton034d8fc8237ab49",
        "isVisible": true,
        "left": "52%",
        "skin": "CopyslButtonGlossBlue06247e61bb25a49",
        "top": "45%",
        "width": "43%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer04b732d5f9cb84b.add(lblOverView, CopyButton0fd37e90d662440, Button02bfe1ab2f98945, CopyButton0faf3a18a99ee45, CopyButton034d8fc8237ab49);
    frmUserProfileData.add(FlexContainer04b732d5f9cb84b);
};

function frmUserProfileDataGlobals() {
    frmUserProfileData = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmUserProfileData,
        "enabledForIdleTimeout": false,
        "id": "frmUserProfileData",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm053bd4bed76e44a",
        "title": "User Profile Data"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false
    });
    frmUserProfileData.info = {
        "notesId": "fee2c2fd8f454fef91ce05bfcdea21cc",
        "kuid": "fee2c2fd8f454fef91ce05bfcdea21cc"
    };
};