kony.globals["appid"] = "AWSDemo";
kony.globals["locales"] = [];