function addWidgetsfrmDynamoDBDetails() {
    frmDynamoDBDetails.setDefaultUnit(kony.flex.DP);
    var segRows = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [
            [{
                    "lblSectionHead": "Label"
                },
                [{
                    "lblDescription": "Label",
                    "lblHeading": "Label"
                }, {
                    "lblDescription": "Label",
                    "lblHeading": "Label"
                }, {
                    "lblDescription": "Label",
                    "lblHeading": "Label"
                }]
            ],
            [{
                    "lblSectionHead": "Label"
                },
                [{
                    "lblDescription": "Label",
                    "lblHeading": "Label"
                }, {
                    "lblDescription": "Label",
                    "lblHeading": "Label"
                }, {
                    "lblDescription": "Label",
                    "lblHeading": "Label"
                }]
            ]
        ],
        "groupCells": false,
        "height": "90%",
        "id": "segRows",
        "isVisible": true,
        "left": "1%",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_9fad32c0eaef4291954948a75a354280,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": flxMain,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "sectionHeaderTemplate": flxSectionHeader,
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "0%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "flxMain": "flxMain",
            "flxSectionHeader": "flxSectionHeader",
            "lblDescription": "lblDescription",
            "lblHeading": "lblHeading",
            "lblSectionHead": "lblSectionHead"
        },
        "width": "98%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Button0886a027e43ef4d = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossRed0b53b4a4aaff54e",
        "height": "10%",
        "id": "Button0886a027e43ef4d",
        "isVisible": true,
        "left": "0%",
        "onClick": AS_Button_659f5d16d99f4943a49addd017146f03,
        "skin": "CopyslButtonGlossRed0b53b4a4aaff54e",
        "text": "Insert Sample Data",
        "top": "90%",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnRemove = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossRed0b53b4a4aaff54e",
        "height": "10%",
        "id": "btnRemove",
        "isVisible": true,
        "left": "50%",
        "onClick": AS_Button_95004d05d0a34ddf95f9956b4940d594,
        "skin": "CopyslButtonGlossBlue0e4976f1f72894c",
        "text": "Remove Sample Data",
        "top": "90%",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmDynamoDBDetails.add(segRows, Button0886a027e43ef4d, btnRemove);
};

function frmDynamoDBDetailsGlobals() {
    frmDynamoDBDetails = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmDynamoDBDetails,
        "enabledForIdleTimeout": false,
        "id": "frmDynamoDBDetails",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "preShow": AS_Form_0f3e9560ffbf4073aec84cf6520d348d,
        "skin": "CopyslForm00c2a74bfe7b646"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false
    });
    frmDynamoDBDetails.info = {
        "kuid": "3cd03bb4004f4a6d8cafff6aaf3949d9"
    };
};