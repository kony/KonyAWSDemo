function addWidgetsfrmImageOpen() {
    frmImageOpen.setDefaultUnit(kony.flex.DP);
    var FlexContainer04b732d5f9cb84b = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "FlexContainer04b732d5f9cb84b",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0%",
        "width": "100%",
        "zIndex": 3
    }, {}, {});
    FlexContainer04b732d5f9cb84b.setDefaultUnit(kony.flex.DP);
    var imgLocal = new kony.ui.Image2({
        "height": "100%",
        "id": "imgLocal",
        "isVisible": true,
        "left": "0dp",
        "skin": "slImage",
        "src": "imagedrag.png",
        "top": "0dp",
        "width": "100%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer04b732d5f9cb84b.add(imgLocal);
    frmImageOpen.add(FlexContainer04b732d5f9cb84b);
};

function frmImageOpenGlobals() {
    frmImageOpen = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmImageOpen,
        "enabledForIdleTimeout": false,
        "id": "frmImageOpen",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm053bd4bed76e44a",
        "title": "example-image-1.png"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false
    });
    frmImageOpen.info = {
        "notesId": "458a27f99491437da3f48bccfaf23f66",
        "kuid": "458a27f99491437da3f48bccfaf23f66"
    };
};