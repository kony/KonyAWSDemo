function initializetmpIdentity() {
    HBox0e2b8165c2d2a48 = new kony.ui.Box({
        "id": "HBox0e2b8165c2d2a48",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL,
        "position": constants.BOX_POSITION_AS_NORMAL,
        "skin": "slHbox"
    }, {
        "containerWeight": 100,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    var Image008a4793b85d945 = new kony.ui.Image2({
        "id": "Image008a4793b85d945",
        "isVisible": true,
        "skin": "slImage",
        "src": "imagedrag.png"
    }, {
        "containerWeight": 20,
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    var Label0acee3151c0534c = new kony.ui.Label({
        "id": "Label0acee3151c0534c",
        "isVisible": true,
        "skin": "CopyslLabel0c26c1d94f9844a",
        "text": "Label"
    }, {
        "containerWeight": 80,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    HBox0e2b8165c2d2a48.add(Image008a4793b85d945, Label0acee3151c0534c);
}