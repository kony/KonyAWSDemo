function addWidgetsForm03b1a4fed99ab43() {
    Form03b1a4fed99ab43.setDefaultUnit(kony.flex.DP);
    var Button03feafb6f56ba4f = new kony.ui.Button({
        "centerX": "50%",
        "focusSkin": "slButtonGlossRed",
        "height": "50dp",
        "id": "Button03feafb6f56ba4f",
        "isVisible": true,
        "left": "37dp",
        "onClick": AS_Button_86a7c035daca49e0a7dc8269a6552953,
        "skin": "slButtonGlossBlue",
        "text": "Button",
        "top": "380dp",
        "width": "260dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Button0b117fdb54ed94f = new kony.ui.Button({
        "centerX": "50%",
        "focusSkin": "slButtonGlossRed",
        "height": "50dp",
        "id": "Button0b117fdb54ed94f",
        "isVisible": true,
        "left": "81dp",
        "skin": "CopyslButtonGlossBlue01bc9f76c8da74d",
        "text": "Button",
        "top": "194dp",
        "width": "260dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    Form03b1a4fed99ab43.add(Button03feafb6f56ba4f, Button0b117fdb54ed94f);
};

function Form03b1a4fed99ab43Globals() {
    Form03b1a4fed99ab43 = new kony.ui.Form2({
        "addWidgets": addWidgetsForm03b1a4fed99ab43,
        "enabledForIdleTimeout": false,
        "id": "Form03b1a4fed99ab43",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "skin": "slForm"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false
    });
    Form03b1a4fed99ab43.info = {
        "kuid": "1f8a61faf2ff46268e2618b32b4c5347"
    };
};