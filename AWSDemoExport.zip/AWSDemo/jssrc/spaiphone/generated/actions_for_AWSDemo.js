//actions.js file 
function AS_Button_f1e80015898e4a5a9a39579c976ce523(eventobject) {
    return createNewUser.call(this);
}

function AS_Button_fb961ea47d8e482292cf363f1b9f6cdc(eventobject) {
    return validateUserDetails.call(this);
}

function AS_FlexContainer_590e9a0997d14d57899f22f0bff1b9c6(eventobject) {
    return segPhotoOnClick.call(this);
}

function AS_Segment_51fafd59ec9741af8706b5f953399b24(eventobject, sectionNumber, rowNumber) {
    return segPhotoOnClick.call(this);
}

function AS_AppEvents_05fded69b8ac4e76a1d0740ca98f1c58(eventobject) {}

function AS_Button_02d5d3edfa544d45ad7fe60bcc48d528(eventobject) {
    AS_Button_fb961ea47d8e482292cf363f1b9f6cdc(eventobject);
}

function AS_Button_11908f7c94fa4e4284adcbf97ac9f14c(eventobject) {
    validateUserDetails();
}

function AS_Button_146a67f5dae0437a9dec03c45ff68b92(eventobject) {
    AS_Button_f1e80015898e4a5a9a39579c976ce523(eventobject);
}

function AS_Button_14bd5b5930b744fc8ae1a401ec441b7b(eventobject) {
    AS_Button_fb961ea47d8e482292cf363f1b9f6cdc(eventobject);
}

function AS_Button_18b6c96901244029a7585b83306eaa74(eventobject) {
    sortPhotos('name');
}

function AS_Button_2f912ca5352b4d40927251a602e70755(eventobject) {
    createNewUser();
}

function AS_Button_3873fba490354252a18d1f7215a8670c(eventobject) {
    return headerBackBtnClick.call(this);
}

function AS_Button_419d3caccfa14fe797138b42ce6f923f(eventobject) {
    AS_Button_f1e80015898e4a5a9a39579c976ce523(eventobject);
}

function AS_Button_47ec9d74125148eaa7c9b86c232d335e(eventobject) {
    AS_Button_fb961ea47d8e482292cf363f1b9f6cdc(eventobject);
}

function AS_Button_51ac5ddb835546edba2a3e93cab66ab1(eventobject) {
    currentUserInfo = {};
    loggedin = 0;
    frmHome.show();
}

function AS_Button_5763fb394253421fab85c51184433268(eventobject) {
    AS_Button_f1e80015898e4a5a9a39579c976ce523(eventobject);
}

function AS_Button_58b10d870f9b43118d385d316c4dab9d(eventobject) {
    return uploadImage.call(this);
}

function AS_Button_659f5d16d99f4943a49addd017146f03(eventobject) {
    return InsertSampleData.call(this);
}

function AS_Button_661e4fcc104e48278b4377156783a1d6(eventobject) {
    AS_Button_f1e80015898e4a5a9a39579c976ce523(eventobject);
}

function AS_Button_73649d2d0f82474da97b959634012ac7(eventobject) {
    AS_Button_fb961ea47d8e482292cf363f1b9f6cdc(eventobject);
}

function AS_Button_86a7c035daca49e0a7dc8269a6552953(eventobject) {
    getUserCredentials.call(this, null, null);
    Form03b1a4fed99ab43.Button03feafb6f56ba4f["skin"] = "";
    undefined.show();
}

function AS_Button_89705506861e4d458f0da17a8dae7393(eventobject) {
    sortPhotos('date');
}

function AS_Button_95004d05d0a34ddf95f9956b4940d594(eventobject) {
    return RemoveSampleData.call(this);
}

function AS_Button_9921b4a90c994abbaea1b56a9238dad4(eventobject) {
    AS_Button_fb961ea47d8e482292cf363f1b9f6cdc(eventobject);
}

function AS_Button_9ea9e824aab04737aca6aa91fe969dc0(eventobject) {
    AS_Button_f1e80015898e4a5a9a39579c976ce523(eventobject);
}

function AS_Button_a090950439cb4d9895cc80beed7d4b4e(eventobject) {
    AS_Button_f1e80015898e4a5a9a39579c976ce523(eventobject);
}

function AS_Button_aad85469cd414bfcbb2187e3814413d3(eventobject) {
    AS_Button_f1e80015898e4a5a9a39579c976ce523(eventobject);
}

function AS_Button_bc43f5a61aec476c8ec870d4c8259c98(eventobject) {
    currentUserInfo = {};
    loggedin = 0;
    frmHome.show();
}

function AS_Button_d056a4a976f24e839cd243ff494e8ef8(eventobject) {
    AS_Button_fb961ea47d8e482292cf363f1b9f6cdc(eventobject);
}

function AS_Button_d3b0209ef3c24501b1cfa7815f8107dd(eventobject) {
    AS_Button_fb961ea47d8e482292cf363f1b9f6cdc(eventobject);
}

function AS_Button_d6721ba2b0f446dc83f4cb7f256885a7(eventobject) {
    AS_Button_f1e80015898e4a5a9a39579c976ce523(eventobject);
}

function AS_Button_d904919cb81946d2acfb7cb8f8e450d3(eventobject) {
    AS_Button_f1e80015898e4a5a9a39579c976ce523(eventobject);
}

function AS_Button_d91296dfbf024132b85aeb17bc2fe689(eventobject) {
    AS_Button_fb961ea47d8e482292cf363f1b9f6cdc(eventobject);
}

function AS_Button_f15cca82721b435a8bf1c0250dd6e540(eventobject) {
    AS_Button_fb961ea47d8e482292cf363f1b9f6cdc(eventobject);
}

function AS_Button_f3a64a070a26468a824c9c5ef1d986ac(eventobject) {
    return invokeLambda.call(this);
}

function AS_Button_fa1b3fbcd60e46278318abd271d820c0(eventobject) {
    frmClogic.lblResult["text"] = "";
    frmClogic.Button0aa44fcf93d4344["text"] = "{ \"key1\":\"value1\", \"key2\":\"value2\", \"key3\":\"value3\" }";
    frmClogic.txtFunction["text"] = "hello-world";
}

function AS_Button_fcbf039b144f4d67b186374fb9f7bd97(eventobject) {
    sortPhotos('size');
}

function AS_FlexContainer_2c8d41ae09b440b4a7113bfa3a749e8b(eventobject) {
    AS_FlexContainer_590e9a0997d14d57899f22f0bff1b9c6(eventobject);
}

function AS_Form_0f3e9560ffbf4073aec84cf6520d348d(eventobject) {
    return frmDynamoDBDetails_PreShow.call(this);
}

function AS_Form_1abc67bad55f4009904e40b46103d7fc(eventobject) {
    return frmDynamoDB_PreShow.call(this);
}

function AS_Form_25e8a43dae8b43b9bd4c9ea30d0d87fc(eventobject) {
    frmUserIdentity_PreShow();
}

function AS_Form_7971aa9421bf4728bf3919cc55debd6d(eventobject) {
    return ppInit.call(this, AWS, config);
}

function AS_Form_93d79f77536640edbb1769e40dd1ad25(eventobject) {
    return frmSingInPreShow.call(this);
}

function AS_Form_9bbe6b8710f7419282dcd0b2a654f4b6(eventobject) {
    return frmHome_PreShow.call(this);
}

function AS_Form_a6958e45d39a45f598ed631af3f3cd7e(eventobject) {
    return frmUserFileStorage_PreShow.call(this);
}

function AS_Form_c3821e1759d54b95a2a830e53b6692fc(eventobject) {
    frmClogicPreshow.call(this);
    frmClogic.txtFunction.text = LambdaFunctiontoInvoke;
}

function AS_Segment_47914ec979a047988e4f23269f2aaa4e(eventobject, sectionNumber, rowNumber) {
    return segPhotoOnClick.call(this);
}

function AS_Segment_913bd6df60ef44b0834907acbba144c3(eventobject, sectionNumber, rowNumber) {
    AS_Segment_51fafd59ec9741af8706b5f953399b24(eventobject, sectionNumber, rowNumber);
}

function AS_Segment_9fad32c0eaef4291954948a75a354280(eventobject, sectionNumber, rowNumber) {
    return frmDynamoDBDetails_segOnRowClick.call(this);
}

function AS_Segment_ec3b0e2f7e9f4fe7b44e8362052c085f(eventobject, sectionNumber, rowNumber) {
    return frmDynamoDB_segOnRowClick.call(this);
}