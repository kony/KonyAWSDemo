//startup.js file
var appConfig = {
    appId: "AWSDemo",
    appName: "AWS",
    appVersion: "1.0.0",
    platformVersion: null,
    serverIp: "10.10.25.85",
    serverPort: "80",
    secureServerPort: "443",
    isMFApp: false,
    eventTypes: ["FormEntry", "ServiceRequest", "Error", "Crash"],
    url: "https://konysecloud.konycloud.com/AWSDemo/MWServlet",
    secureurl: "https://konysecloud.konycloud.com/AWSDemo/MWServlet",
    middlewareContext: "AWSDemo"
};
sessionID = "";

function appInit(params) {
    skinsInit();
    initializeheader1();
    initializetmpIdentity();
    initializeFlexContainer09293fda58b5746();
    initializesegHomeOptions();
    initializetempDemoQueryRow();
    initializetempDemoQuerySection();
    initializetmpAppContentDelivery();
    initializetmpRecords();
    initializetmpRows();
    initializetmpShowRecords();
    Form03b1a4fed99ab43Globals();
    frmClogicGlobals();
    frmDetailsGlobals();
    frmDynamoDBGlobals();
    frmDynamoDBDetailsGlobals();
    frmDynamoDBRecordsGlobals();
    frmHomeGlobals();
    frmImageOpenGlobals();
    frmLoginGlobals();
    frmSignInGlobals();
    frmUserFileStorageGlobals();
    frmUserIdentityGlobals();
    frmUserProfileDataGlobals();
    frmWelcomeGlobals();
    popupDownloadGlobals();
    popupDownloadStarGlobals();
    popupSetCacheSizeGlobals();
    popupStorageDownloadGlobals();
    popupStorageDownloadStarGlobals();
    popupStorageSetCacheSizeGlobals();
    popupUploadGlobals();
    popupUploadStorageGlobals();
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        APILevel: 7100
    })
};

function themeCallBack() {
    initializeGlobalVariables();
    kony.application.setApplicationInitializationEvents({
        init: appInit,
        postappinit: AS_AppEvents_05fded69b8ac4e76a1d0740ca98f1c58,
        showstartupform: function() {
            frmHome.show();
        }
    });
};

function loadResources() {
    kony.theme.packagedthemes(
        ["default"]);
    globalhttpheaders = {};
    callAppMenu();
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
        eventTypes: ["FormEntry", "ServiceRequest", "Error", "Crash"]
    }
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
};

function onSuccessSDKCallBack() {
    spaAPM && spaAPM.startTracking();
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
}

function initializeApp() {
    kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
    //If default locale is specified. This is set even before any other app life cycle event is called.
    loadResources();
};