'use strict';

console.log('Loading function');

var aws = require('aws-sdk');
aws.config.region = 'us-east-1';
var cognitoidentity = new aws.CognitoIdentity();
var identityPoolId = "us-east-1:9c8f0110-3590-4669-a0ae-ad17edfb9afc";
      
exports.handler = (event, context, callback) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    event.forEach((record) => {
        console.log(record.userid);
        console.log(record.username);
        
            var params = {
                IdentityPoolId: identityPoolId,
                Logins: {
                    'login.kony.awstest': record.userid
                }
            };
            cognitoidentity.getOpenIdTokenForDeveloperIdentity(params,function(err,data){
                if(err){
                    console.log(err);
                    context.fail('Something went wrong');
                }else{
                    context.succeed(data);
                }
            });
        
    });
    callback(null, `Successfully processed ${event.length} records.`);
};