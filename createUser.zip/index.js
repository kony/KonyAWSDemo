var aws = require('aws-sdk');
var userdetails = "mysampleapp-mobilehub-676070864-userdetails";
var crypto = require('crypto');
var dynamodb = new aws.DynamoDB({
                apiVersion: '2012-08-10'
            });
            
aws.config.region = 'us-east-1';

function computeHash(password,  fn) {
	// Bytesize
	var len = 128;
	var iterations = 4096;

	crypto.randomBytes(len, function(err, salt) {
		if (err) return fn(err);
		salt = salt.toString('base64');
		crypto.pbkdf2(password, salt, iterations, len, function(err, derivedKey) {
			if (err) return fn(err);
			else fn(null, salt, derivedKey.toString('base64'));
		});
	});
	
}

 //CryptoJS.AES.encrypt(inputstring, generatedkey, { mode: mode, padding: padding});
      
exports.handler = (event, context, callback) => {
  //  console.log('Received event:', JSON.stringify(event, null, 2));
    
    var username = event.username;
    var passkey = event.passkey;

	var hash = crypto.createHash('md5');
	hash.update(username);
	var userId =hash.digest('hex');
	
	console.log(' Userid ' + userId);
	
	computeHash(passkey ,function (err, salt, hash){
        dynamodb.putItem({
    		TableName: userdetails,
    		Item: {
    			userId: {
    				S: userId
    			},
    			username: {
    				S: username
    			},
    			passkey: {
    				S: JSON.stringify({hash:hash,salt:salt})
    			}
    		}
    	}, function(err, data) {
    		if (err){ 
    		    context.fail(err);
    		}
    		else {
    		     context.succeed(data);
    		}
    	});
	    
	});
};