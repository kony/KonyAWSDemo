var aws = require('aws-sdk');
var crypto = require('crypto');
var userdetails = "mysampleapp-mobilehub-676070864-userdetails";
var dynamodb = new aws.DynamoDB({
                apiVersion: '2012-08-10'
            });
aws.config.region = 'us-east-1';            
            
function getUserDetails(userId, callback) {                
    var params = {
        'TableName': userdetails,
        Key: {
            "userId": {S: userId} 
        }
    };
    dynamodb.getItem(params, function(err, data) {
        if (err) {
            kony.print('JSON err' + err);
        } else {                        
            callback(data);
        }
        //console.log(data);           // successful response
    });
}            
 
function computeHash(password,  fn) {
	// Bytesize
	var len = 128;
	var iterations = 4096;

	crypto.randomBytes(len, function(err, salt) {
		if (err) return fn(err);
		salt = salt.toString('base64');
		crypto.pbkdf2(password, salt, iterations, len, function(err, derivedKey) {
			if (err) return fn(err);
			else fn(null, salt, derivedKey.toString('base64'));
		});
	});
}


 //CryptoJS.AES.encrypt(inputstring, generatedkey, { mode: mode, padding: padding});
      
exports.handler = (event, context, callback) => {
   // console.log('Received event:', JSON.stringify(event, null, 2));
    
    var username = event.username;
    var passkey = event.passkey;
    
    var hash = crypto.createHash('md5');
	hash.update(username);
	var userId =hash.digest('hex');
    
    getUserDetails(userId, function(userDetails){
           // console.log("Userdetails", userDetails);
            var ePasskey = JSON.parse(userDetails.Item.passkey.S);
            var salt = ePasskey.salt;
            var len = 128;
	        var iterations = 4096;
            crypto.pbkdf2(passkey, salt, iterations, len, function(err, derivedKey) {
    			var hash = derivedKey.toString('base64');
    			if(ePasskey.hash == hash){
                    context.succeed({login: true});
                    console.log("Login Success.");
                }else{
                    context.succeed({login: false});
                }
    		});
        }
    );
};